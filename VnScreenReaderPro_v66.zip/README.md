# Đọc Màn Hình Việt Pro

Trình đọc màn hình (screen reader) cho Android dành cho người khiếm thị, viết bằng Kotlin và Jetpack Compose.

## Tính năng
- Đọc nội dung bằng giọng tiếng Việt (Android TextToSpeech), ngắt lời tức thì, hàng đợi thông minh.
  Văn bản dài được tự chia nhỏ; nếu TTS chưa sẵn sàng lúc khởi động máy thì tự thử lại.
- Ngắt câu theo ngữ pháp tiếng Việt: không cắt sau từ treo (của, và, là...), không tách số/giờ/viết tắt.
- Đọc thêm trạng thái: vô hiệu hóa, đã chọn, tiêu đề, thanh trượt (%), lỗi nhập, vai trò do app khai báo.
- Xử lý sự kiện trên luồng nền (coroutines), lọc sự kiện trùng để giảm độ trễ.
- Khung viền xanh lá quanh phần tử đang chọn.
- Khám phá bằng cảm ứng: đặt ngón tay lên phần tử nào thì đọc phần tử đó; chạm hai lần (ở bất kỳ đâu) để nhấn
  phần tử vừa nghe.
- 45 cử chỉ chạm (1 ngón: vuốt 4 hướng, 12 cử chỉ hai bước, chạm hai lần, chạm hai lần và giữ; 2, 3, 4 ngón) và 8 cử chỉ phím cứng (phím âm lượng, nút tai nghe), gán chức năng tùy ý. Riêng bốn cú **hai ngón vuốt** do Android xử lý như ở các trình đọc màn hình lớn nên không gán lại được (xem bản 2.18.1).
- **AI trên máy, không dùng mạng** (mô hình ML Kit đóng gói sẵn trong APK; ứng dụng không xin quyền INTERNET):
  - *Đọc chữ trên màn hình (OCR)* và *Mô tả hình ảnh của phần tử đang chọn* - gán vào cử chỉ bất kỳ trong thẻ "Cử chỉ".
  - Đọc thông báo mới đã được tóm tắt (bỏ trùng, rút gọn, gộp khi dồn dập); bật/tắt ở thẻ cài đặt chung. Không đọc khi màn hình tắt.
- Phần tử không có nhãn (không cần chụp màn hình): nhãn ứng dụng → nhãn tự gán → chữ gộp của phần tử con →
  đoán theo tên view (báo "nhãn đoán") → "không có nhãn". Gắn nhãn tự gán bằng cử chỉ "Gắn nhãn cho phần tử đang chọn".
- Chế độ phản hồi: chỉ rung / chỉ âm báo / cả hai / tắt, đổi tức thì, không ảnh hưởng giọng đọc.
- Rung và âm báo (tổng hợp tại chỗ, không tệp âm thanh) khi chuyển phần tử, chạm đầu/cuối, nhấn.
- Chọn công cụ TTS (engine) ngay trong cài đặt, có hiệu lực tức thì.
- Chạy ngay ở màn hình nhập mã sau khi khởi động lại máy, trước khi mở khóa lần đầu (Direct Boot, xem "Bản 2.25.0"), và nối lại giọng đọc ngay khi máy khởi động xong (xem "Bản 2.27.0").
- Cài đặt chia thành 6 menu và 17 trang (xem "Bản 2.21.0", "Bản 2.23.0" và "Bản 2.29.0"), bố cục thích ứng: máy rộng hiện cây menu + nội dung song song; máy hẹp mở từng tầng, Back lùi từng tầng.
- Hệ thống tiện ích: plugin dựng sẵn và script JSON nạp từ tệp.
- Giao diện độ tương phản cao (đen/vàng).

## Cử chỉ mặc định
| Cử chỉ | Chức năng |
|---|---|
| Vuốt phải / trái | Phần tử kế tiếp / trước đó |
| Chạm hai lần | Nhấn phần tử đang chọn |
| Chạm hai lần và giữ | Nhấn giữ phần tử đang chọn (nếu hệ thống gửi cử chỉ này tới app; xem "Điều kiện hệ thống ảnh hưởng cử chỉ") |
| Vuốt xuống / lên | Tiến / lùi theo **điều khiển đọc** đang chọn (ban đầu: từng phần tử, như vuốt phải / trái). Trong **ô nhập**: dời **con trỏ thật** theo đơn vị của điều khiển (ban đầu: từng ký tự) và đọc đoạn chữ vừa đi qua. Đang chọn thanh trượt thì xuống = giảm, lên = tăng (xem bản 2.19.0 và 2.20.0) |
| Xuống rồi phải | **Trình đơn chung** |
| Lên rồi phải | **Trình đơn của phần tử đang chọn** |
| Lên rồi trái | Màn hình chính |
| Xuống rồi trái | Quay lại |
| Trái rồi lên | Ứng dụng gần đây |
| Phải rồi xuống | Thông báo |
| Trái rồi xuống | Tìm chữ trên màn hình |
| Lên rồi xuống | Điều khiển đọc **kế** (phần tử → ký tự → từ → câu → đoạn → tiêu đề → điều khiển → liên kết → tốc độ đọc → phần tử...) |
| Xuống rồi lên | Điều khiển đọc **trước** |
| Hai ngón chạm | Dừng đọc |
| Hai ngón chạm hai lần | Phát / tạm dừng nhạc hoặc video (phím media chuẩn) |
| Hai ngón chạm ba lần | Đọc liên tục từ phần tử đang chọn |
| Hai ngón vuốt lên / xuống | **Do Android xử lý như một ngón vuốt**: cuộn nội dung tại chỗ; khi dùng điều hướng bằng cử chỉ thì vuốt lên từ mép dưới = Màn hình chính (giữ = Ứng dụng gần đây), vuốt xuống từ mép trên = Thông báo |
| Hai ngón vuốt trái / phải | **Do Android xử lý**: chuyển trang ngang tại chỗ; từ mép trái/phải vào = Quay lại |
| Ba ngón chạm | Trình đơn chung |
| Ba ngón chạm hai lần / ba lần | Sao chép chữ của phần tử đang chọn / dán vào ô nhập |
| Ba ngón chạm hai lần và giữ | Cắt chữ ở ô nhập |
| Ba ngón vuốt xuống / lên | Điều khiển đọc **kế** / **trước** (cùng việc với lên-rồi-xuống / xuống-rồi-lên) |
| Ba ngón vuốt trái / phải | **Trang kế / trang trước** (chuyển trang ngang: ViewPager, tab vuốt ngang) |
| Bốn ngón chạm / chạm hai lần | Đổi chế độ rung và âm báo / cho biết giờ và pin |

**Từ bản 2.20.0 các cử chỉ hai bước và nhiều ngón theo bảng cử chỉ chuẩn của Bộ trợ năng Android** (xem phần "Bản 2.20.0" bên dưới: bảng so sánh, các hành động bị nhường chỗ và cách lấy lại). Mặc định mới chỉ tới những cử chỉ bạn **chưa đổi**: từ bản 2.6.0 cấu hình chỉ lưu những cử chỉ bạn thật sự đổi, nên cử chỉ đã đổi giữ nguyên và các cử chỉ còn lại nhận mặc định mới khi cập nhật; cấu hình lưu từ trước bản 2.6.0 (ghi đủ mọi cử chỉ) giữ nguyên hoàn toàn. Đổi cử chỉ làm mất hết cử chỉ của "phần tử kế", "phần tử trước" hay "nhấn" sẽ có cảnh báo. Tất cả đều đổi được trong mục **Cử chỉ**, nơi cũng có nút khôi phục mặc định. Android không cho dịch vụ hỗ trợ tiếp cận bắt cử chỉ vuốt từ cạnh màn hình.

## Trình đơn
Từ bản 2.29.0 hai trình đơn có **hai trang riêng** trong ứng dụng (Cài đặt → Điều khiển), mỗi trang chỉ hiện đúng trình đơn của nó, lấy từ cấu hình thật của bạn (trước đó chung một trang "Trình đơn nhanh"; khóa cũ `menus` vẫn mở trang **Trình đơn hành động nhanh**).
- Trang **Trình đơn chung** (chỉ xem): trình đơn này chứa **toàn bộ 65 chức năng** của ứng dụng và không sửa được, nên luôn đầy đủ. Cấp đầu có 7 mục dùng nhiều nhất (đọc từ đầu, đọc từ phần tử hiện tại, lặp lại, tìm chữ, đọc chữ trên màn hình (OCR), thông báo, màn hình chính), rồi 7 nhóm; mỗi nhóm là một trình đơn con, mục cuối là **Quay lại**: **Đọc** (10), **Duyệt nhanh** (12), **Cuộn và trang** (6), **Phần tử đang chọn** (11), **Chỉnh sửa văn bản** (9), **Hệ thống và phím** (9), **Công cụ và thông tin** (8).
- Trang **Trình đơn hành động nhanh** (sửa được): **trình đơn phần tử** là danh sách của riêng bạn, tối đa 12 chức năng. Mặc định giống các bản trước: nhấn, nhấn giữ, đơn vị kế/trước, đổi đơn vị đọc, sao chép đơn vị, sao chép chữ, đọc từng ký tự, gắn nhãn, mô tả hình ảnh, đọc chữ trong ảnh, thông tin kỹ thuật. Thêm, xóa, đổi thứ tự, thay chức năng và khôi phục mặc định ngay trong trang **Trình đơn hành động nhanh**. Cuối trình đơn còn có các hành động tùy chỉnh của ứng dụng và, riêng ở **ô nhập liệu**, trình đơn con **Chỉnh sửa văn bản** (dán, cắt, chọn tất cả, đưa con trỏ về đầu/cuối, chọn đến đầu/cuối, xóa tất cả, khôi phục chữ vừa xóa, **Quay lại**); hai phần này không tính vào 12.
- Khi trình đơn mở: vuốt phải/trái (hoặc xuống/lên) chọn mục, **hoặc chạm và lướt ngón tay trên màn hình** để nghe từng mục (trình đơn hiện thành danh sách phủ toàn màn hình, xem "Bản 2.23.0"), chạm hai lần thực hiện mục đang chọn, quay lại để lùi một cấp. Mở trình đơn là vào thẳng
  mục đầu tiên (không đọc tên và số mục trước); cử chỉ không dùng được trong trình đơn chỉ nhắc ngắn một lần.
- Cài đặt **Đọc hướng dẫn thao tác** (Nội dung được đọc → Cách đọc phần tử, mặc định bật): tắt thì trình đơn chỉ đọc tên mục, không đọc vị trí, chữ "nhóm", tên nhóm khi vào và lời nhắc.

## Bản 2.29.0: đọc khi xóa ký tự, chế độ an toàn khi không nhập được mã mở khóa, tách trang trình đơn, công cụ giọng nói thành danh sách

Yêu cầu (27/11/2026): "sửa chữa một số lỗi và một số tính năng": (1) sau khi khởi động lại, nhập mã mở khóa hoàn toàn không gõ được; (2) xóa ký tự trong văn bản đã nhập thì không đọc gì; (3) công cụ giọng nói thành danh sách chọn (mặc định công cụ thứ nhất, bấm vào hiện hai lựa chọn khi dùng hai công cụ) và "đọc theo từ và câu" cũng thành danh sách; (4) "Trình đơn" tách thành hai trang riêng, bấm vào trang nào chỉ hiện đúng trình đơn đó.

**Cách hiểu (sai thì báo, sửa một dòng):** "trình đơn 9" (ghi theo giọng nói) = **Trình đơn chung** (trình đơn chính, đủ mọi chức năng); "trình đơn hành động nhân" = **Trình đơn hành động nhanh** = trình đơn của phần tử mà bạn tự sắp xếp (trước đây tên "Trình đơn nhanh"/"Trình đơn phần tử").

- **(2) Xóa ký tự nay được đọc** ("Đã xóa c", "Đã xóa dấu cách", "Đã xóa xuống dòng", "Đã xóa tab"; xóa quá 24 ký tự một lần thì chỉ nói "Đã xóa").
  - *Nguyên nhân:* việc đọc dựa vào ba số đếm của sự kiện (`fromIndex`, `addedCount`, `removedCount`). Nhiều ứng dụng và bàn phím báo 0/0, hoặc báo "thay cả từ" (nhất là chữ đang soạn kiểu Telex), nên xóa một ký tự không có số nào dương → im lặng.
  - *Cách sửa:* so văn bản TRƯỚC và SAU như TalkBack (`core/TextEdits.kt`: phần đầu chung, phần cuối chung, không cắt giữa cặp thay thế của biểu tượng cảm xúc, bỏ qua văn bản dài quá 20.000 ký tự). Văn bản trước lấy từ `beforeText` của sự kiện; thiếu thì từ bộ nhớ một ô (`TextMemory`: chỉ nhớ ô đang gõ, không nhớ ô mật khẩu, quên khi đổi ô hoặc cửa sổ); vẫn không so được thì dùng số đếm như trước (không thụt lùi).
  - Chữ đang soạn: bỏ dấu "chao"→"chào" chỉ đọc "à"; xóa lùi "chào"→"chà" đọc "Đã xóa o" (trước đó đọc lại cả từ "chà").
  - **Ô mật khẩu không lộ gì:** vẫn chỉ "Đã nhập ký tự"/"Đã xóa ký tự" (kể cả khi ứng dụng gửi chữ thật), không đọc từ vừa gõ, không báo chữ hoa; `TextEdit.toString()` không in chữ; nhật ký chẩn đoán chỉ ghi cờ và số đếm (dòng `TEXT silent …` khi bật đọc ký tự mà không có gì để đọc).
  - Chuỗi mới `sp_deleted_text` ("Đã xóa %1$s") đủ 8 ngôn ngữ.
- **(1) Không nhập được mã mở khóa sau khi khởi động lại: chưa xác định được nguyên nhân chắc chắn.** Không có máy thật và không có nhật ký của máy bạn nên tôi chỉ đọc được mã. Phân tích ra hai nguyên nhân khả dĩ có thể làm "hoàn toàn không gõ được"; cả hai đã được chặn, và có thêm nhật ký để lần ra nếu còn lỗi:
  1. *Phiên đọc chết lúc máy còn khóa trong khi chế độ "khám phá bằng chạm" của hệ thống vẫn bật.* Cờ này khai tĩnh trong `accessibility_service_config.xml` nên hệ thống bật ngay khi gắn dịch vụ: mọi cú chạm bị giữ lại cho dịch vụ và "chạm hai lần" phải do dịch vụ tự nhấn. Phiên chết = không ai đọc, không ai nhấn.
     - **Chế độ an toàn** (`core/TouchExplorationPolicy.kt`, nối trong `ScreenReaderService.openSession`): không dựng hoặc không khởi động được phiên thì **tắt cờ đó**, màn hình nhận chạm thường (gõ được mã như khi chưa cài trình đọc); phiên chạy được (kể cả dựng lại sau khi máy mở khóa) thì bật lại. Cờ khác của dịch vụ giữ nguyên.
     - `ReaderSession.start()` bọc **13 bước phụ** trong `guardMain` (nhật ký, lớp phủ, cờ dịch vụ, các bộ nhận…): một bước hỏng chỉ mất đúng tính năng đó, không giết cả phiên. Mọi callback của dịch vụ bắt thêm `LinkageError` (khởi tạo tĩnh hỏng lúc máy còn khóa), không chỉ `RuntimeException`.
  2. *Nhấn đúp thất bại rồi "nhấn điều khiển bên cạnh".* Khi nhấn chính phần tử không được, trình đọc thử nhấn nút nằm cạnh nó (dành cho ô tích cạnh dòng chữ). Ở bàn phím số/chữ bên cạnh là **phím khác**: gõ SAI chữ số mà không ai thấy → mã sai, nghe như "không nhập được". Hệ thống còn tạm tắt cờ "bấm được" của phím trong lúc ngón tay đang chạm (để nhập bằng cách nhấc tay), nên nhấn đúp ngay lúc đó dễ thất bại.
     - `ClickTargetPolicy.mayClickNearby`: **không** nhấn bên cạnh khi phần tử là phím (`isKeyboardKey`: phím nhập hoặc cửa sổ bàn phím) hay khi màn hình khóa đang hiện; ở màn hình khóa, nhấn bằng hành động thất bại thì **chạm thật vào giữa phím** (`shouldTapFallback(…, keyguardShowing)`, dùng `KeyguardManager.isKeyguardLocked`). Luật cũ cho web giữ nguyên.
  - **Nhật ký chẩn đoán mới** (chỉ siêu dữ liệu, không có chữ trên màn hình): `ACTIVATE` (kết quả, đường đi, gói, lớp, bấm được/bật) mỗi lần nhấn đúp; `HOVER_KEY` mỗi lần rê qua phím hoặc ở màn hình khóa (gói, lớp, bấm được).
  - **Chưa kiểm chứng trên máy thật.** Nếu sau bản này vẫn không nhập được: nhờ người giúp mở khóa, rồi vào Cài đặt → Công cụ → Nhật ký và hỗ trợ → mục nhật ký chẩn đoán → **Sao chép nhật ký** (và gửi cả nhật ký lỗi cùng trang), kèm hãng/đời máy và loại khóa (PIN, mật khẩu hay hình vẽ), cho biết nhập bằng cách nhấc tay hay chạm hai lần, và có nghe giọng đọc ở màn hình khóa không. Các dòng cần xem: `START` (có `unlocked=false` không), `ACTIVATE`, `HOVER_KEY`, `GESTURE`.
- **(3) Công cụ giọng nói thành danh sách** (Cài đặt → Giọng nói và âm thanh → Giọng nói): "Số công cụ giọng nói", "Công cụ đang cài đặt" (chỉ hiện khi dùng hai công cụ; mặc định **Công cụ thứ nhất**, bấm vào ra hai lựa chọn) và "Đọc theo từ hay theo câu" đều là nút một dòng ghi lựa chọn hiện tại; bấm mở danh sách, chọn xong tự đóng (`SettingPicker`). Trang chỉ hiện phần của công cụ đang chọn (một công cụ: như trước), không còn dài ra vì bày hết mọi phương án. "Công cụ đang cài đặt" chỉ nhớ trong lúc đang ở trang; mỗi lần vào lại là công cụ thứ nhất.
- **(4) Trình đơn thành hai trang** (Cài đặt → Điều khiển): **Trình đơn chung** (chỉ xem: cách mở, 7 mục chính và 7 nhóm với đúng các mục nghe được khi mở) và **Trình đơn hành động nhanh** (sửa được: thêm, xóa, đổi thứ tự, thay chức năng, khôi phục mặc định). Mục "Điều khiển" có 6 trang: Cử chỉ, Cử chỉ theo ứng dụng, Trình đơn chung, Trình đơn hành động nhanh, Chạm và gõ phím, Phím cứng. Tổng cộng **17 trang**. Khóa trang cũ `menus` (đã lưu hoặc liên kết cũ) mở trang Trình đơn hành động nhanh. Chuỗi: bỏ `sec_menus`, `sec_menus_sum`; thêm `sec_menus_general`, `sec_menus_quick` (và hai tóm tắt), `vo2_slot_title`, `vo2_slot_desc`, `vo2_slot_first`, `vo2_slot_second`, `sp_deleted_text`; đổi chữ `mn_title`, `hub_control_sum` và lời nhắc trong trợ giúp.
- **Kiểm thử:** **1036 bài JVM đạt** (bản 2.28.0: 986), cảnh báo biên dịch vẫn 9. Bài mới: `TextEditsTest` (36), `TouchExplorationPolicyTest` (6), thêm vào `ClickTargetPolicyTest` (3) và `DirectBootSourceTest` (4: dịch vụ trả màn hình về chạm thường khi không có phiên, mọi callback bắt `LinkageError`, bước phụ hỏng không giết phiên, nhấn đúp không nhấn phím bên cạnh và chạm dự phòng ở màn hình khóa); `SettingsMenuTest` cập nhật thành 17 trang (thêm 1 bài cho khóa `menus` cũ). **Kiểm đột biến: 53 chỗ cố tình làm hỏng (so văn bản, câu đọc khi xóa, mật khẩu, bộ nhớ ô nhập, phép tính cờ, chính sách nhấn, nối dây trong dịch vụ/phiên/bộ điều hướng), lần đầu bắt 49/53, lọt 4 chỗ (ba bước phụ trong `start()` không bọc `guardMain` và `val key = false`); đã siết bài kiểm thử và chạy lại các chỗ liên quan: bắt hết, tổng 53/53.**
- **Chưa kiểm chứng được ngoại tuyến:** (a) mã giao diện mới (`ui/VoiceScreen.kt`, `ui/MenusScreen.kt`, `ui/AppRoot.kt`, `ui/SettingsIndex.kt`, `ui/SettingsComponents.kt`) — **lần biên dịch đầu tiên là trên CI**; (b) toàn bộ hành vi ở màn hình khóa sau khởi động lại (cần máy thật); (c) cách các bàn phím khác nhau báo sự kiện xóa ký tự (đã kiểm bằng dữ liệu mô phỏng nhiều kiểu, chưa thử trên từng bàn phím).
- **Cách thử trên máy:** (1) gõ "abc" vào ô văn bản rồi bấm xóa: nghe "Đã xóa c"; chọn một từ rồi xóa: nghe "Đã xóa" kèm từ đó; xóa trong ô mật khẩu: chỉ nghe "Đã xóa ký tự"; (2) vào Giọng nói: chọn "Dùng cả hai công cụ", mở "Công cụ đang cài đặt" chọn công cụ thứ hai và chỉnh ngôn ngữ; (3) vào Điều khiển: hai trang trình đơn riêng, tìm "trình đơn" ra cả hai; (4) khởi động lại máy, ở màn hình nhập mã: rê tay nghe tên chữ số rồi nhập (nhấc tay hoặc chạm hai lần theo cài đặt); nếu không được, làm theo mục nhật ký ở trên.
- **Nếu CI đỏ:** lỗi biên dịch trong `ui/` → gửi dòng lỗi, sửa đúng chỗ; hai trang giao diện tách độc lập nên hoàn tác từng phần được (trang giọng nói: `VoiceScreen.kt`; trang trình đơn: `MenusScreen.kt`, `AppRoot.kt`, `SettingsMenu.kt`, `SettingsIndex.kt` và bảng chuỗi). Nhắc lại: thư mục `app/src/main/res/mipmap-anydpi-v26` (nếu còn trên GitHub) nên xóa tay vì tải lên không xóa tệp cũ.

## Bản 2.28.0: nâng Compose 1.13 (BOM 2026.11.01) và Material3 1.5.0, compileSdk 37.1

Yêu cầu: "Vậy hãy làm theo đề xuất của bạn đi" → **đề xuất 4** (nâng Compose BOM), làm thành **bản riêng xếp lên 2.27.0** để nếu CI đỏ thì hoàn tác riêng được mà không mất việc của 2.27.0. **Không đổi dòng mã Kotlin nào**: chỉ 5 tệp (`gradle/libs.versions.toml`, `app/build.gradle.kts`, `.github/workflows/build.yml`, `.github/workflows/release.yml`, `README.md`). **Chưa biên dịch được ở môi trường soạn thảo** (không có Compose, Gradle và Android SDK ở đây), nên **CI là lần biên dịch đầu tiên** của thay đổi này; phần kiểm chứng ở đây là đọc tài liệu chính thức và đối chiếu từng API đang dùng.

- **(1) Compose BOM 2026.09.00 → 2026.11.01.** Theo trang ánh xạ BOM chính thức, 2026.11.01 là bản mới nhất (Compose Runtime/Foundation 1.13.0, Material3 **1.5.0** ổn định; Compose UI 1.13.0 theo ghi chú phát hành). Yêu cầu của bản này, theo bài phát hành tháng 11/2026 và ghi chú Compose UI/Foundation: **Kotlin 2.2 trở lên** (dự án dùng 2.4.21) và **compileSdk 37.1** ("sẽ buộc mọi ứng dụng dùng Compose cập nhật compileSdk"). `lifecycle-runtime` 2.10.0 mà Compose kéo theo thấp hơn bản 2.11.1 của dự án nên không xung đột.
- **(2) compileSdk 37 → 37.1.**
  - 37.1 là **bản nhỏ của API 37** (Android 17 QPR1) nên không viết được thành một số nguyên. Cú pháp theo tài liệu chính thức của Android (có từ AGP 8.13): `compileSdk { version = release(37) { minorApiLevel = 1 } }` (đã chép đúng mẫu `release(36) { minorApiLevel = 1 }` của trang "Set up the Android 16 QPR2 SDK" và tham chiếu `CompileSdkSpec`, chỉ đổi số).
  - AGP 9.5 ghi "hỗ trợ tối đa API 37"; 37.1 vẫn là API 37 nên kỳ vọng không có cảnh báo (nếu có chỉ là cảnh báo, không làm hỏng build).
  - **Máy dựng cần gói "Android SDK Platform 37.1".** Hai lớp bảo đảm: (a) cả hai workflow có thêm bước `sdkmanager "platforms;android-37.1"` **không làm đỏ lượt chạy nếu không cài được** (chỉ báo `::warning::`); (b) AGP tự tải gói còn thiếu khi bản quyền SDK đã được chấp nhận (`android-actions/setup-android` thường đã chấp nhận khi cài). Tên gói `platforms;android-37.1` là suy ra từ cách đặt tên của 36.1; tôi không xác minh được trên trang nào, nên nếu bước này báo cảnh báo mà build vẫn đỏ vì thiếu nền tảng, hãy gửi dòng lỗi để tôi sửa tên gói.
  - **targetSdk giữ 36** (lý do ở "Bản 2.26.0"), minSdk giữ 35.
- **(3) Đối chiếu API đang dùng với ghi chú phát hành** (Compose UI 1.13.0, Foundation 1.13.0, Material3 1.5.0; mã giao diện chỉ dùng API phổ thông: `Text`, `Button`/`OutlinedButton`/`TextButton` và `ButtonDefaults`, `AlertDialog`, `OutlinedTextField`, `Switch`/`SwitchDefaults`, `RadioButton`, `Slider`, `DropdownMenu`/`DropdownMenuItem`, `MaterialTheme`/`darkColorScheme`, `LazyColumn`, `clickable`/`selectable`/`toggleable`/`border`, `semantics`, `imePadding`...).
  - **Không có API nào đang dùng bị gỡ, đổi tên hay nâng lên mức lỗi (ERROR/HIDDEN)** theo các ghi chú đó. Những thay đổi mã nguồn của 1.13 (`Modifier.onFocusedBoundsChanged` bị bỏ phần thực thi, cache window của danh sách lười chuyển vào `LazyColumn`, `LineHeight.Trim` đổi tên, `BasicTextField` kiểu `value/onValueChange` bị deprecated) đều **không được dùng** trong mã này.
  - **Một cảnh báo deprecated đã biết:** Material3 1.5.0 đánh dấu `Slider` kiểu "không giữ trạng thái" (`value` + `onValueChange`) là deprecated để chuyển sang `SliderState`. `LabeledSlider` (`ui/SettingsComponents.kt`) dùng đúng kiểu này nhưng truyền đối số **theo tên** và có `onValueChange` nên vẫn gọi đúng overload cũ: kỳ vọng chỉ thêm một cảnh báo biên dịch (dự án không bật `allWarningsAsErrors`). Ghi chú chỉ nói "deprecated" (chỉ các API thử nghiệm cũ bị `HIDDEN`), nhưng tôi không biên dịch thử được nên đây là suy luận từ tài liệu. **Cố ý chưa chuyển sang `SliderState`:** viết theo API mới mà không biên dịch được vừa rủi ro vừa đổi cách giữ giá trị của các thanh trượt tốc độ/cao độ giọng, nên để khi có kết quả CI.
- **(4) Thay đổi hành vi của Compose 1.13/Material3 1.5.0 đáng biết** (theo ghi chú phát hành, chưa quan sát trên máy thật):
  - `Modifier.clickable` (và nút, hàng bấm được xây trên nó) **tự phát âm thanh chạm của hệ thống**, theo cài đặt "âm thanh chạm" của máy. Chỉ ảnh hưởng màn hình cài đặt của chính ứng dụng; giọng đọc, âm báo và rung của dịch vụ không đổi.
  - **Trợ năng (có lợi):** nút Compose giữ tiêu điểm trợ năng và không chớp khi khám phá bằng cảm ứng; sửa thứ tự duyệt của TalkBack trong nhóm duyệt gộp; làm lại điều hướng bàn phím và tiêu điểm cho `Slider`.
  - `Slider` rời rạc (có `steps`) sửa lỗi mất độ chính xác số thực khi bám vạch, nên giá trị có thể khác rất nhẹ so với trước ở vài mức.
  - `Modifier.border` được viết lại (dùng kích thước viền thống nhất, sửa cả lỗi vẽ viền hình chữ nhật bo góc): khung viền bo góc ở danh sách mục chính (`AppRoot`), trang Cử chỉ và trang Trình đơn nhanh có thể lệch vài điểm ảnh. Văn bản một dòng cũng có thể cao lệch vài điểm ảnh (tối ưu chiều cao dòng mặc định bật).
  - `imePadding` cập nhật đúng khi chuyển tiêu điểm giữa các ô nhập (sửa lỗi).
  - Nội bộ, không đổi API: tra cứu `CompositionLocal` theo yêu cầu (`isMinimalistLocalsEnabled` mặc định bật).
- **(5) Kiểm thử:** mã Kotlin không đổi nên **986 bài JVM** của 2.27.0 giữ nguyên (đã chạy lại trên bản này: đạt, cảnh báo biên dịch vẫn 9). Phần Compose và Gradle chưa kiểm chứng được ngoại tuyến.
- **Cách thử trên máy** (mở màn hình cài đặt của ứng dụng bằng chính trình đọc này hoặc TalkBack): (1) thanh trượt trang Giọng nói và Đọc vẫn đọc "tên: giá trị" và chỉnh được bằng vuốt lên/xuống; (2) hộp thoại chọn ngôn ngữ và danh sách thả xuống ở trang Giọng nói mở được, đọc đúng và đóng được; (3) ô nhập ở trang Thông báo và Tìm chữ: gõ được, bàn phím không che nút; (4) công tắc, nút chọn, nút bấm đọc đúng trạng thái; (5) khung viền vàng bo góc quanh mục đang chọn (danh sách mục chính, trang Cử chỉ, trang Trình đơn nhanh) vẫn thấy rõ ở giao diện tương phản cao.
- **Nếu CI đỏ** (nâng này tách riêng nên hoàn tác chỉ cần **hai dòng**, các tệp workflow có thể để nguyên vì bước cài nền tảng 37.1 vô hại):
  1. `gradle/libs.versions.toml`: `composeBom = "2026.09.00"`.
  2. `app/build.gradle.kts`: thay khối `compileSdk { … }` bằng `compileSdk = 37` (có thể giữ `versionCode = 66`/`"2.28.0"` hoặc đưa về 65/`"2.27.0"`).
  - Phân biệt nguyên nhân nhờ nhật ký: *"Failed to find target with hash string 'android-37.1'"* → máy dựng thiếu nền tảng, xem bước "Cài nền tảng Android 37.1" và gửi dòng lỗi; *lỗi biên dịch trong `ui/`* → gửi dòng lỗi, tôi sửa đúng chỗ (nhiều khả năng ở `SettingsComponents.kt`, `Slider`); *bước lint đỏ nhưng APK vẫn có* → có thể do kiểm tra lint mới đi kèm Compose 1.13, báo cáo lint (`reports`) chỉ rõ từng mục.

## Bản 2.27.0: nhãn và tiện ích về bộ nhớ thường, nối lại giọng đọc ngay khi máy khởi động xong

Yêu cầu: "Vậy hãy làm theo đề xuất của bạn đi" → làm **đề xuất 2** (xử lý `ACTION_LOCKED_BOOT_COMPLETED`) và **đề xuất 3-B** (đưa `custom_labels`/`plugin_prefs` về bộ nhớ thường). Đề xuất 4 (nâng Compose BOM) làm thành **bản riêng 2.28.0** để hoàn tác riêng được. **Chưa thử được trên máy thật**: thứ tự phát tin lúc khởi động, engine giọng đọc thật, Gradle, lint và Compose đều không chạy được ở môi trường soạn thảo; các tệp `ui/` không biên dịch được ở đây nên **CI là lần biên dịch đầu tiên** của chúng (đã rà từng chỗ gọi `CustomLabelStore`, `PluginRegistry`, `DeviceStorage` trong `ui/`, `MainActivity`, `VnApplication`, `LabelEditorActivity`, `ScreenSearchActivity`: không đổi chữ ký nào).

- **(1) Nhãn tự gán và trạng thái tiện ích về bộ nhớ thường (3-B).**
  - Vì sao: bản 2.25.0 đưa cả 6 kho sang bộ nhớ bảo vệ theo thiết bị (device-protected) để dịch vụ chạy được lúc còn khóa. Bộ nhớ đó **không bị khóa bằng mã mở khóa của bạn**, chỉ bằng khóa của máy. Nhãn tự gán cho biết bạn dùng ứng dụng nào và bấm nút nào; trạng thái bật/tắt tiện ích đi kèm script bạn nạp (script đã ở bộ nhớ thường). Trình đọc không cần cả hai ở màn hình nhập mã, nên chúng quay về chỗ được bảo vệ bằng mã mở khóa.
  - Chia kho (`core/StoragePolicy.kt`, nguồn sự thật duy nhất): **bộ nhớ thường** = `custom_labels`, `plugin_prefs`; **bảo vệ theo thiết bị** = `screen_reader_prefs`, `gesture_prefs`, `app_gesture_prefs`, `menu_layout_prefs` (giọng, cử chỉ, bố cục trình đơn: dịch vụ cần ngay lúc khóa). Kho mới thêm vào danh sách mà không khai báo là kho thường thì mặc định ở bộ nhớ bảo vệ theo thiết bị (luôn mở được lúc khóa).
  - Cách chạy:
    - `DeviceStorage.credentialPrefs(...)` trả **null** lúc máy còn khóa (mỗi lần gọi kiểm tra lại, không nhớ kết quả null); `DeviceStorage.prefs(...)` với kho thường lúc khóa **ném `IllegalStateException`** có lời giải thích (ném lỗi rõ ràng tốt hơn trả một kho giả rồi mất dữ liệu).
    - `CustomLabelStore` gắn kho **muộn** (`core/LateBinding.kt`, thuần Kotlin): dựng lúc khóa không mở kho nào, `find` trả null (phần tử được đọc như khi chưa có nhãn nào), `set`/`remove` không làm gì và `set` báo false. `ReaderSession.onUserUnlocked` gọi `bind()` ngay lúc mở khóa. Giao diện (Activity, chỉ chạy sau khi mở khóa) gắn ngay khi tạo. Sau `close()` không mở lại kho (khỏi rò listener của phiên đã bỏ).
    - `PluginRegistry` mở kho **mỗi lần dùng** và chịu được null: lúc khóa **không biết** tiện ích nào đã bị tắt nên coi như **không tiện ích nào bật** (`isEnabled` false, `setEnabled` không làm gì, `runEnabled` rỗng; nơi gọi báo câu "Chưa có tiện ích nào được bật"), tránh chạy nhầm tiện ích bạn đã tắt.
  - Nâng cấp (không mất dữ liệu, chỉ chạy khi máy đã mở khóa, chạy lại bao nhiêu lần cũng cho kết quả như nhau):
    - **Từ 2.24.0 trở về trước** (mọi thứ ở bộ nhớ thường): 4 kho thuộc nhóm bảo vệ theo thiết bị chuyển sang như ở 2.25.0 (không đổi); 2 kho thường **ở yên**.
    - **Từ 2.25.0/2.26.0** (mọi thứ ở bộ nhớ bảo vệ theo thiết bị): 2 kho thường được chuyển **ngược** về bộ nhớ thường ngay sau khi mở khóa (`core/PrefsRelocation.kt` + `StoragePolicy.planMove`, bản chuyển thật do `Context.moveSharedPreferencesFrom` làm: sao chép rồi xóa bản gốc, cả tệp `.xml` lẫn `.xml.bak`). Quy tắc: bản cũ không có → không làm gì; chỉ bản cũ có → **chuyển**; **cả hai nơi đều có** (lần chuyển trước dừng giữa chừng, người dùng đã ghi tiếp ở bộ nhớ thường) → **giữ bản ở bộ nhớ thường, xóa bản cũ**, không bao giờ ghi đè bản mới hơn. Chuyển hỏng (đĩa đầy, lỗi tệp) → dữ liệu ở lại chỗ cũ, ghi nhật ký, lần mở kho sau thử lại. Mỗi kho được xử lý độc lập; nhiều luồng cùng xử lý một kho thì chỉ chuyển một lần.
  - Sao lưu: không đổi (`allowBackup="false"`; `data_extraction_rules.xml` đã loại mọi miền, kể cả `device_*`).
- **(2) Nối lại giọng đọc ngay khi máy khởi động xong (đề xuất 2).**
  - Vấn đề: lúc dịch vụ lên ở màn hình nhập mã mà engine giọng đọc chưa gắn được, bản cũ thử lại theo thang 1 → 2 → 4 → 8 → 16 giây (tổng khoảng 31 giây) rồi mới rơi về engine mặc định. Nếu engine hệ thống chỉ chạy được sau đó vài giây thì người dùng nghe im lặng suốt khoảng chờ. Hệ thống phát `ACTION_LOCKED_BOOT_COMPLETED` đúng lúc máy khởi động xong nhưng chưa mở khóa, khi mọi dịch vụ `directBootAware` (kể cả engine giọng đọc của hệ thống) đã chạy được.
  - Cách làm:
    - `service/BootSignalReceiver.kt`: bộ nhận khai báo `directBootAware="true"` (thiếu cờ này hệ thống không gửi tin cho nó: tin chỉ gửi **một lần**, lúc máy còn khóa), `exported="false"` (tin của hệ thống vẫn tới, ứng dụng khác không gửi giả được), chỉ lọc đúng một action. `onReceive` chỉ gọi `BootSignal.lockedBootCompleted.arrive()`: không đụng bộ nhớ nào, không việc nặng.
    - `core/LockedBootSignal.kt` (thuần Kotlin): chốt nhớ tin giữa bộ nhận và phiên đọc. **Đúng ở cả hai thứ tự**: người nghe gắn trước tin thì được báo khi tin tới; gắn sau tin (phiên dựng xong muộn) thì được báo ngay. Chỉ gắn khi dịch vụ **khởi động lúc còn khóa**; tin **hết hạn khi mở khóa** (`ScreenReaderService.handleUnlocked`), nên phiên dựng lại về sau (dịch vụ nối lại) không bị báo oan; gỡ người nghe của phiên cũ không gỡ nhầm người nghe của phiên mới. Người nghe chạy **ngoài khóa** (gọi ngược vào chốt không tự khóa chết) và mọi ngoại lệ thời gian chạy của nó được bắt và ghi nhật ký, **không bao giờ thoát ra `onReceive`** (lỗi nặng `Error` vẫn đi tiếp).
    - `VoiceEngine.onLockedBootCompleted` + `TtsUnlockPolicy.retryAtLockedBootCompleted(ready, connecting)`: chỉ nối lại khi engine **chưa sẵn sàng và không đang nối** (tức đang chờ hẹn thử lại); khi đó hủy hẹn giờ đang chờ và nối ngay trên luồng chính. Đang sẵn sàng hoặc đang nối thì để yên (không khựng tiếng). Không đổi bộ đếm thất bại: nếu lần nối này cũng hỏng, thang thử lại vẫn đi tiếp như cũ rồi rơi về engine mặc định. `SpeechEngine` chuyển lời gọi cho cả engine chính và engine thứ hai.
    - `AndroidManifest.xml`: thêm quyền `RECEIVE_BOOT_COMPLETED` (loại thường: không hỏi người dùng, không cho đọc dữ liệu nào) và bộ nhận trên.
  - Tác dụng phụ cần biết: hệ thống có thể dựng tiến trình ứng dụng lúc khởi động máy **ngay cả khi dịch vụ trợ năng đang tắt** để giao tin này. Bộ nhận chỉ ghi tin vào RAM (không tin nào được lưu xuống đĩa, không bộ nhớ nào bị mở).
- **(3) Chốt chặn API của bộ công cụ ngoại tuyến** bắt `Intent.ACTION_LOCKED_BOOT_COMPLETED` vì ký hiệu này chưa nằm trong cơ sở đã qua CI. Đã đối chiếu trang tham chiếu chính thức của Android (API công khai từ API 24; cần `RECEIVE_BOOT_COMPLETED` và bộ nhận `directBootAware`) rồi mới thêm vào danh sách đã xác minh; chốt chặn sau đó đạt.
- **(4) Kiểm thử:** **986 bài JVM đạt** (908 ở bản 2.26.0, thêm 78): `LateBindingTest` (12), `LockedBootSignalTest` (17), `PrefsRelocationTest` (15), `StoragePolicyTest` (20) là bốn tệp mới; `TtsUnlockPolicyTest` thêm 3 bài (14); `DirectBootSourceTest` thêm 11 bài quét mã nguồn và manifest (19: bộ nhận riêng tư và đúng quyền; kho thường chỉ mở qua `credentialPrefs` và không mở ở khởi tạo thuộc tính; kho bảo vệ theo thiết bị chỉ mở qua `prefs`; chuyển kho đúng chiều; bộ nhận chỉ ghi tin; người nghe chỉ gắn lúc khóa và gỡ khi đóng...). `ManifestPermissionsTest` cập nhật danh sách quyền. **61 phép đột biến** (cố ý đổi một dòng trong mã chính) đều bị bài kiểm thử bắt, sau khi siết 4 bài lúc đầu để sót (mở kho thường ở thuộc tính đặt tên khác `prefs`; bỏ lời gọi chuyển kho trước khi mở; gọi callback đóng trong khóa; thu hẹp `catch` còn một loại ngoại lệ). Các bài đa luồng chạy lặp 25 lần không lỗi chập chờn; mọi chỗ chờ đều có hạn, hỏng thì thất bại thay vì treo. Cảnh báo biên dịch vẫn 9 như cũ.
- **Cách thử trên máy:**
  1. *Nâng cấp giữ dữ liệu:* cài đè lên bản đang chạy (2.25.0/2.26.0) có sẵn nhãn tự gán và vài tiện ích đã bật. Sau khi mở khóa, nhãn vẫn đọc đúng và tiện ích vẫn bật. Nếu dịch vụ khởi động lúc còn khóa, nhật ký chẩn đoán có `UNLOCK user unlocked: labels bound=true …` (`labels bound=false` nghĩa là kho nhãn chưa mở được lúc đó: hãy gửi dòng này).
  2. *Khởi động lại, chưa mở khóa:* chạm bàn phím số, phải nghe từng số như ở 2.25.0; nếu trước đây có đoạn im lặng đầu tiên thì nay giọng phải tới sớm hơn. Mở khóa rồi xem nhật ký chẩn đoán: dòng `LOCKED_BOOT boot completed while locked: …` cho biết tin đã tới phiên đọc (xuất hiện khi dịch vụ khởi động lúc còn khóa).
  3. *Lúc còn khóa:* phần tử đọc **không** có nhãn tự gán; sau khi mở khóa nhãn áp dụng lại. Đây là chủ ý.
  4. Có gì lạ: gửi các dòng `START`, `LOCKED_BOOT`, `UNLOCK` của nhật ký chẩn đoán.
- **Giới hạn đã biết:**
  1. Chưa thử trên máy thật. Thứ tự hệ thống gắn dịch vụ trợ năng so với lúc phát `LOCKED_BOOT_COMPLETED` tùy máy (thường dịch vụ được gắn trước nên tin tới sau khi phiên đã dựng); cả hai thứ tự đã được xử lý và kiểm thử bằng JVM, nhưng việc thật trên máy chưa quan sát được.
  2. Một số hãng tùy biến Android có thể trì hoãn hoặc không gửi tin này cho ứng dụng chưa mở khóa; khi đó giọng đọc vẫn dùng thang thử lại cũ (31 giây rồi rơi về engine mặc định), không tệ hơn bản trước.
  3. Lúc còn khóa không có nhãn tự gán và không chạy tiện ích (đánh đổi đã chọn vì riêng tư); người dùng đã đặt nhiều nhãn sẽ thấy khác biệt ở màn hình nhập mã so với 2.25.0/2.26.0.
  4. Các mục (1)-(5) của "Giới hạn đã biết" ở bản 2.25.0 vẫn đúng.
- **Nếu CI đỏ:** các tệp mới (`core/LateBinding.kt`, `core/LockedBootSignal.kt`, `core/PrefsRelocation.kt`, `service/BootSignalReceiver.kt` và 4 tệp kiểm thử mới) **không cần xóa** vì tải lên không xóa tệp; còn tệp nào hỏng biên dịch thì trả các tệp đã sửa về bản 2.26.0: `core/StoragePolicy.kt`, `core/DeviceStorage.kt`, `core/CustomLabelStore.kt`, `plugin/PluginRegistry.kt`, `service/ReaderSession.kt`, `service/ScreenReaderService.kt`, `core/VoiceEngine.kt`, `core/SpeechEngine.kt`, `core/TtsUnlockPolicy.kt`, `AndroidManifest.xml` và các kiểm thử `DirectBootSourceTest.kt`, `ManifestPermissionsTest.kt`, `TtsUnlockPolicyTest.kt`. Nếu chỉ một nhóm hỏng thì có thể hoàn tác riêng: nhóm giọng đọc lúc khởi động = `VoiceEngine`, `SpeechEngine`, `TtsUnlockPolicy`, `ReaderSession`, `ScreenReaderService`, manifest + bộ nhận; nhóm kho = `StoragePolicy`, `DeviceStorage`, `CustomLabelStore`, `PluginRegistry`. Hai nhóm đã đan vào nhau ở `ReaderSession` và `ScreenReaderService`, nên hoàn tác một nhóm thì cần đối chiếu hai tệp đó.

## Bản 2.26.0: đóng giọng đọc ở luồng nền, sửa bài kiểm thử hỏng trên CI của bản 2.25.0, nâng công cụ build, rà soát lỗi

Yêu cầu: "Tiếp" (làm đề xuất 1 đã nêu), đồng thời rà soát lỗi và cập nhật công nghệ mới nhất. Đề xuất 2 (xử lý `ACTION_LOCKED_BOOT_COMPLETED`) và 3-B (đưa `custom_labels`/`plugin_prefs` về bộ nhớ thường) **chưa được duyệt nên không làm**. Dữ liệu và cài đặt của người dùng không đổi.

- **(1) Đóng TextToSpeech ở luồng nền.**
  - Nguyên nhân: `TextToSpeech.stop()` và `shutdown()` là lời gọi binder đồng bộ, chờ tiến trình của engine trả lời. Lúc máy vừa khởi động (hoặc engine đang cập nhật, bị tắt) lời gọi này có thể kéo dài hàng chục giây: trình đọc mã nguồn mở Backtalk đo được luồng chính bị chặn 13.958 ms trên một máy, đúng lúc người dùng vừa nhập xong mã mở khóa. Trước đây `VoiceEngine.shutdownQuietly` gọi thẳng trên luồng chính ở 8 chỗ (nối, thử lại, khôi phục, đổi engine, mở khóa, tắt).
  - Cách sửa: lớp thuần Kotlin mới `core/AsyncCloser.kt`. `shutdownQuietly` chỉ xếp việc `stop()` rồi `shutdown()` vào nhóm luồng daemon (tối đa 4 luồng, luồng nhàn rỗi quá 30 giây tự thoát); luồng chính chỉ tốn thời gian xếp việc. Nhiều luồng để một lần đóng bị kẹt không giữ chân các lần đóng khác. Lỗi lúc đóng được ghi nhật ký, không ném ra; bộ thực thi từ chối thì đóng tại chỗ (chậm còn hơn rò rỉ kết nối); lỗi nặng (`Error`) không bị nuốt.
  - Cố ý giữ nguyên: `VoiceEngine.stop()` (ngắt tiếng đang đọc) vẫn đồng bộ vì phải dừng ngay và không nằm trên đường đóng/mở lại engine; `DeviceStorage.migrate` vẫn chạy trên luồng chính vì chỉ là vài lần kiểm tra và đổi tên tệp, đưa sang luồng nền chỉ thêm nguy cơ chạy đua với việc dựng phiên đọc.
- **(2) Sửa bài kiểm thử hỏng trên CI của bản 2.25.0.**
  - Báo cáo CI: bản dựng (APK) đạt nhưng bước kiểm thử + lint đỏ và báo cáo thiếu thư mục `tests/`. Nguyên nhân: `NavigationWindowTest` dùng hằng `AccessibilityWindowInfo.UNDEFINED_WINDOW_ID`; hằng này có trong `android.jar` đầy đủ dùng để kiểm thử ngoại tuyến nhưng **không thuộc SDK công khai**, nên biên dịch kiểm thử trên CI thật báo lỗi. Đã đổi sang giá trị `-1` (kèm chú thích). APK của bản 2.25.0 không bị ảnh hưởng.
  - Chốt chặn mới trong bộ công cụ kiểm thử ngoại tuyến (không nằm trong repo): lấy mọi tham chiếu dạng `LớpAndroid.THÀNH_VIÊN` trong mã chính và test; ký hiệu nào không có trong cơ sở (338 ký hiệu của mã chính bản 2.25.0 đã qua CI) hoặc danh sách đã xác minh thủ công là API công khai thì báo lỗi. Chốt chặn đã bắt đúng lỗi này trên mã chưa sửa. Giới hạn: không bắt phương thức ẩn gọi trên một biến (`node.hidden()`); chỗ đó vẫn do CI thật kiểm.
- **(3) Nâng công nghệ** (báo cáo lint của CI đối chiếu với Google Maven và Gradle chỉ ra bốn bản mới):
  - Gradle 9.9.1 → **9.9.2** (bản vá bảo mật). Checksum SHA-256 `971fcd71…c76b` trong `gradle-wrapper.properties` là kết quả tự tính trên tệp phân phối thật tải từ kho GitHub chính thức của Gradle, khớp từng ký tự với checksum Gradle công bố.
  - AGP 9.5.1 → **9.5.2** và lifecycle-runtime-compose 2.11.0 → **2.11.1** (cả hai là bản vá).
  - **Chưa** nâng Compose BOM 2026.11.01 (Compose 1.13.0, Material3 1.5.0): Compose 1.13 đòi biên dịch với compileSdk **37.1** trong khi dự án dùng 37; nâng BOM mà không đổi compileSdk thì bước kiểm tra siêu dữ liệu AAR (`checkDebugAarMetadata`) làm hỏng bản dựng. Muốn nâng cần đổi compileSdk sang 37.1 (máy dựng phải có nền tảng SDK 37.1) và xử lý thay đổi của Material3 1.5.0; không thử được ở môi trường soạn thảo nên nên làm thành một bản riêng, để nếu CI đỏ chỉ cần hoàn tác vài dòng. **(Đã làm ở bản 2.28.0.)**
  - targetSdk giữ **36**: Android 17 siết "Background audio hardening" (âm thanh, audio focus và lời gọi chỉnh âm lượng của ứng dụng chạy nền bị từ chối nếu không có vòng đời hợp lệ; với ứng dụng nhắm 37 là dịch vụ foreground đang chạy), chưa thử được với dịch vụ trợ năng trên máy thật. Trang "thay đổi cho mọi ứng dụng" của Android 17 không có mục nào chạm tới dịch vụ trợ năng, `TextToSpeech` hay Direct Boot; mã không tự xin audio focus (giọng đọc do engine TTS quản lý) và đọc lại mức âm lượng thật sau khi chỉnh nên không báo sai.
- **(4) Rà soát lỗi** (quét mã phần chính + đọc kỹ `ScreenReaderService`, `DeviceStorage` và đường đóng/mở engine):
  - Không có: `!!`, `runBlocking`, `GlobalScope`, `PendingIntent`, `SharedPreferences.commit()`, `TODO/FIXME`; quyền INTERNET bị gỡ, `allowBackup=false`. Cả 3 bộ nhận phát sóng đều có gỡ đăng ký tương ứng và dùng `RECEIVER_NOT_EXPORTED`. Mọi chỗ gọi `.first()`/`.last()` đều đứng sau điều kiện kiểm tra rỗng; mọi `catch (Exception)` trong coroutine đều ném lại `CancellationException`; `Thread.sleep` duy nhất (`MenuOverlay.awaitHidden`) chạy ở luồng nền và từ chối chạy trên luồng chính.
  - Hai lỗi thật, đều ở phần kiểm thử: (a) bài kiểm thử dùng hằng ẩn (mục 2); (b) `AsyncCloserTest` có thể **treo** thay vì thất bại nếu ai đó đổi `close()` thành chạy đồng bộ (phát hiện nhờ phép đột biến, đã sửa cho chờ có hạn).
  - Không tìm thấy lỗi thời gian chạy chắc chắn nào trong mã ứng dụng. Quét mã không thay được thử trên máy thật.
- **Kiểm thử:** 908 bài JVM đạt (895 ở bản 2.25.0, thêm 13): `AsyncCloserTest` (12 bài) và 1 bài quét mã trong `DirectBootSourceTest` (việc đóng TextToSpeech chỉ đi qua `AsyncCloser`). 10 phép đột biến (cố ý đổi một dòng ở `AsyncCloser`/`VoiceEngine`) đều bị bài kiểm thử bắt. Chưa chạy được ở môi trường soạn thảo: Gradle, lint, Compose, máy thật.
- **Nếu CI đỏ:** (1) lỗi biên dịch ở `AsyncCloser.kt`/`VoiceEngine.kt` → hoàn tác 2 tệp đó cùng `AsyncCloserTest.kt`; (2) lỗi tải Gradle hoặc plugin → trả `gradle-wrapper.properties` về Gradle 9.9.1 (checksum cũ `d8a18a7a…a228`) và `libs.versions.toml` về `agp = "9.5.1"`, `lifecycle = "2.11.0"`.

## Bản 2.25.0: vuốt trong bàn phím (biểu tượng cảm xúc, bộ nhớ tạm), nhập bằng giọng nói, đọc hai lần ở vùng thông báo, chạy trước khi mở khóa

Yêu cầu: (1) mở bàn phím, vào bảng biểu tượng cảm xúc hoặc bộ nhớ tạm thì vuốt nhảy sang dòng khác của ứng dụng thay vì đi tiếp trong bảng; (2) chạm nút nhập bằng giọng nói của bàn phím thì không ghi âm và không hiện chữ vào ô nhập; (3) các dòng trong vùng thông báo bị đọc hai lần khi chạm, đáng lẽ một lần rồi thôi khi nhấc tay; (4) sau khi tắt nguồn rồi bật lại, trình đọc không chạy khi máy chưa mở khóa, trong khi các trình đọc khác (bộ đọc hỗ trợ Android và các trình đọc lớn) vẫn chạy. **Chưa thử được trên máy thật** (xem "Giới hạn đã biết" ở cuối mục): bàn phím thật, vùng thông báo thật, bộ nhận dạng giọng nói, khởi động lại máy, giọng đọc thật đều không chạy được trong môi trường dựng của mình; phần giao diện Compose vẫn không biên dịch được ở đây nên **CI là lần biên dịch đầu tiên** của phần nằm ngoài lõi (mọi tệp `core/` và `service/` đã biên dịch với android.jar và chạy kiểm thử JVM).

- **(1) Vuốt trong bảng biểu tượng cảm xúc và bộ nhớ tạm.**
  - Nguyên nhân (đọc mã, đã đối chiếu cách Android quản lý cửa sổ): bảng này nằm trong **cửa sổ của bàn phím**, không phải cửa sổ ứng dụng. Chạm vào bàn phím thì nó là cửa sổ "đang hoạt động", nhưng **nhấc ngón tay lên là Android trả "cửa sổ đang hoạt động" về cửa sổ ứng dụng**. Vuốt kế tiếp tìm phần tử kế trong cây của cửa sổ ứng dụng, mà phần tử đang chọn lại thuộc bàn phím nên không tìm thấy vị trí; thế là tiêu điểm nhảy sang một dòng nào đó của ứng dụng.
  - Cách sửa: `core/NavigationWindow.kt` (thuần Kotlin) và `FocusNavigator.navigationRoot()`. Nếu phần tử đang chọn thuộc **cửa sổ khác** cửa sổ hoạt động và cửa sổ đó **còn mở** thì vuốt, cuộn, nhảy theo vị trí đều duyệt trong cửa sổ đó (lấy qua `getWindows()`). Danh sách phần tử lưu tạm nay gắn với cửa sổ, đổi cửa sổ thì không dùng lại. Cửa sổ của phần tử đã đóng (bàn phím thu lại) thì quay về cửa sổ ứng dụng như cũ.
  - Có chủ ý **không** đổi `passwordBounds()` (vùng mật khẩu để che khi chụp màn hình hoặc OCR vẫn lấy theo cửa sổ ứng dụng): đổi sẽ làm sót ô mật khẩu của ứng dụng.
  - Nhật ký chẩn đoán: `WINDOW follow selected element into window=… base=…` (chỉ ghi khi bắt đầu theo một cửa sổ mới, không ghi mỗi lần vuốt).
- **(2) Nhập bằng giọng nói của bàn phím.**
  - **Nguyên nhân chưa xác định được chắc chắn.** Giả thuyết mạnh nhất: tiếng đọc của trình đọc (tên nút micro, tên ô nhập, chữ vừa hiện) **lọt vào micro** đúng lúc bộ nhận dạng nghe, nên bản thu bị nhiễu hoặc bị cắt ngang, chữ không hiện.
  - Cách làm: khi bàn phím đang mở và **một ứng dụng khác đang thu âm bằng nguồn giọng nói** (mặc định, micro, nhận dạng giọng nói, không xử lý), trình đọc **im lặng hoàn toàn**: giọng, âm báo; rung vẫn giữ. Hết thu thì im thêm 0,7 giây rồi đọc lại **một lần** phần chữ vừa nhập (tối đa 300 ký tự cuối). Có van an toàn: im tối đa 120 giây một lần thu. Không cần quyền ghi âm, không biết ứng dụng nào đang thu và không ghi gì về nội dung (`core/DictationGate.kt`, thuần Kotlin).
  - Không im khi: không có bàn phím mở (ứng dụng ghi âm chạy nền), bản thu bị hệ thống câm, hoặc nguồn là cuộc gọi, video, nghe từ khóa chạy ngầm.
  - Nhật ký: `MIC recordings=… counted=… sources=…` (số bản thu, số bản được tính, mã nguồn âm) và `MIC mute on|off`.
  - **Có thể nguyên nhân không nằm ở trình đọc:** nếu sau bản này nút micro vẫn không ghi chữ, hãy kiểm tra bàn phím đã được cấp quyền micro chưa và dịch vụ nhận dạng giọng nói của máy có bật không. Khi đó dòng `MIC … counted=0` trong nhật ký cho biết sửa đổi này không hề kích hoạt, hãy gửi dòng đó để tôi biết bàn phím của bạn báo nguồn âm nào.
- **(3) Đọc hai lần ở vùng thông báo.**
  - Nguyên nhân: chạm vào một dòng làm hệ thống gửi sự kiện "chạm vào" cho phần tử con, rồi tiếp cho **phần tử chứa nó** (dòng thông báo bấm được) vài mili giây sau. Hai sự kiện của hai phần tử khác nhau nên bộ chống lặp (`HoverEchoGuard`) chỉ so cùng phần tử không bắt được: một lần đọc dòng, một lần đọc cả cụm.
  - Cách sửa: trong 250 ms sau khi đọc một phần tử, sự kiện chạm của phần tử **chứa** nó bị bỏ (phần tử con thắng); vẫn bỏ cả sự kiện lặp của chính phần tử đó như cũ. Chạm sang phần tử khác không bị chặn. Chạm có độ trễ (cài đặt độ trễ chạm) đi đường cũ, không đổi.
  - Nhật ký: dòng tổng kết `HOVER` có đếm các lần bị bỏ vì lặp.
- **(4) Chạy trước khi mở khóa (Direct Boot).** Người khiếm thị cần nghe trình đọc ngay ở màn hình nhập mã sau khi khởi động lại, nếu không thì không tự nhập được mã mở khóa.
  - **Nguyên nhân 1 (chắc chắn về cơ chế):** dịch vụ không khai báo `android:directBootAware="true"`. Thiếu cờ này, hệ thống **không gắn dịch vụ** cho tới khi người dùng mở khóa lần đầu sau khởi động; các trình đọc khác khai báo cờ nên chạy ngay ở màn hình nhập mã.
  - **Nguyên nhân 2:** nếu chỉ thêm cờ thì vẫn hỏng. Lúc đó **bộ nhớ thường (credential-protected) còn bị khóa** nên mở `SharedPreferences` ở đó làm Android ném `IllegalStateException`; phiên đọc dựng cài đặt ngay khi tạo nên không dựng được, dịch vụ "nối vào mà câm". Nhật ký lỗi và nhật ký chẩn đoán cũng nằm ở bộ nhớ khóa.
  - **Nguyên nhân 3 (phụ):** engine giọng đọc bên thứ ba thường không chạy được trước khi mở khóa. Bản cũ chờ khoảng 31 giây thử lại rồi mới rơi về engine mặc định kèm câu "Engine giọng đọc đã chọn không dùng được. Đang dùng engine mặc định." Trong lúc đó không nghe gì.
  - Cách sửa:
    - `AndroidManifest.xml`: `ScreenReaderService` thêm `android:directBootAware="true"`. **Chỉ** dịch vụ (Activity không cần; có bài kiểm thử giữ điều này).
    - `core/DeviceStorage.kt` và `core/StoragePolicy.kt`: toàn bộ **6 kho cài đặt** (cài đặt chung, cử chỉ, cử chỉ riêng theo ứng dụng, nhãn tự gán, bố cục trình đơn, bật/tắt tiện ích) cùng **nhật ký lỗi và nhật ký chẩn đoán** chuyển sang bộ nhớ bảo vệ theo thiết bị (device-protected), mở được ngay khi máy khởi động xong. Dịch vụ nhờ đó dựng phiên ngay lúc khóa và đọc đúng tốc độ, giọng, cử chỉ bạn đã chọn. **(Từ bản 2.27.0 chỉ còn 4 kho ở đây: nhãn tự gán và bật/tắt tiện ích đã về bộ nhớ thường, xem "Bản 2.27.0".)**
    - **Nâng cấp từ bản cũ tự chuyển dữ liệu** (không mất cài đặt): `VnApplication` chuyển ngay khi tiến trình khởi động mà máy đã mở khóa (`moveSharedPreferencesFrom`, `FileMigration`). Nếu tiến trình khởi động lúc còn khóa thì chuyển ngay sau khi mở khóa.
    - Script tiện ích do bạn nạp (JSON) **vẫn ở bộ nhớ thường**, nên lúc còn khóa chỉ có tiện ích dựng sẵn; script dùng được sau khi mở khóa.
    - `ScreenReaderService`: nếu được gắn lúc khóa thì đăng ký nghe `ACTION_USER_UNLOCKED` (đăng ký trước, kiểm tra lại sau, không lỡ tin). Khi mở khóa: dựng lại phiên nếu lúc khóa chưa dựng được (hoặc vừa chuyển dữ liệu cũ), không thì báo cho giọng đọc.
    - Giọng đọc (`core/TtsUnlockPolicy.kt`, `VoiceEngine.onUserUnlocked`): engine bạn chọn chưa gắn được lúc khóa thì **đọc tạm bằng engine hệ thống ngay**, im lặng, không chờ thử lại và không đọc câu "engine không dùng được" (lúc này đó là bình thường). Khi mở khóa **nối lại đúng engine đã chọn**; câu mới nhất đang chờ vẫn được đọc. Đang đọc đúng engine thì để yên, không khựng tiếng lúc mở khóa. Lúc khóa **không nhắc "thiếu giọng"** (dữ liệu giọng có thể còn ở bộ nhớ khóa); sau khi mở khóa giọng được kiểm tra lại.
    - `data_extraction_rules.xml`: loại các miền `device_root`, `device_file`, `device_database`, `device_sharedpref` khỏi sao lưu và chuyển máy (khớp `allowBackup="false"`).
  - **Riêng tư:** bộ nhớ bảo vệ theo thiết bị **không bị khóa bằng mã mở khóa của bạn**, chỉ bằng khóa của máy. Vì vậy chỉ để cài đặt và nhật ký không nhạy cảm: không mật khẩu, không nội dung màn hình (nhật ký chẩn đoán vẫn không ghi chữ trên màn hình), không script. Có bài kiểm thử quét mã nguồn để không ai mở kho nào ở bộ nhớ thường mà quên chuyển, và để mọi tên kho đều nằm trong `StoragePolicy`.
  - Nhật ký: dòng `START … unlocked=true|false` cho biết dịch vụ khởi động lúc đã hay chưa mở khóa; `UNLOCK …` ghi khi nhận tin mở khóa.
- **Cách thử trên máy:**
  1. *Vuốt trong bàn phím:* mở một ô nhập, mở bảng biểu tượng cảm xúc, vuốt phải rồi trái: tiêu điểm đi tiếp từng biểu tượng. Làm tương tự với bộ nhớ tạm của bàn phím (các đoạn đã sao chép).
  2. *Nhập giọng nói:* chạm nút micro trên bàn phím, nói một câu: trong lúc thu không nghe gì từ trình đọc; xong thì chữ hiện ở ô nhập và trình đọc đọc lại phần vừa nhập một lần.
  3. *Vùng thông báo:* kéo thanh thông báo xuống, đặt ngón tay lên một dòng rồi nhấc lên: nghe đúng một lần.
  4. *Direct Boot:* đặt khóa màn hình bằng mã PIN, **khởi động lại máy và chưa mở khóa**. Chờ vài giây rồi chạm vào bàn phím số: phải nghe từng số. Nhập mã, mở khóa, rồi vào **Nhật ký chẩn đoán**: tìm dòng `START … unlocked=false` (dịch vụ đã chạy lúc khóa) và `UNLOCK …`.
  5. Có gì lạ thì để Nhật ký chẩn đoán bật (mặc định bật), làm lại đúng thao tác đó, bấm **Sao chép nhật ký** và gửi các dòng `WINDOW`, `MIC`, `HOVER`, `START`, `UNLOCK`.
- **Kiểm thử:** 895 bài JVM đạt (825 ở bản 2.24.0, thêm 70): `NavigationWindowTest` (6 bài: chọn cửa sổ để duyệt), `HoverEchoGuardTest` (7 bài mới: bỏ sự kiện của phần tử chứa, không chặn phần tử khác, hết cửa sổ thời gian thì đọc), `DictationGateTest` (29 bài, gồm cổng im lặng và đọc lại chữ vừa nhập), `FileMigrationTest` (10 bài: chuyển tệp trong thư mục tạm, giữ bản mới ở đích, chạy lại không đổi, không mất tệp khi lỗi), `TtsUnlockPolicyTest` (11 bài) và `DirectBootSourceTest` (7 bài quét mã nguồn và manifest). Phần cần máy thật **không kiểm thử được**: sự kiện cửa sổ và chạm của bàn phím và thanh thông báo, bộ nhận dạng giọng nói, hành vi Direct Boot, engine giọng đọc thật.
- **Giới hạn đã biết:**
  1. Chưa thử trên máy thật, cả bốn mục. Sửa (1) và (3) dựa trên cách Android làm việc chứ không phải quan sát lỗi thật; sửa (2) là giảm nhiễu chứ chưa chắc là nguyên nhân (xem trên).
  2. (1) cần bàn phím cho phép đọc cây phần tử của bảng biểu tượng cảm xúc. Nếu bàn phím trả về cây rỗng hoặc vẽ bảng không qua hệ thống trợ năng thì vẫn không vuốt được; gửi dòng `WINDOW` kèm tên bàn phím.
  3. (2) Mã nguồn âm mà bộ nhận dạng của từng bàn phím báo chưa biết trước: đã tính mặc định, micro, nhận dạng giọng nói, không xử lý. Nguồn khác (ví dụ cuộc gọi, nghe từ khóa) bị loại có chủ ý.
  4. (4) Một số hãng tùy biến Android có thể chặn dịch vụ chạy sớm hoặc dùng quy trình khởi động riêng; tôi không kiểm chứng được. Engine giọng đọc mà dữ liệu giọng tiếng Việt nằm ở bộ nhớ khóa của nó thì lúc khóa có thể đọc bằng giọng khác ngôn ngữ cho tới khi mở khóa; ứng dụng này không điều khiển được việc đó. Màn hình khóa dùng cử chỉ hoặc cửa sổ hệ thống đặc biệt có thể cư xử khác từng máy.
  5. Lúc khóa **không có** script tiện ích do bạn nạp, đọc chữ trong ảnh (OCR) và mô tả hình ảnh có thể báo lỗi (thư viện ML Kit nạp sau khi mở khóa), và các màn hình của ứng dụng (Activity) không mở được: đó là giới hạn của Android với thành phần không hỗ trợ Direct Boot, có chủ ý.
- **Quyết định cần bạn xem:** (a) im lặng cả âm báo khi nhập giọng nói tối đa 120 giây một lần thu (đổi một hằng số nếu bạn muốn khác); (b) lúc khóa đọc tạm bằng engine hệ thống nếu engine bạn chọn chưa dùng được, thay vì im; (c) cài đặt (không nhạy cảm) nằm ở bộ nhớ bảo vệ theo thiết bị: nếu bạn muốn giữ chúng ở bộ nhớ thường thì trình đọc sẽ không chạy được lúc khóa. Cả ba có thể đổi nếu bạn báo.

## Bản 2.24.0: báo bật/tắt màn hình luôn bật (bỏ công tắc), tắt màn hình thì không đọc thông báo, rà lỗi tồn đọng

Yêu cầu (làm một lần trong một bản): (1) đưa phần báo bật/tắt màn hình vào mặc định và xóa công tắc cho bớt rườm rà; (2) khi tắt màn hình thì không đọc thông báo đến; (3) kiểm tra còn lỗi tồn đọng nào không rồi sửa. **Chưa thử được trên máy thật**: thứ tự broadcast bật/tắt màn hình so với các sự kiện hệ thống, việc hỏi trạng thái nguồn của máy và phát giọng không chạy được trong môi trường dựng của mình. Phần giao diện (`ui/NotificationScreen.kt`) chỉ là xóa một khối công tắc, nhưng Compose vẫn không biên dịch được ở đây nên **CI là lần biên dịch đầu tiên**.

- **Luôn bật, không còn công tắc.**
  - Bật màn hình: đọc giờ hiện tại ("Bây giờ là 15 giờ 28 phút"). Tắt màn hình: "Đã tắt màn hình". Giống bản 2.20.6, chỉ khác là không ai phải bật.
  - Mặc định trước đây là TẮT, nên **người đang dùng từ trước sẽ nghe lời báo này ngay sau khi cập nhật**, kể cả khi trước đó đã để tắt.
  - Đã xóa: công tắc ở trang Thông báo và sự kiện, `SettingsRepository.announceScreen`, hai chuỗi `rd_screen_title`/`rd_screen_desc` (cả 8 ngôn ngữ) và mục trong chỉ mục tìm kiếm. Tiêu đề nhóm ở trang đó nay là "Cuộc gọi và vị trí"; tóm tắt của menu bỏ "bật tắt màn hình".
  - Khóa `announce_screen` còn nằm lại trong cài đặt đã lưu trên máy: vô hại, không còn mã nào đọc. Tệp sao lưu của bản cũ có khóa này thì khi nhập bị bỏ qua **lặng lẽ** (`BackupSchema.isRetired`, không tính vào số mục "bị bỏ qua"); tệp sao lưu mới không còn ghi nó.
- **Đang đổ chuông hoặc trong cuộc gọi: im lặng cả hai chiều (đổi).** Trước đây "Đã tắt màn hình" vẫn được đọc trong cuộc gọi vì công tắc mặc định tắt. Nay tính năng luôn bật mà áp điện thoại lên tai làm cảm biến tiệm cận tắt màn hình (rời tai thì bật lại), nên nếu giữ nguyên thì mỗi cuộc gọi đều nghe "Đã tắt màn hình" ngay bên tai. Cách nhận biết giống cũ: chế độ âm thanh khác bình thường (đổ chuông, cuộc gọi, gọi qua mạng). Nếu bạn vẫn muốn nghe lời này trong cuộc gọi, báo lại, chỉ đổi một chỗ.
- **Tắt màn hình thì không đọc thông báo.**
  - Hệ thống gửi sự kiện thông báo **ngay lúc nó được đăng**, kể cả khi màn hình đang tắt, nên trước đây thông báo đến lúc tắt màn hình (đang nghe nhạc, bỏ túi) vẫn bị đọc to. `NotificationRules.shouldRead` nay có tham số `screenOn` và kiểm tra nó **trước mọi luật khác**: màn hình tắt thì không đọc, kể cả thông báo chứa từ khóa "luôn đọc" (mã OTP, ngân hàng...). Khi màn hình tắt, hệ thống cũng không bị tra ngữ cảnh (đang gọi, không làm phiền...).
  - Thông báo bỏ lỡ lúc tắt màn hình **không được đọc bù** khi bật lại, và cũng không ghi vào bộ nhớ chống trùng, nên thông báo gửi lại sau đó vẫn được đọc.
  - **Toast** cũng vậy (`NotificationRules.shouldReadToast`: công tắc đọc thông báo nổi VÀ màn hình bật).
  - Trạng thái màn hình lấy từ `PowerManager.isInteractive` ngay lúc xử lý sự kiện, không dựa vào cờ do broadcast đặt nên không lệch nếu lỡ một broadcast. Màn hình khóa nhưng đang sáng vẫn là "bật", nên vẫn đọc thông báo. Không hỏi được hệ thống thì coi là bật (thà đọc thừa còn hơn im nhầm với người không nhìn thấy màn hình).
  - **Không đổi:** lời báo người gọi (đi đường riêng, bằng broadcast trạng thái điện thoại) vẫn đọc khi màn hình tắt; lời "ứng dụng chủ động báo" (`TYPE_ANNOUNCEMENT`) và vùng thông báo trực tiếp không bị chặn.
  - **Quyết định cần bạn xem:** luật cứng này ghi đè cả danh sách "Từ khóa luôn đọc". Nếu bạn muốn từ khóa luôn đọc vẫn được đọc lúc tắt màn hình (ví dụ mã OTP khi điện thoại trong túi), báo lại; chỉ đổi một dòng.
- **Lỗi tồn đọng đã sửa** (tìm trong lúc làm):
  1. **Lời đọc giờ bị cắt giữa chừng** (giới hạn đã biết từ 2.20.6): màn hình khóa hiện ra ngay sau khi bật màn hình và đọc tiêu đề cửa sổ cùng tiêu điểm đầu tiên theo cách ngắt lời, nên câu giờ chỉ còn vài âm đầu. Nay `core/SpeechShield.kt` (thuần Kotlin, có kiểm thử) giữ câu vừa báo (cả giờ lẫn "Đã tắt màn hình") tối đa 6 giây: trong lúc đó lời **tự động** (tiêu đề cửa sổ, tiêu điểm do hệ thống tự đặt) xếp hàng sau thay vì ngắt. Cử chỉ, chạm và phím của bạn không đi qua bộ này và luôn ngắt ngay. Hết 6 giây, hoặc khi giọng đã đọc xong, mọi thứ như cũ.
  2. **Mở trình đơn rồi tắt màn hình:** trước đây trình đơn (và lớp danh sách chạm được của 2.23.0) vẫn mở khi bật lại, nằm trên màn hình khóa, rồi 30 giây sau tự đóng kèm lời "Đã đóng trình đơn" giữa lúc đang dùng. Nay đổi trạng thái màn hình (tắt hoặc bật) đóng trình đơn **im lặng**: hủy hẹn giờ đóng và gỡ lớp phủ.
  3. **Việc chờ độ trễ chạm** (`hoverJob`) không bị hủy khi màn hình đổi trạng thái, nên một lần chạm sát lúc tắt có thể đọc sau khi đã tắt. Nay hủy cùng với việc chuyển tiêu điểm và việc AI.
  4. **Tiêu đề cửa sổ và việc hẹn đọc phần tử đầu/phần tử nhớ lúc màn hình tắt:** vẫn cập nhật trạng thái như cũ nhưng không đọc và không hẹn đọc, để không nói chồng lên "Đã tắt màn hình".
  5. **Tệp sao lưu cũ có khóa đã bỏ** không còn làm tăng số mục "bị bỏ qua" (xem trên).
  6. **Nhật ký chẩn đoán** có hai dòng mới: `SCREEN on|off said=true|false inCall=true|false menuClosed=true|false` và `NOTIF screenOn=true|false allowed=true|false` (chỉ hai giá trị đúng/sai, **không ghi nội dung hay tên ứng dụng của thông báo**).
- **Chuỗi dịch:** xóa 2 chuỗi, sửa 5 chuỗi (`sec_notif_sum`, `nt_events_head`, `rd_notif_desc`, `rd_toast_desc`, `nt_white_desc`: nay nói rõ "không đọc khi màn hình tắt"); cả 8 ngôn ngữ, còn 728 mục (714 chuỗi và 14 `<plurals>`). **Bản dịch ngoài tiếng Việt và tiếng Anh do máy dịch**, chưa người bản ngữ duyệt. Chuỗi sinh tự động vẫn sửa trong `tools/i18n/table_*.py` rồi chạy `python3 -I tools/i18n/gen.py .`.
- **Kiểm thử:** 825 bài JVM đạt (814 trước đó). `ScreenAnnouncementTest` viết lại (bỏ bài của công tắc, thêm "im lặng cả hai chiều khi đổ chuông hoặc trong cuộc gọi"); `NotificationRulesTest` thêm 4 bài (màn hình tắt chặn mọi thứ kể cả "luôn đọc"; không tra ngữ cảnh hệ thống khi màn hình tắt; Toast); `SpeechShieldTest` 6 bài mới (đúng ranh giới thời gian, không bảo vệ khi không đang đọc, bảo vệ lại thì tính lại từ mốc mới); `SettingsBackupTest` thêm 3 bài (khóa cũ bỏ lặng lẽ, dòng hỏng vẫn được đếm). Việc nghe broadcast, hỏi `PowerManager`, phát giọng và lớp phủ **không kiểm thử được ngoài máy thật**.
- **Cách thử trên máy:** (1) bấm nút nguồn: nghe "Đã tắt màn hình"; bấm lại: nghe giờ đầy đủ rồi mới tới tên màn hình khóa. (2) Tắt màn hình, nhờ người gửi một tin: không nghe gì; bật màn hình rồi gửi tiếp: nghe như thường. (3) Mở trình đơn, tắt rồi bật màn hình: trình đơn đã đóng, không có lời nào. (4) Gọi điện, áp lên tai: không nghe "Đã tắt màn hình". Có gì lạ thì bật Nhật ký chẩn đoán, làm lại đúng thao tác đó, bấm **Sao chép nhật ký** và gửi các dòng `SCREEN`, `NOTIF`, `WINDOW`.
- **Giới hạn đã biết:** (1) thứ tự sự kiện lúc bật màn hình do hệ thống quyết định; nếu câu giờ vẫn bị cắt thì báo kèm tên máy, kiểu khóa màn hình và dòng `SCREEN`. (2) Nếu có máy nào báo sai "không tương tác" trong khi bạn đang dùng, tiêu đề cửa sổ và thông báo sẽ im; chưa gặp và không kiểm chứng được. (3) Khi trình đơn đang mở, chạm hai ngón (`STOP_SPEECH`) vừa dừng đọc vừa đóng trình đơn; giữ nguyên vì có thể là chủ ý.

## Bản 2.23.0: trình đơn của dịch vụ chạm và lướt ngón tay được, ngôn ngữ giọng nói thành danh sách, bỏ "Kiểm tra cử chỉ"

Yêu cầu (làm một lần trong một bản): (1) ở ngoài màn hình mọi mục đọc rất tốt, nhưng trong trình đơn của dịch vụ vuốt qua lại thì đọc còn chạm và rê ngón tay thì **im lặng**; (2) các ngôn ngữ trong Công cụ giọng nói bày giữa màn hình quá rườm rà, nên gom thành danh sách trong một menu con; (3) bỏ phần Kiểm tra cử chỉ. Kèm theo vài cải tiến nhật ký chẩn đoán và lời đọc của nhóm, rút ra sau khi đọc nhật ký bạn gửi (nhật ký bị khung chat cắt ở khoảng 20.000 ký tự, trong phần nhìn thấy không có lỗi nào của phần đọc ở ngoài màn hình).

**Chưa thử được trên máy thật.** Lớp danh sách phủ màn hình (`service/MenuOverlay.kt`) và trang Giọng nói (`ui/VoiceScreen.kt`, `ui/SettingsComponents.kt`) không chạy được trong môi trường dựng của mình. Điều chưa biết chắc: trên máy của bạn hệ thống có chuyển sự kiện lướt ngón tay vào lớp phủ đúng như tài liệu hay không. Cách kiểm tra: bật **Nhật ký chẩn đoán**, mở trình đơn rồi chạm và lướt ngón tay; dòng `MENU_OVERLAY shown rows=N` cho biết lớp đã hiện, dòng `MENU touch row=i/N` cho biết mỗi lần chạm tới đúng hàng. Có dòng `shown` mà không có dòng `touch` nghĩa là hệ thống không chuyển sự kiện vào lớp: gửi nhật ký để sửa. Nếu CI báo lỗi ở `ui/`, gửi nội dung lỗi.

- **Nguyên nhân im lặng khi chạm.** Khi trình đơn mở, nó chỉ là trạng thái trong bộ nhớ của dịch vụ, không có gì trên màn hình để chạm vào; còn sự kiện lướt ngón tay của ứng dụng nằm bên dưới thì cố ý bị bỏ qua lúc trình đơn đang mở (để chạm nhầm không làm đổi mục chọn). Kết quả: vuốt thì đọc, chạm thì im.
- **Cách sửa: trình đơn cũng là một danh sách thật trên màn hình.** Khi trình đơn mở, dịch vụ vẽ nó thành danh sách phủ toàn màn hình (cửa sổ `TYPE_ACCESSIBILITY_OVERLAY` nhận chạm; nền gần đen, chữ trắng, mục đang chọn tô vàng chữ đen, cùng bảng màu tương phản cao của màn hình cài đặt):
  - Chạm hoặc lướt ngón tay tới hàng nào thì chọn và đọc hàng đó, đúng câu khi vuốt ("tên, i trên N"). Rê trong cùng một hàng không đọc lặp; nhấc ngón rồi chạm lại thì đọc lại.
  - Chạm hai lần thực hiện **mục đang chọn** (mục vừa nghe). Vuốt phải/trái/xuống/lên, quay lại, đóng trình đơn giữ nguyên như trước; vuốt chuyển mục thì hàng được tô theo.
  - Các hàng chia đều toàn bộ chiều cao màn hình, mỗi hàng cao tối thiểu 56 dp. Trình đơn dài hơn số hàng vừa màn hình (trình đơn phần tử có thể tới khoảng 33 mục) thì hiện một "cửa sổ" hàng và tự cuộn theo mục đang chọn.
  - Lớp được gỡ **trước** khi chạy chức năng: dịch vụ chờ luồng chính gỡ xong (tối đa 250 ms) rồi thêm khoảng 48 ms cho hệ thống cập nhật danh sách cửa sổ nhận chạm. Lý do: nhiều chức năng (nhấn bằng toạ độ, nhấn giữ, cuộn, chuyển trang) phát cử chỉ chạm giả lập; nếu lớp còn nằm trên cùng thì chạm đó rơi vào lớp chứ không tới ứng dụng bên dưới. Chụp màn hình cho OCR và mô tả hình ảnh cũng chỉ xảy ra sau khi lớp đã gỡ.
  - Sự kiện "đổi cửa sổ" do chính lớp này tạo ra không bị coi là màn hình mới nên trình đơn không tự đóng khi vừa mở.
  - Hệ thống từ chối thêm cửa sổ thì trình đơn quay về hành vi cũ, nhưng chạm vào màn hình sẽ **đọc lại mục đang chọn** (tối đa một lần mỗi 1,5 giây) thay vì im lặng.
  - Mã: `menu/MenuTouchMap.kt` (hình học thuần Kotlin, có kiểm thử), `MenuState.select(position)` (chọn thẳng một mục, giữ nguyên danh sách, trình đơn cha và thứ tự), `service/MenuOverlay.kt` (cửa sổ và vẽ), `ReaderSession` (nối chạm với trình đơn).
- **Báo "nhóm".** Khi bật **Đọc hướng dẫn thao tác**, mục mở một nhóm được đọc "Đọc, nhóm, 1 trên 14" (trước chỉ "Đọc, 1 trên 14"), và khi vào nhóm dịch vụ đọc tên nhóm cùng số mục ("Duyệt nhanh, 12 mục.") trước mục đầu để biết mình vừa vào đâu. Tắt gợi ý thì chỉ đọc tên mục như trước.
- **Ngôn ngữ giọng nói thành danh sách.** Trang **Giọng nói (TTS)**: mỗi lựa chọn ngôn ngữ chỉ còn tiêu đề, mô tả và **một nút** ghi lựa chọn hiện tại (đọc "Ngôn ngữ của công cụ thứ nhất: Tiếng Việt"). Chạm vào mở hộp thoại danh sách cuộn được, mỗi hàng là một nút chọn đọc "tên, đang chọn/không chọn", chọn xong hộp thoại tự đóng, có nút Hủy. Áp dụng cho ngôn ngữ công cụ thứ nhất (có mục "Theo ngôn ngữ ứng dụng", 12 ngôn ngữ) và ngôn ngữ công cụ thứ hai. Thành phần mới `SettingPicker` (`ui/SettingsComponents.kt`) dành cho cài đặt có nhiều lựa chọn; `SettingChoice` (dàn mọi lựa chọn ra màn hình) vẫn dùng cho cài đặt chỉ có vài mức.
- **Bỏ "Kiểm tra cử chỉ".** Đã bỏ trang cài đặt, các điểm móc trong dịch vụ, 9 chuỗi dịch (cả 8 ngôn ngữ) và 2 bài kiểm thử; cài đặt còn **16 trang** (6 menu). Tệp `core/GestureTestMode.kt` và `ui/GestureTestScreen.kt` còn lại như tệp chỉ có chú thích (bản tải lên không xóa được tệp cũ). Trang đã lưu là "Kiểm tra cử chỉ" tự chuyển sang trang **Cử chỉ tùy chỉnh**. Muốn biết cử chỉ nào thật sự tới được ứng dụng: bật Nhật ký chẩn đoán rồi làm thử cử chỉ, mỗi cử chỉ tới dịch vụ để lại một dòng `GESTURE`.
- **Nhật ký chẩn đoán:**
  - Nút **Sao chép nhật ký** nay chép tối đa 18.000 ký tự cuối (trước đó 100.000): khung chat chỉ nhận khoảng 20.000 ký tự khi dán và khi quá dài thì giữ phần ĐẦU, bỏ phần CUỐI, tức là bỏ đúng đoạn vừa thao tác. Muốn gửi đúng đoạn cần xem: bấm **Xóa nhật ký**, làm thao tác đó rồi bấm **Sao chép nhật ký** ngay.
  - Dòng `START` ghi thêm phiên bản ứng dụng.
  - Trình đơn: `MENU open/enter/back/run/close/timeout/closed by window change`, `MENU touch row=i/N` (chạm chọn hàng), `MENU_OVERLAY shown/attach failed`; chỉnh trình đơn phần tử: `MENU_EDIT <thao tác> count=N`. Chỉ ghi tên thao tác, vị trí và số lượng, **không ghi nhãn chữ** của phần tử.
  - Nhánh dự phòng của tự cuộn tìm phần tử nay luôn ghi dòng kết cục `AUTOSCROLL outcome=...`, kể cả khi không có khung nào để cuộn (`NO_TARGET`, `EXHAUSTED`, `NO_SWIPE_LINE`, `SWIPE_FAILED`, `SWIPE_UNCHANGED`); trước đây các trường hợp này không để lại dòng nào nên nhật ký chỉ thấy dòng `start` rồi im.
- **Trợ giúp:** mục Trình đơn nói thêm cách dùng khi trình đơn đang mở (vuốt, chạm và lướt ngón tay, chạm hai lần).
- **Chuỗi dịch:** thêm 1 chuỗi (`menu_position_group`: "tên, nhóm, i trên N"), sửa 1 chuỗi có số lượng (`hp_menus_body`, nay thêm câu hướng dẫn), xóa 9 chuỗi của "Kiểm tra cử chỉ"; cả 8 ngôn ngữ. `menu_position_group` là vị trí chứ không phải số lượng nên nằm trong danh sách ngoại lệ của `QuantityStringsTest`. **Bản dịch ngoài tiếng Việt và tiếng Anh do máy dịch**, chưa người bản ngữ duyệt.
- **Kiểm thử:** 814 bài JVM đạt (16 bài mới, trừ 2 bài của tính năng đã bỏ). `MenuTouchMapTest` (8 bài): hàng chia đều toàn bộ chiều cao kể cả phần dư, chạm ngoài vùng hoặc toạ độ không hợp lệ không ra hàng nào, trình đơn dài cuộn theo mục chọn, hàng cao hơn cả màn hình vẫn hiện một hàng, mép các hàng liền nhau, và với mọi cỡ trình đơn và màn hình thì mục đang chọn luôn nằm trong cửa sổ. `MenuTouchSelectTest` (8 bài): chọn thẳng một mục, giữ trình đơn cha để Quay lại vẫn đúng, bỏ qua vị trí không hợp lệ, chạm rồi vuốt tiếp đi từ mục vừa chạm, chữ "nhóm" đúng với đúng 7 nhóm của trình đơn chung thật, câu vào nhóm có tên và số mục. Hai bài của tính năng đã bỏ được xóa khỏi `GestureFixesTest` và `SubmenuAndEditTest`; `SettingsMenuTest` cập nhật thành 16 trang. Phần mã dịch vụ (`MenuOverlay`, nối chạm trong `ReaderSession`) được biên dịch cùng bộ kiểm tra nhưng **không chạy được** trong JVM vì cần Android thật. `SettingPicker` và hai chỗ gọi trong `VoiceScreen` được kiểm tra kiểu với bộ khai báo thay thế của Compose, **chưa biên dịch bằng Compose thật**.
- **Giới hạn đã biết:** (1) chưa biết hệ thống có đưa sự kiện lướt ngón tay vào lớp danh sách trên máy bạn không (xem cách kiểm tra ở trên); (2) trong lúc trình đơn mở, lớp phủ chặn chạm vào ứng dụng bên dưới (có chủ ý, vì chạm lúc này là để nghe trình đơn); trình đơn tự đóng sau 30 giây không thao tác; (3) hàng chữ dài bị cắt bằng dấu "…" trên màn hình nhưng vẫn được đọc đủ; (4) lớp phủ này chỉ hữu ích khi chế độ khám phá bằng cảm ứng đang bật, là điều kiện sẵn có của dịch vụ.

## Bản 2.22.0: trình đơn chung đủ mọi chức năng, trình đơn phần tử tự sắp xếp

Yêu cầu: trình đơn chung là nơi chứa **tất cả** chức năng của ứng dụng; trình đơn phần tử là danh sách riêng của người dùng để thêm, bớt, đổi thứ tự, thay chức năng, tối đa khoảng 12 chức năng một lần. Làm một lần trong một bản. **Chưa thử được trên máy thật.** Phần giao diện (Compose) không biên dịch được trong môi trường dựng của mình nên **CI là lần biên dịch đầu tiên** của trang chỉnh trình đơn (`ui/MenusScreen.kt`) và của hai dòng thêm vào `ui/HelpScreen.kt`, `ui/SettingsIndex.kt`.

- **Trình đơn chung nay đủ 65 chức năng.** Trước đó chỉ có 22 chức năng; 43 chức năng còn lại chỉ gán được cho cử chỉ chứ không có trong trình đơn nào. 9 trong 74 hành động cố ý không có mặt vì là điều khiển của chính trình đơn hoặc không làm gì: phần tử kế/trước, điều khiển kế/trước, quay lại, dừng đọc, mở trình đơn chung, mở trình đơn phần tử, "không làm gì".
  - **Cấp đầu: 14 mục** (trước là 8). 7 mục quen thuộc giữ **đúng vị trí cũ** (đọc từ đầu, đọc từ phần tử hiện tại, lặp lại, tìm chữ, OCR, thông báo, màn hình chính) nên thói quen vuốt không đổi; sau đó là **7 nhóm** thay cho trình đơn con "Khác" (mục "Khác" không còn nữa).
  - **Bảy nhóm:** Đọc 10, Duyệt nhanh 12, Cuộn và trang 6, Phần tử đang chọn 11, Chỉnh sửa văn bản 9, Hệ thống và phím 9, Công cụ và thông tin 8 (cộng lại 65). Mỗi nhóm kết thúc bằng "Quay lại" và giữ vị trí đang chọn của trình đơn cha. Bảy mục ở cấp đầu cũng có mặt trong nhóm của chúng. "Bật/tắt tiêu điểm chi tiết" xếp ở "Công cụ và thông tin"; nhóm đặt tên "Công cụ và thông tin" (không phải "Công cụ") vì có thêm nói trạng thái và nói vị trí.
  - Các ghi chú của bản cũ bên dưới nhắc "trình đơn chung → Khác" là trình đơn con cũ; nay những chức năng đó nằm trong các nhóm trên.
- **Trình đơn phần tử tự sắp xếp** (Cài đặt → Điều khiển → **Trình đơn nhanh**, phần đầu trang):
  - **Tối đa 12 chức năng**, mặc định đúng 12 mục như các bản trước. Hành động tùy chỉnh của ứng dụng (tối đa 20) và mục "Chỉnh sửa văn bản" ở ô nhập vẫn nằm cuối trình đơn và **không tính vào 12**.
  - **Mỗi chức năng là MỘT điểm dừng** của trình đọc màn hình, đọc "tên, vị trí trên tổng". Chạm vào mở hộp thoại, chỉ gồm thao tác áp dụng được: Chuyển lên đầu (chỉ từ vị trí 3 trở đi, vì ở vị trí 2 nó trùng "Chuyển lên"), Chuyển lên, Chuyển xuống, Thay bằng chức năng khác, Xóa khỏi trình đơn. Mục cuối cùng không xóa được (trình đơn phải còn ít nhất một chức năng) và hộp thoại nói rõ lý do thay cho nút Xóa. Chọn cách đổi thứ tự bằng nút thay vì kéo thả vì kéo thả không dùng được với người khiếm thị.
  - **Thêm chức năng** mở hộp thoại chọn: danh sách cuộn, chia theo 7 nhóm (mỗi nhóm một tiêu đề), chỉ gồm chức năng **chưa có** trong trình đơn nên không thể chọn trùng. **Thay bằng chức năng khác** dùng chính hộp thoại này và giữ nguyên vị trí. Khi đã đủ 12, nút Thêm được thay bằng một dòng giải thích.
  - **Khôi phục trình đơn mặc định** (chỉ hiện khi đã tùy chỉnh) có hộp thoại xác nhận.
  - Kết quả mỗi thao tác ("Nhấn giữ, nay ở vị trí 3 trên 12", "Đã xóa Nhấn giữ. Còn lại: 11", "Đã thêm Nhấn giữ ở vị trí 12"...) đọc ra qua vùng thông báo trực tiếp (`liveRegion`).
  - **Có hiệu lực ngay:** mỗi thay đổi lưu tức thì và dịch vụ đọc bố cục mỗi lần mở trình đơn, nên không cần khởi động lại. Trình đơn đang mở giữ danh sách lúc mở; lần mở sau nhận bố cục mới. Bố cục dùng chung cho mọi ứng dụng.
- **Lưu trữ:** tệp `menu_layout_prefs`, khóa `local_actions` (tên các chức năng, ngăn bằng dấu phẩy). **Chỉ lưu khi khác mặc định**: ai chưa chỉnh thì không có gì được lưu và vẫn nhận mặc định cải thiện về sau; sắp xếp lại đúng như mặc định cũng được coi là chưa tùy chỉnh. Đọc lại luôn an toàn: tên lạ (bản ứng dụng khác), trùng, chức năng không có trong danh mục, quá 12 mục hoặc chuỗi hỏng đều bị bỏ, không sập; không còn gì dùng được thì về mặc định. **Có trong Sao lưu và khôi phục** (`BackupSchema.MENU_LAYOUT`).
- **Quy tắc ảnh giữ nguyên nhưng chỉ khi chưa tùy chỉnh:** ở phần tử là ảnh, "Mô tả hình ảnh" và "Đọc chữ trong ảnh" vẫn nhảy lên đầu trình đơn. Đã tùy chỉnh thì thứ tự của bạn được giữ nguyên, kể cả với ảnh.
- **Không đổi:** cử chỉ, cách chọn mục trong trình đơn, mọi cài đặt đã lưu, cách chạy chức năng (mục trình đơn đi qua `dispatcher.dispatch` như cử chỉ). Khóa chuỗi `menu_more_title` ("Khác") đã xóa.
- **Chuỗi dịch:** thêm 29 chuỗi (tên nhóm, mô tả trang, nhãn thao tác, hộp thoại chọn và khôi phục, thông báo kết quả, mục Trợ giúp), sửa 2 chuỗi (tóm tắt trang Trình đơn nhanh; lời giới thiệu Sao lưu nay nhắc trình đơn phần tử), xóa 1; cả 8 ngôn ngữ. Ba chuỗi có số lượng ("tối đa N chức năng", "đã có N chức năng", mục Trợ giúp) là `<plurals>` theo quy ước của dự án; các chuỗi chỉ có vị trí hoặc "Còn lại: N" nằm trong danh sách ngoại lệ của `QuantityStringsTest`. **Bản dịch ngoài tiếng Việt và tiếng Anh do máy dịch**, chưa người bản ngữ duyệt; bản Phồn thể do bộ chuyển đổi nội bộ (`tools/i18n/zh_hant.py`) sinh ra và đã đọc lại bằng mắt.
- **Mã nguồn:** `menu/MenuCatalog.kt` (7 nhóm `MenuGroup` và danh sách loại trừ; nguồn duy nhất cho trình đơn chung, hộp thoại chọn và trang giải thích), `menu/MenuLayout.kt` (bố cục bất biến, thuần Kotlin, mọi thao tác trả về bố cục mới hoặc chính nó nếu không hợp lệ), `menu/MenuLayoutStore.kt` (SharedPreferences). `MenuModel.kt` viết lại: `Menus.global()`, `Menus.submenu(kind)`, `Menus.local(..., layout)`, `Menus.labelFor`; `MenuKind.GLOBAL_MORE` và `Menus.globalMore()` đã bỏ. Chuỗi sinh tự động vẫn sửa trong `tools/i18n/table_*.py` rồi chạy `python3 -I tools/i18n/gen.py .`.
- **Kiểm thử:** 800 bài JVM đạt (29 bài mới). `MenuCatalogTest` (9 bài) giữ lời hứa "đủ mọi chức năng mãi mãi": mỗi `GestureAction` phải thuộc đúng một nhóm hoặc nằm trong danh sách loại trừ, nên thêm hành động mới mà quên xếp nhóm thì test đỏ; trình đơn chung phải tới được đủ 65 chức năng; hành động điều khiển của trình đơn luôn nằm trong danh sách loại trừ. `MenuLayoutTest` (14 bài) và `LocalMenuLayoutTest` (6 bài): mặc định, thêm/xóa/chuyển/thay ở mọi biên, chuỗi lưu hỏng, vòng lưu và khôi phục qua `BackupCodec`, thao tác nào giao diện được phép hiện thì luôn đổi được bố cục và thao tác bị ẩn thì không bao giờ đổi, thứ tự và nhãn của trình đơn phần tử mặc định giống bản cũ, quy tắc ảnh. Năm tệp test cũ sửa theo cấu trúc mới (`MenuTest`, `SubmenuAndEditTest`, `ReadingControlGestureTest`, `DetailedFocusTest`, `QuantityStringsTest`). Phần Compose chỉ được đối chiếu tên: mọi `R.string.*`/`R.plurals.*` có thật, cách gọi lấy theo các màn hình đã biên dịch được (`GestureSettingsScreen`, `BackupScreen`), **chưa biên dịch**; nếu CI báo lỗi ở `ui/`, gửi nội dung lỗi để sửa.
- **Giới hạn đã biết:** chưa thử trên máy thật nên chưa biết tiêu điểm trợ năng đặt ở đâu sau khi đóng hộp thoại (do hệ thống quyết định); trình đơn chung không sửa được (theo yêu cầu); bố cục trình đơn phần tử chung cho mọi ứng dụng, chưa có bố cục riêng theo ứng dụng; khôi phục từ tệp sao lưu chỉ ghi các khóa có trong tệp (như mọi cài đặt khác, "không xóa cài đặt nào khác"), nên tệp sao lưu lúc trình đơn phần tử còn mặc định (không có khóa nào) sẽ không đặt lại bố cục đang tùy chỉnh trên máy: dùng nút "Khôi phục trình đơn mặc định".

## Bản 2.21.0: giao diện chính hai tầng (menu → trang), mục "Cử chỉ tùy chỉnh"

Yêu cầu: gom các tính năng giống nhau vào cùng một menu cho gọn (phương án A, làm một lần trong một bản) và đổi tiêu đề mục cử chỉ thành "Cử chỉ tùy chỉnh". **Chưa thử được trên máy thật.** Phần giao diện (Compose) không biên dịch được trong môi trường dựng của mình nên **CI là lần biên dịch đầu tiên** của bản này.

- **Cấu trúc: 6 menu, 17 trang** (nay còn 16 trang vì trang "Kiểm tra cử chỉ" đã bỏ ở bản 2.23.0; trước đó là danh sách phẳng 15 mục, trong đó "Chi tiết đọc nội dung" là một trang cuộn dài 21 công tắc):
  - **Bắt đầu**: Trạng thái và quyền.
  - **Giọng nói và âm thanh**: Giọng nói (TTS); Âm báo và rung.
  - **Nội dung được đọc**: Cách đọc phần tử; Tiêu điểm; Thông báo và sự kiện.
  - **Điều khiển**: Cử chỉ tùy chỉnh; Cử chỉ theo ứng dụng; Kiểm tra cử chỉ (đã bỏ ở bản 2.23.0); Trình đơn nhanh; Chạm và gõ phím; Phím cứng và nút tai nghe.
  - **Công cụ**: Nhãn của tôi; Tiện ích và kịch bản; Sao lưu và khôi phục; Nhật ký và hỗ trợ.
  - **Trợ giúp**: Hướng dẫn và giới hạn.
- **Điều hướng (máy hẹp):** danh sách chính chỉ có 6 menu; mở menu ra danh sách trang; mở trang ra toàn màn hình. Nút Back của hệ thống và hàng "Quay lại" ở đầu trang lùi **từng tầng** (trang → menu → danh sách chính; ở danh sách chính mới thoát ứng dụng). Hai menu chỉ có một trang (Bắt đầu, Trợ giúp) mở **thẳng** trang, không qua danh sách một mục. **Máy rộng:** cột trái hiện cả cây (tên menu làm tiêu đề, dưới là các trang của nó), cột phải là trang đang chọn nên không cần Back.
- **Tìm kiếm** vẫn ở đầu danh sách chính; kết quả là các **trang** (mở thẳng). Gõ tên menu (ví dụ "Điều khiển") ra mọi trang của menu đó. Chỉ mục được chia lại theo trang mới.
- **Mục cử chỉ đổi tên thành "Cử chỉ tùy chỉnh"** (trước đọc "Cử chỉ. Một, hai, ba, bốn ngón"; nay đọc "Cử chỉ tùy chỉnh. Gán chức năng cho từng cử chỉ"). Đầu trang cử chỉ cũng có tiêu đề "Cử chỉ tùy chỉnh" (trước đây trang không có tiêu đề, mở ra gặp ngay "Một ngón"). Các tiêu đề nhóm trong trang ("Một ngón", "2 ngón", "3 ngón", "4 ngón", "Phím âm lượng và nút tai nghe") **giữ nguyên** để nhảy theo tiêu đề; nhãn của mỗi cử chỉ vốn đã có số ngón. Mọi chuỗi nhắc tên mục này (Trợ giúp, nhãn, tiện ích, trình đơn, phím âm lượng...) đã đổi theo ở cả 8 ngôn ngữ.
- **Cài đặt cũ nay nằm ở đâu:**
  - Biểu tượng cảm xúc, ảnh không nhãn (OCR), phạm vi danh sách, đọc hướng dẫn thao tác, gợi ý thao tác, mức chi tiết (trước ở Đọc) → Nội dung được đọc → **Cách đọc phần tử**.
  - Tiêu điểm chi tiết, hộp thoại, nhớ vị trí (trước ở Đọc) → Nội dung được đọc → **Tiêu điểm**.
  - Đọc người gọi đến, nói vị trí (trước ở Đọc) → Nội dung được đọc → **Thông báo và sự kiện**, cùng trang với đọc thông báo. Báo giờ khi bật màn hình / báo khi tắt màn hình từng nằm cùng chỗ; từ bản 2.24.0 nó luôn bật và không còn công tắc.
  - Độ trễ chạm, nhập phím bằng nhấc tay, thanh trượt chỉnh bằng cử chỉ cuộn, đọc ký tự và từ khi gõ, chữ hoa, đọc mật khẩu (trước ở Đọc) → Điều khiển → **Chạm và gõ phím**.
  - Phím tắt bàn phím ngoài, phím âm lượng, nút tai nghe (trước ở Đọc) → Điều khiển → **Phím cứng và nút tai nghe**.
  - Nhật ký chẩn đoán (trước nằm lẫn trong trang Đọc) → Công cụ → **Nhật ký và hỗ trợ**, cùng trang với nhật ký lỗi.
  - Mục "Quyền" riêng → cuối trang Bắt đầu → **Trạng thái và quyền**; chỉ còn một nút "Mở cài đặt quyền" thay vì lặp lại sau từng dòng.
  - Hai đoạn giải thích (phần tử không nhãn; chức năng gán vào cử chỉ) → **Trợ giúp**.
- **Không đổi:** khóa lưu và giá trị của mọi cài đặt (không ai phải bật lại), cách đọc, cử chỉ. Chỉ đổi chỗ đặt và tên mục. Trạng thái màn hình lưu bằng khóa cũ vẫn mở được ("reading" → Cách đọc phần tử, "permissions" → Trạng thái và quyền).
- **Chuỗi dịch:** thêm 17 chuỗi, đổi tên 5 khóa, sửa chữ 18 chuỗi (tên mục và các câu nhắc tên mục), xóa 9 chuỗi không còn dùng; cả 8 ngôn ngữ, bản dịch ngoài tiếng Việt và tiếng Anh do máy dịch. Bản Phồn thể sửa luôn "日志" thành "日誌" (21 chuỗi cũ còn sót dạng giản thể).
- **Mã nguồn:** cây menu là Kotlin thuần (`core/SettingsMenu.kt`: `SettingsPage`, `SettingsMenu`, `SettingsNav`) nên kiểm thử được trên JVM; `ui/AppRoot.kt` chỉ vẽ lại cây này. Hàm `when` trên menu/trang là đầy đủ, nên thêm trang mới mà quên chuỗi tên thì không biên dịch. Màn Đọc cũ tách thành `ReadElementsScreen`, `FocusScreen`, `TouchTypingScreen`, `HardwareKeysScreen` (cùng tệp `ReadingScreen.kt`); `PermissionsScreen.kt` nay chỉ còn `PermissionsSection()` chèn vào trang Trạng thái.
- **Kiểm thử:** 771 bài JVM đạt (20 bài mới: mỗi trang đúng một menu, khóa không trùng, khóa cũ vẫn mở được, Back từng tầng và không có ngõ cụt, bố cục rộng luôn có trang; và đọc thẳng mã nguồn để chắc chỉ mục tìm kiếm có đủ trang và mọi `R.string.*` có thật trong `strings.xml`). Phần Compose chỉ được đối chiếu tên với bản cũ (không tên nào lạ, mọi `settings.*` có thật), **chưa biên dịch**; nếu CI báo lỗi ở `ui/`, gửi nội dung lỗi để sửa.
- **Giới hạn đã biết:** chưa thử trên máy thật nên chưa biết tiêu điểm trợ năng đặt ở đâu sau mỗi lần vào menu/trang (do hệ thống quyết định); tiêu đề đầu mỗi trang là heading để nhảy tới nhanh. Bản dịch máy chưa người bản ngữ duyệt.

## Bản 2.20.7: sửa lỗi lướt ngón tay trên màn hình bỏ sót mục

Yêu cầu: vuốt qua lại đã đọc đủ, nhưng khi **lướt ngón tay trên màn hình** (khám phá bằng cảm ứng) vẫn có mục không được đọc. Rà theo mã nguồn (không có máy thật nên **chưa thử được trên máy thật**), tìm các chỗ có bằng chứng từ mã và sửa:

- **Nguyên nhân chính: bộ lọc trùng sự kiện chung nuốt mục khi lướt nhanh.** Sự kiện chạm đi qua cùng bộ lọc trùng (cửa sổ 120 ms) với mọi sự kiện khác, mà khóa lọc chỉ gồm loại sự kiện, id view và chữ sự kiện. Ứng dụng không có id và chữ sự kiện rỗng (Compose, web, nhiều ứng dụng tự vẽ), hoặc danh sách lặp lại cùng một chữ ("Xóa", "Trả lời"), cho khóa GIỐNG HỆT nhau giữa các mục. Mốc thời gian lại được làm mới cả khi bỏ sự kiện, nên lướt nhanh (mỗi mục dưới 120 ms) chỉ đọc mục đầu rồi bỏ hết các mục sau, kể cả mục ngón tay dừng lại. Triệu chứng đúng như đã báo: một số mục không đọc, tùy tốc độ lướt. Nay sự kiện chạm **không qua bộ lọc này**.
- **Chống đọc lặp riêng cho chạm.** Hệ thống đôi khi báo vào cùng một phần tử hai lần liền nhau (vào, ra, vào lại khi đi qua view con không hiển thị với trợ năng). Bộ chống vọng mới chỉ so với phần tử vừa đọc: sang phần tử khác luôn được đọc; chỉ lần báo lại trong 250 ms của CHÍNH phần tử đó mới bị bỏ; bỏ một lần không kéo dài thời gian chặn; nhấc tay thì quên, nên chạm lại đúng mục đó luôn được đọc lại.
- **Lướt nhanh hơn tốc độ xử lý.** Mỗi lần chạm tốn vài lượt gọi hệ thống đồng bộ trên luồng xử lý duy nhất, nên khi lướt nhanh các sự kiện dồn lại và mục ngón tay đang dừng chỉ được đọc sau khi đọc hết các mục cũ (mỗi mục cũ vừa bắt đầu đã bị mục kế cắt). Nay nếu trong hàng đợi đã có sự kiện chạm mới hơn thì bỏ các sự kiện chạm cũ liền trước nó. Không bao giờ gộp xuyên qua một lần nhấc tay, và các sự kiện khác (nhấc tay, đổi cửa sổ, cử chỉ) không bao giờ bị bỏ.
- **Chạm khớp với vuốt.** Thứ gì vuốt tới được thì chạm vào cũng phải nghe được: thanh trượt/thanh tiến trình **không nhãn** trước đây vuốt tới được nhưng chạm vào thì im lặng; nay được đọc. Khung không nhãn nhưng tự khai báo là một khối đọc (`screenReaderFocusable`) được đọc gộp chữ các con khi bên dưới có chữ. Khoảng trống không chữ, không thao tác vẫn im lặng như cũ (không đọc "không có nhãn" khi lướt qua).
- **Nhật ký chẩn đoán có thẻ `HOVER`**, chỉ ghi khi một lần đặt ngón tay có chạm không được đọc, dạng `read=5 echo=0 unreadable=2 hidden=0 no_source=0 coalesced=3`: `unreadable` là chạm vào chỗ không có gì đáng đọc, `hidden` là phần tử không hiển thị, `no_source` là sự kiện không có nút nguồn, `coalesced` là số lần chạm bị bỏ vì đã có chạm mới hơn. **Chỉ có số đếm, không ghi nội dung chữ trên màn hình.**
- Kiểm thử: 751 bài JVM đạt (33 bài mới: bộ chống vọng, bộ gộp sự kiện kèm luồng ngẫu nhiên, cổng sự kiện, đếm nhật ký, và 3.000 cây ngẫu nhiên kiểm "mọi điểm dừng khi vuốt đều chạm vào được"). Đã thử phá từng sửa đổi (cho sự kiện chạm qua lại bộ lọc cũ, bỏ vế thanh trượt, để tiếng vọng làm mới mốc, nuốt sự kiện không gộp được) thì đúng các bài mới báo lỗi. Việc nhận sự kiện chạm từ hệ thống, đặt tiêu điểm và phát giọng **không kiểm thử được ngoài máy thật**.
- Giới hạn đã biết: mục nằm trong view bị ứng dụng đánh dấu "không quan trọng với trợ năng" vẫn cần "Tiêu điểm chi tiết"; ứng dụng tự vẽ không qua cây trợ năng (game, canvas, ảnh chứa chữ) không có phần tử để đọc, dùng OCR; khối đọc không nhãn mà không có chữ nào bên dưới vẫn im khi chạm. Nếu vẫn còn mục không đọc khi lướt, gửi tên ứng dụng, màn hình đang dùng, tốc độ lướt (chậm hay nhanh) và các dòng `HOVER`/`COLLECT` trong nhật ký (Cài đặt → Đọc → "Sao chép nhật ký").

## Bản 2.20.6: bật màn hình thì đọc giờ, tắt màn hình vẫn báo "Đã tắt màn hình"

> **Đã đổi ở bản 2.24.0:** công tắc dưới đây đã bỏ và tính năng luôn bật; trong cuộc gọi không đọc cả hai chiều; giới hạn "lời đọc giờ bị cắt" đã có biện pháp riêng. Xem "Bản 2.24.0". Phần còn lại của mục này giữ làm lịch sử.

Công tắc **Báo giờ khi bật màn hình, báo khi tắt màn hình** (Cài đặt → Đọc; khóa lưu giữ nguyên là `announce_screen`, nên ai đã bật rồi thì không phải bật lại; mặc định vẫn tắt):

- **Bật màn hình**: đọc **giờ hiện tại** ("Bây giờ là 15 giờ 28 phút", cùng câu với cử chỉ "cho biết giờ"), không còn đọc "Đã bật màn hình". Giờ lấy ngay lúc đọc.
- **Tắt màn hình**: giữ nguyên, đọc "Đã tắt màn hình" (giọng đọc luôn dừng khi tắt màn hình, bất kể công tắc).
- **Đang đổ chuông hoặc trong cuộc gọi** (kể cả gọi qua mạng, chế độ âm thanh khác bình thường): KHÔNG đọc giờ khi bật màn hình, vì màn hình bật lại mỗi lần rời tai nghe và lời đọc giờ sẽ chen vào lời báo người gọi hoặc cuộc nói chuyện. Lời "Đã tắt màn hình" giữ như cũ.
- Chuỗi "Đã bật màn hình" không còn dùng nên đã xóa; tên và mô tả công tắc đã cập nhật ở cả 8 ngôn ngữ (bản dịch ngoài tiếng Việt và tiếng Anh do máy dịch).
- Kiểm thử: 718 bài JVM đạt (8 bài mới cho lời báo bật/tắt màn hình). Việc nghe broadcast bật/tắt màn hình và phát giọng **không kiểm thử được ngoài máy thật**.
- Giới hạn đã biết: nếu ngay sau khi bật màn hình hệ thống gửi sự kiện đổi cửa sổ (màn hình khóa) và ứng dụng đọc nó theo cách ngắt lời, lời đọc giờ có thể bị cắt giữa chừng. Nếu gặp, báo lại kèm máy và kiểu khóa màn hình.

## Bản 2.20.5: rà soát phần đọc phần tử, sửa các chỗ làm thiếu phần tử khi vuốt

Yêu cầu: rà lại phần đọc các phần tử trên màn hình, nơi đôi khi vẫn còn thiếu. Rà theo mã nguồn (không có máy thật nên **chưa thử được trên máy thật**), tìm các chỗ có thể làm mất phần tử và sửa những chỗ có bằng chứng từ mã:

- **Khung có chữ nhưng không bấm được không còn nuốt các con.** Trước đây mọi nút có `text`/`contentDescription` đều "nuốt" hết chữ không thao tác bên dưới: một khung bố cục, danh sách, WebView hay nhóm có `contentDescription` làm mất toàn bộ chữ bên dưới khi vuốt. Nay chỉ nút bấm/tích/gõ được có nhãn (và khung tự khai báo là một khối đọc) mới gộp chữ con; khung chữ thường là một điểm dừng nhưng các con vẫn là điểm dừng riêng.
- **Nút con bấm được trong thẻ không còn bị giấu.** Nút kiểu "Thích/Bình luận" (khung bấm được chứa biểu tượng và chữ) và nút biểu tượng chưa gắn nhãn nằm trong thẻ bấm được trước đây chỉ tới được khi bật "Tiêu điểm chi tiết"; nay luôn là điểm dừng riêng (nhờ đó còn gắn được nhãn tự gán). Thẻ cũng không đọc lặp chữ của các nút con này.
- **Khung bấm được chứa nhiều chữ.** Trước đây chỉ đọc 6 chữ đầu, sâu 4 cấp, phần còn lại mất hẳn (điển hình: khung gốc cả màn hình đặt "bấm được"). Nay gộp được tới 12 mảnh chữ; nhiều hơn thì khung chỉ là bố cục và từng chữ là một điểm dừng. Nhấn một chữ vẫn kích hoạt khung bấm được bao quanh nó.
- **Khung chỉ bọc quanh các nút khác** (bấm được, không có chữ riêng) không còn là điểm dừng "không có nhãn" thừa.
- **Thanh trượt/tiến trình chưa gắn nhãn, và ô chỉ có gợi ý hay chú thích** trước đây không tới được bằng vuốt (chạm vào thì nghe được); nay là điểm dừng khi chúng không nằm trong khối đã gộp.
- **Nhãn gộp khi đọc** dùng cùng quy tắc với phần chọn điểm dừng (một nguồn duy nhất), nên chữ đã bị gộp thì chắc chắn được đọc, và nút thao tác bên trong không bị đọc lặp. Vùng thông báo trực tiếp vẫn gộp mọi chữ bên dưới như cũ.
- **Cây giao diện thiếu nút con** (hệ thống trả null khi ứng dụng đang vẽ lại): nạp lại một lần sau 80 ms; danh sách còn khuyết không được giữ trong bộ đệm 0,8 giây như trước.
- **Ô nhập đã có chữ** đọc thêm tên ô (nhãn gắn kèm, gợi ý) sau vai trò, ví dụ "Nguyễn Văn A, ô nhập, Họ tên". Trước đây tên ô rơi mất nên các ô điền sẵn không phân biệt được với nhau.
- Nhật ký chẩn đoán có thêm thẻ `COLLECT` (số điểm dừng, danh sách có đầy đủ không). **Không ghi nội dung chữ trên màn hình.**
- Kiểm thử: 710 bài JVM đạt (38 bài mới: 35 cho quy tắc chọn điểm dừng, gồm 4.000 cây ngẫu nhiên kiểm "không mất chữ vô cớ, không đọc lặp, nút thao tác luôn tới được"; 3 cho lời đọc ô nhập). Đã thử đảo lại hành vi cũ thì bài ngẫu nhiên báo lỗi. Phần gọi hệ thống (dựng cây từ `AccessibilityNodeInfo`) **không kiểm thử được ngoài máy thật**.
- **Thay đổi cần biết:** số điểm dừng mỗi màn hình thay đổi (thường nhiều hơn ở màn có khung có nhãn hoặc nút con trong thẻ). Công tắc "Tiêu điểm chi tiết" nay chỉ còn bật cờ hệ thống đưa cả view bị ứng dụng đánh dấu "không quan trọng" vào cây; việc chọn điểm dừng không còn phụ thuộc nó.
- Giới hạn đã biết: ứng dụng tự vẽ không qua cây trợ năng (game, canvas, ảnh chứa chữ) vẫn không có phần tử để đọc, dùng OCR; view bị đánh dấu "không quan trọng với trợ năng" vẫn cần "Tiêu điểm chi tiết"; trang rất dài vẫn bị cắt ở 1.500 nút hiển thị mỗi lần nạp. Nếu vẫn còn thiếu phần tử, gửi tên ứng dụng, màn hình đang dùng và các dòng `COLLECT`/`MOVE` trong nhật ký (Cài đặt → Đọc → "Sao chép nhật ký").

## Bản 2.20.4: vuốt một ngón phải/trái tự cuộn tiếp khi hết màn hình

Lỗi được báo: vuốt một ngón **phải** (phần tử kế) / **trái** (phần tử trước) chỉ đi hết các phần tử đang hiện trên màn hình rồi dừng, không tự cuộn để đi tiếp dù phía dưới (hoặc phía trên) vẫn còn nội dung. Sửa dựa trên phân tích mã nguồn, **chưa thử được trên máy thật** (xem "Giới hạn" bên dưới):

- **Cuộn trước khi rời danh sách**: khi phần tử kế nằm NGOÀI vùng cuộn đang đứng (thanh dưới, nút nổi, tiêu đề cố định...) mà vùng đó còn cuộn được theo hướng vuốt, ứng dụng cuộn vùng đó trước rồi mới sang phần tử ngoài vùng. Trước đây chỉ cuộn khi cả cửa sổ đã hết phần tử, nên thanh dưới luôn bị tới trước và phần còn lại của danh sách bị bỏ qua.
- **Chờ nội dung dừng hẳn** thay vì chờ cố định 0,3 + 0,5 giây: thăm dò mỗi 0,12 giây (tối đa 1,5 giây mỗi lần cuộn), xong khi hai lần thăm dò liên tiếp cho cùng một danh sách khác trước khi cuộn. Danh sách trượt có hiệu ứng (~0,6 giây) và trang web cập nhật chậm không còn bị chọn nhầm lúc nội dung chưa kịp đổi.
- **Chọn phần tử mới theo vị trí + nhãn** (không chỉ nhãn): đo quãng nội dung đã trượt từ các phần tử giống nhau trước/sau, rồi chỉ coi là "đã thấy" những phần tử trùng nhãn VÀ đúng chỗ dự kiến. Nhờ vậy: mục trùng chữ (nút "Thích" ở mỗi bài, giá tiền) không bị bỏ sót; thanh dính đứng yên không bị chọn; đoạn văn dài bị cắt ở mép không bị đọc lại.
- **Hàng kiểu thẻ** (khung bấm được, chữ nằm ở phần tử con) trước đây coi là không nhãn nên không nhận ra hàng nào đã đọc; nay dùng chữ gộp của các con làm nhãn so khớp.
- Nếu một lần cuộn chưa lộ ra phần tử có nhãn nào (ví dụ chỉ thêm ảnh) thì cuộn tiếp, tối đa 3 lần.
- **Không cuộn nhầm**: chỉ cuộn khung nội dung dọc. Bộ chọn giá trị (NumberPicker, TimePicker, thanh trượt: cuộn là đổi giá trị) và băng chuyền/bộ chuyển trang chỉ cuộn ngang bị bỏ qua. Các lệnh cuộn do người dùng chủ động (hai ngón vuốt, cử chỉ "Cuộn") giữ nguyên.
- **Nhớ vùng đã hết** 5 giây: cuộn xong mà không có gì mới thì các lần vuốt kế đi thẳng sang phần tử kế, không chờ vô ích. Cuộn tay hoặc đổi màn hình thì xóa nhớ.
- Nhật ký chẩn đoán (Cài đặt → Đọc → "Sao chép nhật ký") có thêm dòng thẻ `AUTOSCROLL` ghi số liệu mỗi lần tự cuộn (số phần tử trước/sau, quãng trượt, số phần tử đã thấy, kết quả). **Không ghi nội dung chữ trên màn hình.** Nếu vẫn lỗi, gửi các dòng này kèm tên ứng dụng và màn hình đang dùng.
- Kiểm thử: 672 bài JVM đạt (34 bài mới cho phần chọn phần tử sau cuộn, nhận biết ổn định, nhớ vùng đã hết). Phần gọi hệ thống (đọc cây giao diện, thực hiện cuộn) **không kiểm thử được ngoài máy thật**.
- Giới hạn đã biết: danh sách toàn mục GIỐNG HỆT nhau (cùng chữ, cùng hộp) không đo được quãng trượt; tiêu đề dính ĐỔI chữ khi cuộn (tên mục hiện hành) vẫn bị coi là phần tử mới; ứng dụng cập nhật giao diện chậm hơn 1,5 giây sau khi cuộn sẽ bị coi là "chưa đổi"; khung báo cuộn được mà không phản hồi hành động cuộn thì vẫn dùng cú vuốt giả lập như trước (chỉ khi đã hết phần tử của cả cửa sổ).

## Bản 2.20.3: sửa 4 lỗi lint do CI báo

Báo cáo CI của bản 2.20.2: bản dựng đạt, **638/638 bài kiểm thử đạt**, nhưng `lintDebug` báo **4 lỗi**, 5 cảnh báo, 2 gợi ý (4 lỗi làm bước lint đỏ). **Không đổi hành vi ứng dụng**:

- **4 lỗi `LocalContextGetResourceValueCall`** (màn **Sao lưu**): các thông báo kết quả ("đã lưu", "đã khôi phục", "không đọc/ghi được tệp") lấy chuỗi bằng `LocalContext.current.getString()`, không đổi theo ngôn ngữ/cấu hình nếu cấu hình đổi lúc màn đang mở. Nay lấy qua `LocalResources.current` (đúng cách Compose khuyến nghị).
- Cảnh báo `LocalContextResourcesRead` (màn **Nhãn**): `context.resources` → `LocalResources.current`.
- Gợi ý `AutoboxingStateCreation` (màn **Đọc**): hai ô nhớ số dùng `mutableIntStateOf` / `mutableFloatStateOf` (không đóng gói số mỗi lần ghi).
- Cảnh báo `UseKtx`: hàm khôi phục cài đặt (`SettingsBackupIO.apply`) dùng `SharedPreferences.edit { }`; cùng hành vi (gom thay đổi từng tệp rồi `apply()` một lần).
- Cảnh báo `ObsoleteSdkInt`: thư mục biểu tượng `mipmap-anydpi-v26` đổi thành `mipmap-anydpi` (minSdk 35 nên hậu tố `-v26` là thừa). Nội dung hai tệp giữ nguyên. Nếu kho GitHub của bạn còn thư mục cũ thì có thể xóa; để lại không gây hại (cùng nội dung), chỉ còn đúng cảnh báo đó.
- **Android Gradle Plugin 9.5.0 → 9.5.1** (bản vá; lint báo có bản mới; trang phát hành chính thức ghi 9.5.1 không có lỗi công khai nào được sửa, yêu cầu tối thiểu như 9.5.0).
- Cố ý **giữ** cảnh báo `OldTargetApi` (`targetSdk = 36`): Google Play yêu cầu API 36; nâng 37 cần thử hành vi mới của Android 17 trên máy thật trước.
- Kiểm thử: 638 bài JVM vẫn đạt. Compose và lint **không chạy được** ở môi trường soạn thảo, nên các sửa ở `ui/` mới được đối chiếu với tài liệu API (`LocalResources: ProvidableCompositionLocal<Resources>`), chưa biên dịch; lần chạy CI kế tiếp là bước kiểm chứng thật.

## Bản 2.20.2: nâng công cụ build

Chỉ đổi cấu hình build, **không đổi mã ứng dụng** (638 bài kiểm thử JVM vẫn đạt; CI đã xác nhận bản dựng và 638/638 bài đạt với AGP 9.5.0 + Gradle 9.9.1):

- **Android Gradle Plugin 9.4.0 → 9.5.0** (ổn định từ 10/2026; yêu cầu tối thiểu Gradle 9.6, JDK 17, compileSdk tối đa 37: dự án đã thỏa).
- **Gradle 9.8.2 → 9.9.1**, giữ ghim checksum SHA-256 của bản phân phối `gradle-9.9.1-bin.zip`. 9.9.1 là bản vá bảo mật (ra 10/11/2026) theo ghi chú phát hành của Gradle.
- Chưa chạy Gradle ở môi trường soạn thảo nên chưa chứng minh được bản dựng; nếu CI báo lỗi, quay lại v51 hoặc đổi riêng từng dòng (`agp` trong `gradle/libs.versions.toml`, `distributionUrl` + `distributionSha256Sum` trong `gradle/wrapper/gradle-wrapper.properties`).

## Bản 2.20.1: rà soát toàn diện, sửa 3 lỗi

Rà lại toàn bộ mã dịch vụ, giọng đọc, AI/OCR, plugin, lưu trữ/sao lưu, nhật ký lỗi và phần giao diện đã đổi từ 2.18 (Compose không biên dịch được ở môi trường soạn thảo nên chỉ đọc mã). Chỉ sửa lỗi có bằng chứng trong mã:

- **Vuốt xuống/lên bị kẹt ở thanh tiến trình chỉ-đọc** (tải xuống, mức pin, vòng tải): trước đây phần tử nào có khoảng giá trị cũng bị coi là thanh trượt, nên vuốt một ngón xuống/lên chỉ đọc lại giá trị mà không sang phần tử khác (và cuộn trang cũng bị nuốt). Nay chỉ thanh **đang bật và có hành động chỉnh** (`ACTION_SET_PROGRESS` hoặc cuộn tới/lui) mới được chỉnh bằng cử chỉ (`SliderMath.isAdjustable`).
- **"Đưa con trỏ về đầu/cuối", "chọn tất cả" báo "không thực hiện được" khi đã ở đúng vị trí** (TextView trả false cho `ACTION_SET_SELECTION` nếu vùng chọn không đổi). Nay nhận ra trường hợp đã đúng sẵn (`SelectionMath.isNoOp`) và báo xong. Độ dài chữ lấy theo chữ THẬT, không tính gợi ý (hint) của ô trống; không gửi lại `ACTION_FOCUS` cho ô đang giữ tiêu điểm (như khi dời con trỏ), tránh ứng dụng chọn lại toàn bộ chữ rồi "dán" ghi đè cả ô.
- **Duyệt theo từ không tách dấu cách không ngắt** (`&nbsp;` U+00A0, U+202F, U+3000... hay gặp trên trang web): "Hà&nbsp;Nội" từng là một từ và cụm chỉ gồm &nbsp; thành một "từ" rỗng. Nay mọi khoảng trắng Unicode đều tách từ, giống đơn vị câu/đoạn.
- Kiểm thử: 638 bài JVM (thêm 3 bài hồi quy ở `SliderMathTest`, `SubmenuAndEditTest`, `TextUnitsTest`). **Chưa** chạy Gradle/Compose/lint và chưa thử trên máy thật. Lỗi thứ hai dựa trên hành vi TextView mà tôi nhớ từ mã nguồn Android (chưa kiểm chứng trên máy): phần kiểm tra "đã đúng vị trí" là logic thuần nên vô hại kể cả khi nhớ sai.

## Bản 2.20.0: cử chỉ theo bảng chuẩn mới nhất của Bộ trợ năng Android

Đối chiếu với bảng cử chỉ và danh sách "điều khiển đọc" trong tài liệu chính thức của Google (bản mới nhất, hai lần trích độc lập cho kết quả giống nhau) rồi đưa mặc định về đúng chuẩn. Mọi cử chỉ vẫn gán lại được trong mục **Cử chỉ**.

- **Mặc định đổi** (`GestureMapping.defaults`):

  | Cử chỉ | Bản 2.20.0 | Trước đó |
  |---|---|---|
  | Lên rồi trái | Màn hình chính | Quay lại |
  | Xuống rồi trái | Quay lại | Màn hình chính |
  | Trái rồi lên | Ứng dụng gần đây | (trống) |
  | Phải rồi xuống | Thông báo | (trống) |
  | Trái rồi xuống | Tìm chữ trên màn hình | (trống) |
  | Hai ngón chạm hai lần | Phát/tạm dừng nhạc hoặc video | Đọc lại câu vừa đọc |
  | Hai ngón chạm ba lần | Đọc từ phần tử đang chọn | Đổi đơn vị đọc |
  | Ba ngón chạm hai lần | Sao chép chữ của phần tử | Trình đơn phần tử |
  | Ba ngón chạm ba lần | Dán vào ô nhập | Đọc từ đầu màn hình |
  | Ba ngón chạm hai lần và giữ | Cắt chữ ở ô nhập | (trống) |
  | Ba ngón vuốt xuống / lên | Điều khiển đọc kế / trước | Đơn vị đọc kế / trước |

- **Hành động bị nhường chỗ** (không còn cử chỉ mặc định nhưng không mất): *Đọc lại câu vừa đọc* và *Đọc từ đầu* (trình đơn chung), *Đổi đơn vị đọc* và *Đơn vị kế/trước* (trình đơn phần tử). Trình đơn phần tử vẫn mở bằng lên-rồi-phải. Muốn ba ngón vuốt như cũ: mục Cử chỉ → bộ ba ngón vuốt → "Đọc theo đơn vị và chuyển trang". Muốn lấy lại các hành động khác: gán cho một cử chỉ bất kỳ trong mục Cử chỉ (ví dụ hai ngón chạm hai lần = *Đọc lại*). Ai đã lưu cử chỉ riêng thì các cử chỉ đó giữ nguyên.
- **Điều khiển đọc theo danh sách mới:** phần tử → ký tự → từ → câu → đoạn → tiêu đề → điều khiển → liên kết → tốc độ đọc → phần tử (`ReadingControl`). Trước: phần tử → tiêu đề → liên kết → đoạn → câu → từ → ký tự. Mới: **Điều khiển** (nhảy tới nút, ô nhập, công tắc... kế/trước, dùng lại chế độ đọc có sẵn qua `FocusNavigator.moveToMode`, không đổi chế độ đọc của vuốt phải/trái) và **Tốc độ đọc** (vuốt lên = nhanh hơn, xuống = chậm hơn, mỗi bước 10% trong khoảng 50%–200% của thanh trượt ở Cài đặt giọng đọc, áp ngay và đọc lại tốc độ mới; `SpeechRate`). "Phần tử" (mặc định) và "câu" là hai mục ứng dụng thêm so với bảng chuẩn.
- **Ô nhập dời con trỏ thật:** vuốt xuống/lên khi đang ở ô nhập (không phải mật khẩu) dời con trỏ bằng `ACTION_SET_SELECTION` theo đơn vị của điều khiển (với "Phần tử": từng ký tự; với ký tự/từ/câu/đoạn: đúng đơn vị đó) và đọc đoạn chữ con trỏ vừa đi qua; ô trống hoặc đã tới đầu/cuối chữ thì lần vuốt kế sang phần tử kế/trước để không kẹt trong ô. Ô mật khẩu: không dời con trỏ, không đọc chữ, chỉ sang phần tử kế/trước. Phép tính nằm ở `CaretMath` (hàm thuần: tiến tới CUỐI đơn vị kế, lùi tới ĐẦU đơn vị trước, ký tự theo cụm ký tự người dùng thấy nên không cắt dấu thanh rời hay emoji); `FocusNavigator.moveCaret` thực thi và ghi nhận `lastOwnSelectionMs` để sự kiện "vùng chọn đổi" dội lại không bị đọc thêm. Không gửi lại `ACTION_FOCUS` khi ô đã giữ tiêu điểm nhập.
- **Phát/tạm dừng nhạc:** hành động mới `MEDIA_PLAY_PAUSE` gửi cặp phím `KEYCODE_MEDIA_PLAY_PAUSE` bằng `AudioManager.dispatchMediaKeyEvent` (không cần quyền; không có trình phát thì không có gì xảy ra). Có trong trình đơn chung → Khác.
- **Kiểu ba ngón vuốt:** thêm "Đổi điều khiển đọc và chuyển trang" (mặc định mới, `SwipeProfile.READING_CONTROLS`); "Đọc theo đơn vị và chuyển trang" thành lựa chọn thường.
- **Chuỗi:** năm chuỗi mới (tên hành động nhạc, câu báo tốc độ đọc, tên kiểu ba ngón vuốt, tiêu đề và nội dung mục "Cử chỉ mặc định" trong Trợ giúp) và hai chuỗi sửa (nội dung mục "Điều khiển đọc" trong Trợ giúp, bỏ "(mặc định)" khỏi kiểu đơn vị). Đủ 7 ngôn ngữ, bản dịch do máy, cần người bản ngữ rà lại.
- **Cố ý khác bảng chuẩn / chưa làm:** hai ngón chạm = **dừng đọc** (chuẩn là tạm dừng/tiếp tục; bộ đọc của Android không có tạm dừng giữa chừng); chưa có điều khiển "Dòng" (cần đo dòng hiển thị thật) và "Ngôn ngữ"; "Tìm trên màn hình" là hành động riêng chứ chưa thành điều khiển đọc; chưa có chế độ chọn văn bản (hai ngón chạm hai lần và giữ), trả lời/cúp cuộc gọi bằng hai ngón chạm hai lần, lệnh giọng nói (phải-rồi-lên), luyện cử chỉ/trợ giúp/cử chỉ đi xuyên bằng bốn ngón, chỉnh thanh trượt bằng phải-rồi-trái / trái-rồi-phải. "Đọc từ phần tử đang chọn" gần với "đọc từ phần tử kế" của bảng chuẩn nhưng bắt đầu từ chính phần tử đang chọn. Một trang trợ giúp khác của Google nói ba ngón vuốt trái/phải đổi điều khiển đọc, còn trang bảng cử chỉ chính thức thì không; bản này theo trang bảng cử chỉ (ba ngón vuốt trái/phải vẫn chuyển trang). Ba ngón vuốt lên từ mép dưới vẫn thuộc về nút hỗ trợ tiếp cận của hệ thống.
- **Rủi ro cần biết:** trước đây ba cử chỉ hai bước bắt đầu bằng trái/phải để trống vì cú vuốt trái/phải hơi cong dễ bị nhận nhầm; nay chúng mở Ứng dụng gần đây, Thông báo và Tìm chữ (đúng chuẩn). Ai hay bị nhầm thì gán lại hoặc bỏ gán trong mục Cử chỉ.
- Kiểm thử: 635 bài JVM (mới: `CaretMathTest`, `SpeechRateTest`; cập nhật `GestureTest`, `ReadingControlTest`, `ReadingControlGestureTest`, `SwipeProfileTest`, `QuantityStringsTest`). **Chưa** chạy Gradle/Compose/lint và chưa thử trên máy thật. Cần thử trên máy: dời con trỏ bằng vuốt trong nhiều loại ô nhập (EditText, Compose, WebView), phím media với nhiều trình phát, vuốt ngang có bị nhận nhầm thành trái-rồi-lên / phải-rồi-xuống không, đổi tốc độ đọc nghe rõ, ba ngón vuốt xuống/lên đổi điều khiển.

## Bản 2.19.0: "điều khiển đọc" cho vuốt một ngón lên/xuống (theo bảng cử chỉ chuẩn)

- **Vuốt một ngón xuống = tiến, lên = lùi, theo "điều khiển đọc" đang chọn** (`ReadingControl`, `FocusNavigator.readingControl`). Ban đầu là *Phần tử* (như vuốt phải/trái). Vuốt **lên rồi xuống** = điều khiển KẾ, **xuống rồi lên** = điều khiển TRƯỚC; ứng dụng đọc "Điều khiển đọc: <tên>". Các điều khiển xếp vòng tròn: phần tử → tiêu đề → liên kết → đoạn → câu → từ → ký tự → phần tử (thứ tự và danh sách đổi ở 2.20.0). Thứ tự lên-rồi-xuống / xuống-rồi-lên theo bảng cử chỉ chuẩn của Android; một bản mô tả trước đó đảo ngược hai cử chỉ này, ai quen kiểu đảo thì tự đổi trong mục Cử chỉ.
- **Phần tử / tiêu đề / liên kết** dùng lại `moveElement` và `quickMove` (trong web dùng hành động duyệt chuẩn của nền tảng; ngoài web tự cuộn tìm tiếp như trước). Chế độ đọc cũ (`ReadingMode`, đổi bằng hành động "chế độ đọc kế/trước") là trục riêng chỉ tác động vuốt phải/trái; điều khiển đọc không đụng tới nó.
- **Đoạn / câu / từ / ký tự:** mỗi lần vuốt đọc một đơn vị của phần tử đang chọn (`moveUnit`). Hết chữ (hoặc phần tử không có chữ) thì sang phần tử kế/trước và đọc cả phần tử đó như vuốt phải/trái (`FocusNavigator.moveToNeighbour`). Lùi sang phần tử trước thì con trỏ chữ đặt ở CUỐI phần tử (`TextCursor.parkAtEnd`) để vuốt lên tiếp đọc đơn vị cuối cùng thay vì nhảy qua cả phần tử. Ba ngón vuốt xuống/lên (đơn vị kế/trước) giữ như cũ: dừng và báo "hết văn bản" (từ 2.20.0 ba ngón vuốt xuống/lên đổi điều khiển đọc).
- **Đồng bộ với "đổi đơn vị đọc"** (hai ngón chạm ba lần): điều khiển đọc đi theo đơn vị mới; ngược lại chọn một điều khiển theo đơn vị chữ cũng đặt đơn vị của con trỏ chữ (`TextCursor.select`, giữ chỗ đang đứng) nên "sao chép đơn vị" và ba ngón vuốt dùng đúng đơn vị đang chọn. Con trỏ chữ nay luôn bắt đầu lại khi sang phần tử khác, kể cả hai phần tử có chữ giống hệt (danh sách nút "Xóa").
- **Thanh trượt:** đang chọn thanh trượt thì vuốt lên = tăng, xuống = giảm, bất kể điều khiển đang chọn (`adjustRange`). Công tắc "Cử chỉ cuộn chỉnh thanh trượt" chỉ còn tác dụng với hành động "Cuộn xuống/lên" do bạn tự gán.
- **Điều khiển đọc tự về "Phần tử" khi cửa sổ đổi** (`onWindowChanged`, cùng chỗ với chế độ đọc cũ). "Đọc trạng thái" (bốn ngón chạm hai lần) nhắc điều khiển đang chọn khi khác "Phần tử".
- **Trong trình đơn,** vuốt xuống/lên chuyển mục y như vuốt phải/trái (`MenuGestures.HANDLED`, `ReaderSession.handleMenuAction`); đổi điều khiển trong trình đơn chỉ nhận một lời nhắc ngắn.
- **Mặc định đổi** (`GestureMapping.defaults`): vuốt xuống/lên (trước là cuộn), lên-rồi-xuống / xuống-rồi-lên (trước là "sao chép đơn vị" / "chạy tiện ích"). **Cuộn trang nay bằng hai ngón vuốt lên/xuống** (Android xử lý), hoặc gán "Cuộn xuống/lên" cho cử chỉ bất kỳ. "Sao chép đơn vị đang đọc" và "Chạy các tiện ích đã bật" không còn gán sẵn: vẫn có trong trình đơn phần tử / trình đơn chung (mục Khác) và gán được trong Cử chỉ. Ai đã lưu cử chỉ riêng thì giữ nguyên các cử chỉ đó (cấu hình chỉ lưu phần khác mặc định); ai chưa chỉnh vuốt lên/xuống sẽ nhận hành vi mới ngay khi cập nhật.
- **Chuỗi:** bốn hành động mới ("Tiến theo điều khiển đọc", "Lùi theo điều khiển đọc", "Điều khiển đọc kế tiếp/trước đó") và lời báo "Điều khiển đọc: …"; mục "Điều khiển đọc" mới trong Trợ giúp (và trong tìm kiếm cài đặt); lời giới thiệu mục Tiện ích sửa theo việc không còn cử chỉ mặc định. Đủ 7 ngôn ngữ, bản dịch do máy, cần người bản ngữ rà lại.
- Kiểm thử: 610 bài JVM (mới: `ReadingControlTest`, `TextCursorControlTest`, `ReadingControlGestureTest`; sửa hai khẳng định mặc định trong `GestureTest`). **Chưa** chạy Gradle/Compose/lint và chưa thử trên máy thật. Cần thử trên máy: vuốt lên rồi xuống / xuống rồi lên đổi điều khiển và nghe tên; đi từng từ tới hết phần tử rồi sang phần tử kế (phần tử mới được đọc cả, vuốt xuống tiếp đọc từ đơn vị đầu của nó nên từ đầu có thể nghe lặp) và đi ngược qua phần tử trước; thanh trượt tăng/giảm đúng chiều; hai ngón vuốt vẫn cuộn; trình đơn vuốt xuống/lên.
- **Chưa làm ở bản này (cả ba việc đầu đã làm ở 2.20.0):** vuốt lên/xuống trong ô nhập chưa dời con trỏ thật (mới chỉ đọc theo đơn vị; dời con trỏ cần thử trên máy); ba ngón vuốt lên/xuống vẫn là đơn vị trước/kế (có thể đổi thành đổi điều khiển nếu muốn); mặc định Màn hình chính / Quay lại vẫn là xuống-rồi-trái / lên-rồi-trái, còn bảng chuẩn là lên-rồi-trái = Màn hình chính, xuống-rồi-trái = Quay lại (đổi được trong Cử chỉ; đổi mặc định nếu muốn đúng chuẩn).

## Bản 2.18.1: hai ngón vuốt theo chuẩn, bỏ lối thoát khẩn cấp, rà soát chống sập

- **Hai ngón vuốt nay theo chuẩn các trình đọc màn hình lớn.** Trước đây dịch vụ bật cờ cử chỉ nhiều ngón nhưng KHÔNG bật `FLAG_REQUEST_2_FINGER_PASSTHROUGH`, nên hệ thống nuốt cả bốn cú hai ngón vuốt thành "cử chỉ" gửi cho dịch vụ (kể cả khi bắt đầu từ mép màn hình) và dịch vụ tự cuộn bằng hành động trợ năng; điều hướng bằng cử chỉ của Android bằng hai ngón (vuốt lên từ mép dưới = Màn hình chính, vuốt lên và giữ = Ứng dụng gần đây, vào từ mép trái/phải = Quay lại, vuốt xuống từ mép trên = Thông báo) không bao giờ tới hệ thống. Nay cờ này luôn bật (đặt lúc chạy trong `ReaderSession.applyServiceFlags`, không phụ thuộc tên thuộc tính XML của từng bản SDK): hai ngón vuốt được chuyển nguyên cho ứng dụng/Android như một ngón vuốt. Ba ngón vuốt lên từ mép dưới thuộc về nút hỗ trợ tiếp cận của hệ thống.
- **Hệ quả:** bốn cú hai ngón vuốt không còn gán lại được và không hiện trong "Cử chỉ" (`Gesture.passedToSystem`; chỉ còn một dòng giải thích). Cấu hình cũ vẫn đọc được; mặc định cũ (cuộn / chuyển trang) giữ làm dự phòng cho máy vẫn gửi các cử chỉ này tới dịch vụ. Bộ vuốt gán sẵn (Cuộn và chuyển trang, Duyệt nhanh...) chỉ còn ở nhóm ba ngón (`GestureAnalyzer.hasProfile`). Ai đã gán riêng cho hai ngón vuốt (ví dụ Duyệt nhanh = tiêu đề kế/trước) sẽ thấy các gán đó không còn chạy: dùng ba ngón vuốt thay thế.
- **Cuộn gốc của Android không còn đi qua `FocusNavigator.scroll`**, nên không còn lời "Đã cuộn xuống/lên"; thay vào đó có "Đọc phạm vi danh sách" (Cài đặt → Đọc). Khi danh sách ngừng cuộn 450 ms mà phần tử đang chọn đã khuất khỏi màn hình, `FocusNavigator.releaseIfScrolledAway` bỏ nó để lần vuốt kế bắt đầu từ phần tử đầu tiên đang hiện (phần tử vẫn hiện thì giữ nguyên, kể cả khi ứng dụng tự cuộn để đưa nó vào màn hình).
- **Đã bỏ lối thoát khẩn cấp** (`TOGGLE_TOUCH_EXPLORATION`: hai phím âm lượng cùng lúc, Alt+E, tự bật lại sau 10 phút, cờ khám phá cảm ứng bật/tắt lúc chạy). Lý do: không trình đọc lớn nào làm vậy; dễ bấm nhầm khi cầm máy và lúc đó mọi cú chạm của người khiếm thị thành bấm thật; và việc chiếm phím âm lượng làm hỏng chính phím tắt hỗ trợ tiếp cận của Android (giữ hai phím), vốn là lối thoát đáng tin hơn vì nằm ngoài dịch vụ. Hai phím cùng lúc (`VOLUME_BOTH`) vẫn là cử chỉ gán được nhưng không gán sẵn; cấu hình cũ nhắc tới hành động đã bỏ được bỏ qua mà không mất phần còn lại. Alt+P (tạm dừng phím) vẫn có.
- **Phím âm lượng làm phím tắt nay mặc định TẮT** (các bản 2.14.0–2.18.0 mặc định bật chỉ để có lối thoát khẩn cấp). Ai đã tự bật/tắt trong Cài đặt thì giữ nguyên; ai chưa đụng tới cần bật lại ở Cài đặt → Đọc nếu muốn. Mô tả trong ứng dụng nói rõ: khi bật, phím tắt hỗ trợ tiếp cận của Android (giữ hai phím âm lượng) không dùng được lúc màn hình sáng.
- **Chống sập (rà soát toàn bộ):** `ScreenReaderService` bọc try/catch mọi callback và việc tạo/đóng phiên; `ReaderSession.guardMain` bọc các điểm vào ở luồng chính; `VoiceEngine`/`SpeechEngine` bảo vệ callback TTS và watchdog, `isSpeaking` đúng ở chế độ một công cụ; `Texts.lookup` lùi về chuỗi tiếng Việt dự phòng (rồi tên khóa) thay vì ném lỗi khi thiếu tài nguyên; `Diag` đọc/xóa không ném lỗi và nút sao chép chỉ chép tối đa 100.000 ký tự cuối (clipboard có giới hạn Binder), báo thật khi chép thất bại; Sao lưu/Khôi phục chạy ở luồng nền và giới hạn dung lượng tệp; danh sách ứng dụng trong "Cử chỉ theo ứng dụng" nạp ở luồng nền; `VnApplication` cài bộ ghi lỗi trước tiên và bọc từng bước; bỏ các chỗ dùng `!!`.
- **Thêm:** mục "Cử chỉ hệ thống bằng hai hoặc ba ngón" và "Hai công cụ giọng nói" trong Trợ giúp (7 ngôn ngữ, bản dịch do máy, cần người bản ngữ rà lại).
- Kiểm thử: 584 bài JVM (mới: `SystemGestureTest`, bổ sung `DiagLogTest`, `TextsTest`). **Chưa** chạy Gradle/Compose/lint và chưa thử trên máy thật. Cần thử trên máy: hai ngón vuốt lên từ mép dưới về Màn hình chính (bật điều hướng bằng cử chỉ), hai ngón vuốt cuộn danh sách và chuyển trang, đọc phạm vi danh sách sau khi cuộn, hai công cụ giọng nói, đọc người gọi. Nếu cờ hai ngón không có tác dụng trên một dòng máy (nhà sản xuất tùy biến), cử chỉ hai ngón vẫn rơi về mặc định cũ (cuộn/chuyển trang).

## Bản 2.18.0: ghép dòng v31–v33 vào dòng hai công cụ giọng nói

- **Giữ nguyên** từ dòng hiện tại: hai công cụ giọng nói, chọn ngôn ngữ cho từng công cụ, cử chỉ đổi chế độ giọng, chế độ đọc theo loại, vùng chứa/cửa sổ kế/trước, mức chi tiết, nhật ký.
- **Thêm** từ dòng v31–v33: cử chỉ riêng theo ứng dụng, sao lưu và khôi phục cài đặt, tìm kiếm trong cài đặt, bộ lọc đọc thông báo (không làm phiền, đang gọi, đang phát nhạc, từ khóa chặn/luôn đọc), nhập phím bằng nhấc tay, đọc Toast, phím tắt bàn phím ngoài, phím âm lượng và nút tai nghe làm cử chỉ, thanh trượt, lối thoát khẩn cấp, tự chuyển tiêu điểm vào hộp thoại, nhớ vị trí theo cửa sổ, tùy chọn đọc khi gõ, đọc phạm vi danh sách, đọc người gọi đến, nói vị trí hiện tại, xóa/khôi phục chữ trong ô nhập.
- **Đọc người gọi đến chỉ còn MỘT công tắc** (Cài đặt → Đọc → Cuộc gọi và vị trí). Bật lên thì xin quyền cuộc gọi (bắt buộc), rồi xin thêm quyền danh bạ (tùy chọn): được cấp thì đọc tên trong danh bạ, không thì chỉ đọc số. Công tắc "tên từ danh bạ" cũ đã bỏ; khóa `call_names_contacts` cũ nếu có trong tệp sao lưu sẽ bị bỏ qua.
- **Đã bỏ** phần đọc mã xác thực (như dòng hiện tại), ngưỡng 64 ms cho Android 16 của phím âm lượng (không có nguồn kiểm chứng độc lập; tổ hợp hai phím nay luôn nhận), và mọi nhắc tới tên ứng dụng khác trong chuỗi giao diện.
- **Hòa giải xung đột:** `ReaderSession` (đường cử chỉ qua `GestureRouter` giữ nguyên, thêm `runAction` cho phím); `FocusNavigator.focusOn(node, prefix, interrupt)`; engine TTS đã chọn hỏng thì rơi về mặc định và báo một lần (chuyển vào `VoiceEngine`); trình đơn chỉ tính cử chỉ cảm ứng khi kiểm tra "còn cử chỉ cho phần tử kế" (phím âm lượng không được che mất lỗi kẹt trình đơn).
- `Gesture.fromSystemId` vẫn từ chối mã âm; mã âm của phím cứng chỉ dùng nội bộ.
- Chưa chạy Gradle/lint/Compose ở môi trường soạn thảo (chỉ có biên dịch và 569 bài kiểm thử JVM). Hãy chạy CI và gửi log nếu có lỗi.

## Bản 2.17.1: sửa lỗi build trên CI

- **Lỗi từ log CI:** thiếu `import androidx.compose.foundation.layout.padding` trong `GestureSettingsScreen.kt` (không báo ở bản kiểm tra offline vì không biên dịch Compose); đã thêm. Đã quét mọi tệp Compose khác tìm import thiếu tương tự: không còn.
- **Tệp cũ còn sót trong kho mã:** tải zip lên chỉ thêm/ghi đè tệp, KHÔNG xóa tệp đã bỏ, nên `ai/CaptchaReader.kt` cũ vẫn nằm đó và làm lỗi biên dịch. 9 tệp đã bỏ nay có mặt trong zip dưới dạng tệp RỖNG (chỉ có dòng `package`) để ghi đè bản cũ: `CaptchaImageMath`, `CaptchaImagePrep`, `CaptchaReader`, `CaptchaPolicy`, `NodeVerbosity` và 4 tệp test `Captcha*Test`. Có thể xóa hẳn chúng sau.

## Bản 2.17.0: chọn ngôn ngữ cho cả hai công cụ, thêm Pháp/Tây Ban Nha/Đức/Ý/Bồ Đào Nha

- **Công cụ thứ nhất chọn được ngôn ngữ** (Cài đặt → Giọng đọc): mặc định "Theo ngôn ngữ ứng dụng"; cũng áp dụng ở chế độ một công cụ.
- **Danh sách ngôn ngữ chung cho cả hai công cụ:** Anh, Việt, Pháp, Tây Ban Nha, Đức, Ý, Bồ Đào Nha, Trung, Nga, Ả Rập, Nhật, Hàn. Hai công cụ cùng một ngôn ngữ thì không tách văn bản.
- **Nhận ngôn ngữ (heuristic, có test):** khác hệ chữ → theo hệ chữ. Việt + ngôn ngữ Latin khác: chữ có dấu/ký tự chỉ có trong tiếng Việt là Việt; từ mà bỏ hết dấu vẫn không thành âm tiết tiếng Việt hợp lệ ("café", "señor", "Straße", "Bluetooth") thuộc ngôn ngữ kia. Pháp/Tây Ban Nha/Ý/Bồ Đào Nha có dấu trùng tiếng Việt nên dấu đơn thuần chưa đủ để kết luận. Hai ngôn ngữ Latin không có tiếng Việt: dùng danh sách từ chức năng thông dụng và chữ có dấu (khi một bên là tiếng Anh). Từ không có bằng chứng là trung tính, theo từ đứng trước.
- Từ trung tính ở ĐẦU văn bản nay thuộc ngôn ngữ thứ nhất (trước đây theo từ mạnh đầu tiên, gây sai với "Xin chào señor").
- 3 chuỗi mới (dịch máy). Chưa thử với engine thật; danh sách từ chức năng nhỏ nên câu rất ngắn dễ nhận sai.

## Bản 2.16.2: rà soát

- Khi ngôn ngữ ứng dụng trùng ngôn ngữ của công cụ thứ hai (ví dụ cả hai là tiếng Anh) thì không tách văn bản nữa, đọc hết bằng công cụ thứ nhất (trước đây có thể đẩy nhầm vài từ sang công cụ thứ hai). Có test.
- Đã đọc lại thứ tự khóa giữa `SpeechEngine` và `VoiceEngine` (không có đường khóa ngược nhau), thứ tự "đọc xong" và đồng hồ canh, việc áp chế độ từ luồng nền: không thấy lỗi khác. Chưa thử với hai engine thật.

## Bản 2.16.1: đơn giản hóa phần chọn công cụ đọc

- **Chỉ còn hai lựa chọn:** *Một công cụ* (chọn một công cụ duy nhất) hoặc *Hai công cụ* (chọn cả hai: công cụ thứ nhất đọc ngôn ngữ ứng dụng, công cụ thứ hai đọc ngôn ngữ đã chọn). Bỏ chế độ "Chỉ công cụ thứ hai" gây rối. Giá trị cũ `SECOND_ONLY` đã lưu từ bản 2.15 tự rơi về "Một công cụ".
- Màn hình: chọn chế độ trước, rồi hiện ngay các bộ chọn công cụ tương ứng (một hoặc hai). Cử chỉ "Đổi chế độ công cụ đọc" nay đổi qua lại giữa hai chế độ.
- Chưa thử với hai engine thật trên máy; chưa build Gradle/Compose.

## Bản 2.16.0: chia văn bản theo câu (như chế độ tự nhận ngôn ngữ của các bộ đọc nhiều engine)

- **Cài đặt → Giọng đọc → Cách chia văn bản** (hiện khi chọn "Hai công cụ"): *Theo từ* (đổi công cụ tại từng từ của ngôn ngữ kia, như bản 2.15) hoặc *Theo câu* (mỗi câu do MỘT công cụ đọc trọn, theo ngôn ngữ chiếm nhiều từ hơn trong câu; hòa thì theo câu trước). Theo câu mượt hơn và ít đổi giọng; "Bật Bluetooth để kết nối." vẫn đọc trọn bằng giọng tiếng Việt.
- Tách câu theo dấu `. ! ? … ؟` (cần khoảng trắng sau) và `。！？` (không cần). Ghép các đoạn lại luôn bằng đúng văn bản gốc (có test).
- Học từ mô tả công khai của các bộ đọc nhiều engine (chế độ theo từ và chế độ tự nhận theo câu); không dùng mã của ứng dụng nào.
- 4 chuỗi mới (dịch máy). Chưa thử với hai engine thật trên máy.

## Bản 2.15.1: rà soát hai công cụ đọc

- **Cảnh báo thiếu giọng:** trước đây công cụ này báo đủ giọng sẽ xóa cảnh báo thiếu giọng của công cụ kia. Nay trạng thái được gộp: thiếu ở bất kỳ công cụ nào đang dùng thì vẫn báo.
- **Câu báo khi đổi chế độ bằng cử chỉ:** áp chế độ ngay rồi mới đọc, nên câu báo dùng đúng công cụ mới và không bị cắt khi công cụ cũ đóng. `SpeechEngine.configure` gọi được từ luồng bất kỳ.
- **Tách ngôn ngữ:** dạng rút gọn tiếng Anh có dấu nháy ("don't", "it's") nay được coi là tiếng Anh thay vì trung tính.
- Test thêm: `LanguageRunsContractionTest`. Chưa thử với hai engine thật trên máy.

## Bản 2.15.0: hai công cụ đọc, mỗi công cụ một ngôn ngữ

- **Cài đặt → Giọng đọc → Chế độ công cụ đọc:** *Một công cụ* (mặc định, như cũ) / *Hai công cụ, mỗi công cụ một ngôn ngữ* / *Chỉ công cụ thứ hai*. Công cụ thứ nhất đọc ngôn ngữ ứng dụng (ví dụ tiếng Việt), công cụ thứ hai đọc ngôn ngữ bạn chọn (mặc định tiếng Anh; có thể chọn Trung, Nga, Ả Rập, Nhật, Hàn). Tắt bớt một công cụ bằng cách đổi chế độ: công cụ không dùng được đóng kết nối ngay.
- **Cử chỉ mới "Đổi chế độ công cụ đọc"** (không gán mặc định): xoay vòng ba chế độ và đọc tên chế độ.
- **Cách tách ngôn ngữ** (`LanguageRuns`, có test): khác hệ chữ thì tách theo hệ chữ (chắc chắn). Việt + Anh: từ có dấu là tiếng Việt; từ không dấu không khớp cấu trúc một âm tiết tiếng Việt ("Bluetooth", "wifi", "settings") là tiếng Anh; từ ngắn nhập nhằng ("to", "can") theo từ đứng trước. Đây là heuristic: từ rất ngắn hoặc tên riêng lạ có thể bị giao nhầm công cụ. Cặp Latin không có tiếng Anh (ví dụ Pháp + Tây Ban Nha) không tách.
- **Phát tuần tự** (`RunScheduler`, có test): hai TextToSpeech không có hàng đợi chung nên mỗi lúc chỉ một đoạn được phát; ngắt dừng cả hai công cụ; có đồng hồ canh để hàng đợi không kẹt nếu một công cụ chết giữa chừng. Chế độ một công cụ đi thẳng đường cũ, không qua bộ điều phối.
- Mã: `SpeechEngine` nay là lớp ghép; mỗi kết nối TTS nằm trong `VoiceEngine` (mã cũ của `SpeechEngine`, thêm ngôn ngữ riêng và báo "đọc xong").
- 11 chuỗi mới (dịch máy, cần người bản ngữ rà soát). Chưa chạy trên máy thật: cần thử với hai engine thật (ví dụ Google + một engine khác), kiểm tra không đọc chồng và độ trễ khi đổi giọng giữa câu.

## Bản 2.14.1

- Sửa test `GestureRouterTest` (kỳ vọng sai: trong trình đơn, vuốt phải là "mục kế", không phải hành động ngoài trình đơn). Mã chạy đúng, chỉ test sai nên CI sẽ đỏ. Đã đối chiếu mọi hằng số `AccessibilityService.GESTURE_*` với android.jar API 36: đều tồn tại.

## Bản 2.14.0: sửa lỗi tồn đọng (cử chỉ, TTS, ổn định) và phần ngôn ngữ

Rà soát bản 2.13.0 (đối chiếu hành vi với một trình đọc màn hình khác, không sao chép mã) và vá các lỗi tìm thấy.

- **Cử chỉ:** `ReaderSession.handleGesture` trước đây tính `inMenu` và hành động ngay trên luồng chính nhưng chạy sau trên luồng nền,
  nên vuốt nhanh hai lần có thể dùng trạng thái trình đơn đã cũ. Nay `GestureRouter` (thuần hàm, có test) được gọi hai lần: một lần
  trên luồng chính chỉ để báo "đã xử lý" và ngắt lời đọc, một lần trên luồng xử lý ngay trước khi chạy hành động (kết quả chính thức).
- **Mã cử chỉ hệ thống:** bỏ `SystemGestureIds` (tra tên bằng reflection, gõ sai tên thì cử chỉ lặng lẽ biến mất). minSdk 35 nên dùng
  thẳng hằng số `AccessibilityService.GESTURE_*`; sai tên sẽ báo lỗi biên dịch. Bỏ `Gesture.isSupported` và dòng nhật ký `GESTURES unsupported`.
- **TTS tự phục hồi:** engine bị tắt hoặc vừa cập nhật khiến mọi lệnh đọc trả `ERROR` và máy im lặng đến khi tắt/bật dịch vụ. Nay
  `SpeechEngine` tạo lại engine khi `speak` trả `ERROR` hoặc `onError(ERROR_SERVICE)`, đọc lại câu vừa lỡ, có giới hạn
  (`SpeechRecoveryPolicy`: tối đa 3 lần/phút, cách nhau ≥ 1,5 giây; đọc xong một câu thì xóa bộ đếm).
- **Ổn định:** mọi `CoroutineScope` của dịch vụ có `CoroutineExceptionHandler` (`CoroutineGuard`, ghi vào nhật ký lỗi). `runSafely` bắt thêm
  `VirtualMachineError` (hết bộ nhớ, tràn ngăn xếp) và báo "hành động thất bại". `AiAssistant` bắt `OutOfMemoryError` khi xử lý ảnh chụp.
- **Ngôn ngữ:**
  - Tiếng Trung: dấu `。！？` kết thúc câu không cần khoảng trắng phía sau; "từ" của cụm chữ Hán/Nhật/Thái được tách tiếp bằng `BreakIterator`
    (từ điển ICU của Android; trên JVM thử nghiệm không tách được nên test chỉ kiểm tra các tính chất bất biến). Thêm dấu `؟ ۔` của tiếng Ả Rập.
  - Ký tự theo cụm ký tự người dùng thấy (`Graphemes`): dấu thanh viết rời (NFD), emoji màu da/ZWJ, cờ, cặp surrogate không bị tách khi
    duyệt từng ký tự và khi đánh vần (`SpeechFormats.spell` trước đây duyệt từng `Char` UTF-16). Văn bản được chuẩn hóa NFC trước khi đọc.
  - Thiếu giọng cho ngôn ngữ ứng dụng: dịch vụ nhắc bằng lời một lần mỗi ngôn ngữ, và màn hình Giọng đọc hiện nút **Cài dữ liệu giọng**
    (`ACTION_INSTALL_TTS_DATA`). Trước đây chỉ ghi log.
  - `SpeechChunker` (văn bản > 4000 ký tự) cắt được sau dấu toàn chiều rộng và dấu hỏi tiếng Ả Rập; `LinkRoles` nhận vai trò "liên kết" ở cả
    es/fr/ru/ar/zh; `SkipAdPlugin` có từ khóa bằng es/fr/ru/zh/ar.
- **Nhỏ:** `DiagFile` giới hạn theo BYTE (trước đây tính theo số ký tự nên tệp tiếng Việt vượt ngân sách); sửa chú thích enum `Gesture`.
- **Chuỗi mới:** 5 chuỗi (`msg_tts_voice_missing`, `vo_voice_*`) thêm vào `tools/i18n/table_d.py` rồi chạy bộ sinh. Bản dịch là dịch máy, cần người bản ngữ rà soát.
- **Phiên bản:** `versionCode` 39, `versionName` 2.14.0.
- **Test mới:** `GestureRouterTest`, `GestureIdsTest`, `SpeechRecoveryPolicyTest`, `GraphemesTest`, `TextUnitsLanguageTest`, `SpeechFormatsSpellTest`,
  `DiagFileBytesTest`, `SpeechChunkerCjkTest`, `LinkRolesTest`.
- **Chưa làm / cần quyết định:** khi trình đơn đang mở, chạm hai ngón (`STOP_SPEECH`) vừa dừng đọc vừa đóng trình đơn; chưa đổi vì có thể là chủ ý.
  Các tính năng còn thiếu so với trình đọc khác (phím cứng, `NotificationListenerService`, trạng thái cuộc gọi/màn hình, hồ sơ theo ứng dụng,
  xuất/nhập cài đặt) chưa làm.
- **Chưa kiểm chứng:** môi trường soạn thảo không có trình biên dịch Kotlin, Gradle hay Android SDK nên chưa chạy build, lint hay
  `./gradlew :app:testDebugUnitTest`. Đã kiểm cân ngoặc, nhất quán chuỗi bằng bộ sinh, và đối chiếu logic tách câu/ký tự bằng bản thử Java trên JDK 21.
  Cần chạy build và thử trên máy thật (nhất là phục hồi TTS và tách từ tiếng Trung).

## Bản 2.13.0: hợp nhất nhánh 2.11.0 với nhánh 2.12.x

Lấy bản 2.11.0 làm nền (giữ nguyên các tính năng của nó) và đưa vào những phần còn thiếu:

- **Đã bỏ** toàn bộ phần đọc mã xác thực khỏi mã nguồn, chuỗi, cử chỉ và trình đơn; không còn mục nào liên quan.
- **Mức chi tiết và gợi ý thao tác:** dùng một bản duy nhất (`Verbosity`, `ActionHints`); bỏ bản trùng.
- **Thêm vào nền 2.11.0:** chế độ đọc theo loại, vùng chứa kế/trước, cửa sổ kế/trước, 11 cử chỉ mới (tra theo tên lúc chạy, máy không có thì ẩn), vuốt trang có kiểm tra màn hình đổi, nhật ký chẩn đoán tự động (chỉ siêu dữ liệu), trình đơn mở thẳng mục đầu, gợi ý cho ảnh không nhãn, giao diện gọn (mỗi cử chỉ một điểm dừng, không tiêu đề thừa).
- **Giữ của nhánh 2.11.0:** bám vết tiêu điểm, `ClickResolver`, duyệt nhanh tiêu đề/liên kết, cử chỉ 2-3 ngón theo bộ gán sẵn, nhật ký lỗi, màn hình Quyền, plurals.
- Chưa chạy Gradle/lint/Compose/ML Kit ở môi trường soạn thảo; cần chạy `./gradlew :app:testDebugUnitTest` và thử trên máy thật.

## Bản 2.12.3

- **Chế độ đọc theo loại** (tiêu đề, liên kết, điều khiển, ô nhập, ô tích, hình ảnh): hành động "chế độ đọc tiếp theo/trước đó"; khi khác "phần tử", vuốt phần tử kế/trước nhảy theo loại và tự cuộn tìm tiếp (tối đa 4 lần, 4 giây). Tìm không ra thì trả lựa chọn về chỗ cũ. Chế độ tự về mặc định khi cửa sổ đổi; trạng thái ("Đọc trạng thái") nhắc chế độ đang dùng.
- **Vùng chứa và cửa sổ kế/trước** (hành động mới). Lựa chọn cửa sổ chỉ mất khi cửa sổ thật sự đổi. Plugin vẫn chạy trên cửa sổ đang hoạt động.
- **11 cử chỉ mới** (nhấn giữ nhiều ngón, bốn ngón vuốt/nhấn ba lần), tra theo tên hằng số lúc chạy; máy không có thì ẩn (nhật ký ghi `GESTURES unsupported=...`). Không gán mặc định.
- **Giao diện gọn hơn:** mỗi cử chỉ một điểm dừng; không tiêu đề/giới thiệu thừa ở màn hình cử chỉ và trình đơn; trình đơn mở thẳng mục đầu.
- **Cài đặt Đọc:** mức chi tiết (đầy đủ/gọn/tối giản), đọc gợi ý thao tác, **nhật ký chẩn đoán tự động** (chỉ siêu dữ liệu, không có chữ trên màn hình; sao chép để gửi).
- **Chuyển trang/cuộn:** thử hành động trước, rồi vuốt giả lập (`canPerformGestures`) và kiểm tra màn hình có đổi không; bám vết tiêu điểm khi giao diện vẽ lại; nhấn không nhấn đúp hai lần; chỉ nhấn nút con khi nó duy nhất; nhấn giữ có dự phòng ngữ cảnh/chạm giữ.

## Bản 2.15.0: đọc người gọi, nói vị trí hiện tại, xóa tất cả trong ô nhập

Cả ba đều TẮT mặc định hoặc chỉ xin quyền khi bạn bật; tắt công tắc là ứng dụng ngừng dùng quyền đó.

- **Đọc người gọi đến** (Cài đặt → Đọc → Cuộc gọi và vị trí). Quyền: `READ_PHONE_STATE` + `READ_CALL_LOG` (từ Android 9, số gọi đến chỉ có khi có cả hai; theo tài liệu TelephonyManager). Khi có `READ_CALL_LOG` hệ thống gửi MỖI hồi chuông hai broadcast (một có số, một không, thứ tự không đảm bảo; số rỗng = số lạ/ẩn): `CallRingPolicy` chỉ đọc một lần, chờ tối đa 1,2 giây cho bản có số. Thiếu quyền số thì chỉ đọc "Có cuộc gọi đến". Công tắc riêng "đọc tên từ danh bạ" (`READ_CONTACTS`, tra bằng `PhoneLookup`, chạy ngoài luồng chính). Số được đọc từng chữ số theo nhóm 3. Bộ nhận chỉ được đăng ký khi công tắc bật VÀ có quyền. Số/tên không bị ghi nhật ký hay lưu. Lưu ý: Google Play hạn chế `READ_CALL_LOG`; bản này dành cho cài trực tiếp.
- **Nói vị trí hiện tại** (Alt+G, hoặc gán cử chỉ "Nói vị trí hiện tại của tôi"; có trong trình đơn chung → Khác): quyền `ACCESS_FINE_LOCATION` + `ACCESS_COARSE_LOCATION`, công tắc "Cho phép nói vị trí của tôi". Chỉ hỏi vị trí MỘT lần khi bạn chạy hành động (không theo dõi, không lưu, không gửi): thử GPS tối đa 12 giây, rồi nhà cung cấp hợp nhất/mạng 6 giây, rồi vị trí cũ còn nhớ. Địa chỉ do `Geocoder` của hệ thống tra (dịch vụ vị trí của điện thoại có thể liên hệ nhà cung cấp qua internet; ứng dụng vẫn KHÔNG có quyền INTERNET); không có địa chỉ thì đọc vĩ độ/kinh độ 5 chữ số thập phân. Luôn đọc độ chính xác ("khoảng N mét"); sai số từ 50 m hoặc vị trí cũ hơn 2 phút thì nói rõ có thể chưa chính xác.
- **Xóa tất cả trong ô nhập** (Alt+X, trình đơn "Chỉnh sửa văn bản", hoặc gán cử chỉ) và **khôi phục chữ vừa xóa** (Alt+Shift+X): dùng `ACTION_SET_TEXT` rỗng, không đụng clipboard; chữ cũ giữ trong bộ nhớ (tối đa 20 000 ký tự) và chỉ khôi phục khi ô còn trống. Ô mật khẩu không bao giờ bị xóa hay được nhớ (theo `EditPolicy`).
- Mục "Quyền" nay liệt kê ba tính năng với trạng thái cấp quyền; `ManifestPermissionsTest` vẫn buộc quyền trong manifest khớp đúng `PermissionFeatures`.

Chưa làm: tự trả lời/từ chối cuộc gọi (cần `ANSWER_PHONE_CALLS`), đọc cuộc gọi khi tắt màn hình bằng nguồn khác ngoài broadcast, la bàn/hướng đi trong "nói vị trí", đọc đường phố giao nhau gần nhất, kiểm tra chính tả số theo từng quốc gia.

## Bản 2.14.0: phím âm lượng đúng kiểu, nút tai nghe, thanh trượt, lối thoát khẩn cấp (lối thoát khẩn cấp và mặc định bật phím âm lượng đã bỏ ở 2.18.1)

Phím âm lượng và cử chỉ:

- **Phím âm lượng không còn làm mất chỉnh âm lượng.** Phím bị chiếm thì chính trình đọc chỉnh âm lượng (`ReaderSession.adjustVolume`): trong cuộc gọi chỉnh âm cuộc gọi; đang đọc hoặc đang chạm màn hình chỉnh luồng trợ năng (đúng giọng đọc); còn lại chỉnh âm phương tiện (`VolumeStreamPolicy`). Không hiện bảng âm lượng hệ thống mà đọc phần trăm mới.
- **Phím cứng thành "cử chỉ" 0 ngón** (`Gesture.fingers = 0`, `systemId` âm, hệ thống không bao giờ gửi): `VOLUME_UP/DOWN_SHORT`, `VOLUME_UP/DOWN_LONG`, `VOLUME_BOTH`, `HEADSET_SHORT/DOUBLE/LONG`. Vì vậy gán lại được trong Cài đặt cử chỉ (nhóm "Phím âm lượng và nút tai nghe") và gán riêng cho từng ứng dụng bằng cơ chế sẵn có. Mặc định: bấm nhanh = tăng/giảm âm lượng; giữ tăng = phần tử trước, giữ giảm = phần tử kế; hai phím cùng lúc = lối thoát khẩn cấp; tai nghe: một lần = phần tử kế, hai lần = kích hoạt, giữ = đọc từ phần tử hiện tại.
- **Phím âm lượng bật mặc định** (trước là tắt) vì bấm nhanh không còn mất chức năng gốc và lối thoát khẩn cấp cần có sẵn. Tắt trong Cài đặt → Đọc → Phím nếu cần phím tắt trợ năng "giữ hai phím âm lượng" của hệ thống.
- **Lối thoát khẩn cấp** (`TOGGLE_TOUCH_EXPLORATION`): hai phím âm lượng cùng lúc, Alt+E hoặc một cử chỉ tạm dừng "duyệt bằng cách chạm" (bỏ cờ khám phá cảm ứng, cử chỉ nhiều ngón và nhấn đôi do dịch vụ xử lý) để dùng màn hình như bình thường khi trình đọc làm kẹt một màn hình. Trong lúc tạm dừng, phím âm lượng luôn được xử lý (bất kể cài đặt khác): bấm nhanh = chỉnh âm lượng, hai phím = bật lại; Alt+E và Alt+P luôn dùng được. Tự bật lại khi tắt màn hình, sau 10 phút, hoặc khi phiên đóng, nên không bao giờ kẹt vĩnh viễn.
- **Nút tai nghe** (`KEYCODE_HEADSETHOOK`, mặc định tắt): chỉ khi màn hình sáng và không trong cuộc gọi.
- **Thanh trượt**:
  - Cử chỉ cuộn (một/hai ngón vuốt lên/xuống, mặc định bật, có công tắc) đổi giá trị thanh trượt đang chọn ≈5% mỗi bước thay vì cuộn trang (`FocusNavigator.adjustRange`, dùng `ACTION_SET_PROGRESS`, không có thì cuộn tới/lui của chính nó). Từ 2.19.0 vuốt một ngón xuống/lên không còn là cuộn mà là "tiến/lùi theo điều khiển đọc", và luôn chỉnh thanh trượt đang chọn (không phụ thuộc công tắc này; công tắc chỉ còn tác dụng với hành động "Cuộn xuống/lên" do bạn tự gán).
  - Hành động riêng gán được: "Tăng/Giảm thanh trượt đang chọn", "Kéo thanh trượt đang chọn tới cuối". Thanh chuẩn thì đặt thẳng giá trị lớn nhất; núm kéo thì thực hiện một cú kéo từ tâm núm tới mép phải đường trượt (`dragToEnd`). Chỉ kéo thẳng theo lệnh của người dùng, KHÔNG giải mã xác thực ghép hình.

Chưa làm: bấm đúp/ba phím âm lượng, phím âm lượng điều khiển con trỏ khi sửa văn bản, hiện bảng âm lượng hệ thống, nhận lệnh phím khi tắt màn hình, kéo thanh trượt sang trái, thanh trượt dọc, trình đơn có sẵn mục thanh trượt.

## Bản 2.13.0: an toàn phím, màn hình tắt/bật, hộp thoại và nhớ vị trí, tùy chọn gõ phím, phạm vi danh sách

- **Lối thoát cho phím cứng/phím âm lượng**: Alt+P (hoặc cử chỉ "Tạm dừng/tiếp tục phím") tạm dừng cả hai, không lưu (khởi động lại dịch vụ là hoạt động lại). Alt+V (hoặc cử chỉ "Tắt/bật phím âm lượng cho ứng dụng này") ghi ứng dụng đang mở vào danh sách không dùng phím âm lượng (`volume_excluded_apps`). Hai hành động mới đã có trong danh sách cử chỉ, chưa gán mặc định.
- **Màn hình tắt/bật** (`ACTION_SCREEN_OFF/ON`): luôn dừng giọng đọc, bỏ trạng thái phím đang giữ dở, hủy việc AI/chuyển tiêu điểm đang chờ; luôn báo thêm bằng lời (từ bản 2.24.0 không còn công tắc): tắt màn hình đọc "Đã tắt màn hình", bật màn hình đọc giờ hiện tại, im lặng cả hai chiều khi đang đổ chuông hoặc trong cuộc gọi, và đóng trình đơn đang mở một cách im lặng (xem bản 2.20.6 và 2.24.0).
- **Tự chuyển tiêu điểm vào hộp thoại** (mặc định bật): cửa sổ có lớp `*Dialog*`/`*BottomSheet*` mở ra thì đọc tiêu đề rồi chọn phần tử đầu tiên, nhưng chỉ khi người dùng chưa tự chọn gì và không đang trong trình đơn.
- **Nhớ vị trí theo cửa sổ** (mặc định tắt): nhớ phần tử đang chọn khi rời cửa sổ (khóa = gói + tiêu đề, tối đa 8 cửa sổ) và tìm lại bằng vết (mã/nhãn) khi quay về.
- **Gõ phím**: đọc từng ký tự (mặc định bật, như cũ), đọc từ vừa gõ xong sau dấu cách/dấu câu (mặc định tắt), đọc "Chữ hoa" trước chữ viết hoa (mặc định tắt). Ô mật khẩu không bao giờ đọc từ hay chữ hoa. Chưa làm: đọc từ ví dụ cho chữ cái (cần bảng theo từng ngôn ngữ).
- **Đọc phạm vi danh sách khi cuộn** (mặc định tắt): "Mục 5 đến 9 trên 30" sau khi danh sách ngừng cuộn 450 ms; chỉ khi ứng dụng báo đủ `fromIndex/toIndex/itemCount` hợp lý.

Chưa build/chạy test trong môi trường soạn thảo: chạy `./gradlew :app:testDebugUnitTest :app:lintDebug` rồi thử trên máy thật.

## Bản 2.12.0: sửa lỗi + phím cứng và phím âm lượng

Các lỗi tìm thấy ở v2.11.0 và cách xử lý:

- **Hiện/ẩn bàn phím không còn xóa vị trí đang chọn**: `TYPE_WINDOW_STATE_CHANGED` của cửa sổ bàn phím (IME) hoặc lớp phủ trợ năng chỉ làm mới bộ đệm, không `reset()`, không đóng trình đơn, không ngắt lời đang đọc (`ReaderSession.handleWindowState`). Cửa sổ ứng dụng, hộp thoại, thanh thông báo vẫn đặt lại như trước.
- **Đọc vùng cập nhật trực tiếp (`liveRegion`), khung mới (`paneTitle`) và `announceForAccessibility`**: thêm `typeAnnouncement` và xử lý `TYPE_WINDOW_CONTENT_CHANGED` qua kênh riêng (`contentEvents`, tối đa 1 sự kiện/80 ms, chỉ các kiểu đổi chữ/mô tả/cây con/khung). Assertive ngắt lời, còn lại xếp hàng; `LiveRegionGate` chống đọc lặp. Các màn hình của chính ứng dụng dùng `liveRegion` nay được đọc.
- **Toast** đọc theo công tắc riêng (Đọc thông báo → Đọc thông báo nổi, mặc định bật), không phụ thuộc "đọc thông báo", không gộp "N thông báo mới", kể cả Toast của chính ứng dụng; không đọc khi màn hình tắt (từ bản 2.24.0).
- **Sự kiện bổ sung**: `typeViewTextSelectionChanged` (đọc ký tự vừa đi qua / đoạn được chọn / dòng khi nhảy xa; `SelectionSpeech`; bỏ qua tiếng vọng của chính lệnh đặt con trỏ), `typeViewSelected` (chỉ tab), `typeViewLongClicked` (bỏ tiếng vọng của lệnh nhấn giữ của trình đọc), `typeWindowsChanged` (chỉ đánh dấu bộ đệm cũ).
- **Giọng đọc không còn câm vĩnh viễn**: engine đã chọn hỏng/bị gỡ → sau 5 lần thử lại tự rơi về engine mặc định và báo một lần (không đổi lựa chọn trong cài đặt); engine mặc định hỏng thì thử lại mỗi 60 giây. Lỗi dịch vụ TTS (`ERROR_SERVICE`, `ERROR_NOT_INSTALLED_YET`) hoặc 3 lần `speak()` trả `ERROR` liên tiếp → dựng lại engine (tối đa 1 lần/5 giây) và đọc lại câu đang dở.
- **`runSafely`** nay bắt mọi `Exception`, `StackOverflowError`, `OutOfMemoryError`; scope có `CoroutineExceptionHandler` nên lỗi lạ chỉ được ghi nhật ký, không làm sập tiến trình hay chết vòng xử lý. Hàng đợi sự kiện chính 32 → 128 để rê ngón nhanh không làm rơi sự kiện nhấc tay.
- Nhỏ: giới hạn độ dài `message` của script nay đúng 120 (trước đây bị chặn ở 100); KDoc `speakPasswords`/`announceActionHint` về đúng chỗ; `FocusNavigator.cachedNodes/cachedAtMs` là `@Volatile`.

**Phím cứng** (Cài đặt → Đọc → Phím; mặc định BẬT): giữ Alt hoặc Windows/Search rồi nhấn phím (bảng đầy đủ trong Trợ giúp và `KeyShortcuts`). Chỉ tổ hợp có Alt/Meta và không có Ctrl mới bị chặn, nên gõ văn bản và Ctrl+phím vẫn hoạt động; Ctrl bấm riêng = dừng đọc. Nhả phím của tổ hợp đã chặn cũng được chặn nốt. Cần `canRequestFilterKeyEvents` + `flagRequestFilterKeyEvents` (đã thêm vào cấu hình dịch vụ; không cần quyền runtime). Người dùng đã bật dịch vụ từ bản cũ có thể phải tắt rồi bật lại dịch vụ để hệ thống áp cấu hình mới.

**Phím âm lượng** (cùng mục, mặc định TẮT): giảm = phần tử kế, tăng = phần tử trước, nhấn cả hai = kích hoạt, giữ nửa giây = cuộn tới/lui (`VolumeKeyNav`, có khôi phục khi mất sự kiện nhả phím). Chỉ chiếm phím khi màn hình sáng và không trong cuộc gọi/chuông reo; tắt màn hình hoặc đang gọi thì chỉnh âm lượng như thường. Không có cử chỉ vân tay (theo yêu cầu).

Chưa làm (có chủ đích, cần máy thật): duyệt xuyên nhiều cửa sổ (`service.windows`) vì phải sửa bộ nhớ vết tiêu điểm theo cửa sổ; `speakPasswords` vẫn gộp hai việc (đọc ký tự gõ và không che OCR); audio ducking.
Chưa build/chạy test trong môi trường soạn thảo: chạy `./gradlew :app:testDebugUnitTest :app:lintDebug` rồi thử trên máy thật (bàn phím hiện/ẩn, Toast, Snackbar, bàn phím Bluetooth, phím âm lượng).

## Bản 2.11.0: bám vết tiêu điểm, nhấn liên kết web, cử chỉ 2-3 ngón, mức chi tiết, nhật ký lỗi

- **Không nhảy về đầu khi giao diện vẽ lại**: `FocusNavigator` giữ bộ đệm vết (`FocusTraceBuffer`: mã duy nhất, viewId, nhãn, hộp tọa độ, chỉ số danh sách) của vài phần tử gần nhất. Nút đang chọn bị tái chế thì tìm lại theo vết (`TraceLocator`), không khớp thì dùng khe theo vị trí (`FocusTracker`). Chỉ `reset()` (màn hình/cửa sổ mới, sau khi cuộn) mới xóa vết.
- **Nhấn liên kết/vùng tương tác trong WebView**: `ClickResolver` + `ClickTargetPolicy` chọn nút nhận `ACTION_CLICK`: chính nó hoặc tổ tiên gần nhất có hành động nhấn (kể cả khi cờ `isClickable` là false), không leo vào gốc WebView/vùng cuộn; không có thì thử con bấm được (ưu tiên thẻ liên kết); cuối cùng, chỉ trong nội dung web, giả lập một cú chạm vào giữa phần tử. `ActionDispatcher` đọc câu báo theo kết quả (`ActivateOutcome`). Vai trò "liên kết" được đọc khi nhận diện được.
- **Duyệt nhanh trong web** dùng hành động chuẩn của nền tảng (`ACTION_NEXT/PREVIOUS_HTML_ELEMENT`, loại LINK/HEADING) nên không cần cuộn; vòng cuộn dài dừng ngay khi có cử chỉ mới.
- **Cử chỉ hai và ba ngón**: `GestureAnalyzer` phân nhóm vuốt theo số ngón + hướng; `SwipeProfile` là bộ gán sẵn cho bốn hướng (cuộn/chuyển trang, đổi điều khiển đọc/chuyển trang, đọc theo đơn vị, duyệt nhanh tiêu đề/liên kết, cả trang). Chọn nhanh ở đầu nhóm hai/ba ngón trong màn hình Cử chỉ; từng cử chỉ vẫn gán riêng được cho bất kỳ chức năng nào. Mặc định không đổi. Chức năng mới: tiêu đề/liên kết kế-trước, cuộn tới đầu/cuối trang, nhảy phần tử đầu/cuối (cũng có trong trình đơn chung, mục Khác).
- **Gợi ý và mức chi tiết** (Cài đặt → Đọc): công tắc riêng "Đọc gợi ý thao tác" (câu gợi ý xếp hàng sau phần tử, không ngắt; tên cử chỉ lấy theo cấu hình hiện tại) và mức Gọn/Chuẩn/Chi tiết ("Mục 3 trên 12" khi ứng dụng cung cấp thông tin danh sách). Nội dung chính của phần tử luôn đọc đủ.
- **Nhật ký lỗi** (Cài đặt → Nhật ký lỗi): chỉ lưu trong thư mục `crash_logs` của bộ nhớ riêng bảo vệ theo thiết bị (từ bản 2.25.0, để ghi được cả lỗi xảy ra lúc máy chưa mở khóa; bản cũ để ở `filesDir/crash_logs` và tự chuyển sang; không backup, không cần quyền). Tối đa 3 báo cáo sập (mỗi báo cáo ≤ 16.000 ký tự) + một tệp sự kiện lỗi nhẹ cuộn vòng ≤ 24.000 ký tự, tổng ≤ ~80 KB; lỗi lặp bị gộp (1 lần/phút/chữ ký, ≤ 20 lần/giờ). Thông điệp lỗi được che thư điện tử, địa chỉ web, chuỗi số dài. Xem, chia sẻ (hộp chia sẻ hệ thống, dạng văn bản) và xóa (có hỏi lại) ngay trong ứng dụng; có công tắc tắt. Không gửi đi đâu tự động.
- **Đối chiếu với trình đọc khác (học hỏi, không sao chép)**: dịch vụ nay nghe thêm `typeWindowContentChanged`, `typeViewScrolled` (chỉ đánh dấu bộ đệm điểm dừng đã cũ, không qua hàng đợi) và `typeViewAccessibilityFocused` (đồng bộ con trỏ khi ứng dụng/trình duyệt tự đặt tiêu điểm, không đọc lại); `notificationTimeout` = 0 để giảm trễ khi rê ngón tay. Thứ tự duyệt tôn trọng `accessibilityTraversalAfter/Before` (`TraversalOrder`). "Cuộn tới đầu/cuối" nhảy thẳng bằng `ACTION_SCROLL_TO_POSITION` khi danh sách biết số hàng.
- Lượt rà soát lần hai: gợi ý thao tác không còn duyệt con (tránh ~60 lần gọi hệ thống mỗi lần chọn); duyệt nhanh web xuất phát từ gốc WebView không báo sai "không còn" khi chỉ là chưa có điểm bắt đầu. Chưa có (khác biệt tính năng, không phải lỗi): nhập phím bằng nhấc tay trên bàn phím, phím tắt âm lượng/phím cứng, vân tay, quy tắc theo từng ứng dụng, chỉnh độ trễ chạm.
- **Nhập phím bằng nhấc tay** (Cài đặt → Đọc, mặc định tắt): rê tới phím rồi nhấc tay là gõ; `LiftToTypePolicy` chỉ cho nhấn một lần mỗi lần chạm, hủy khi lướt khỏi bàn phím, khi bắt đầu cử chỉ hoặc khi chạm quá 5 giây. **Độ trễ chạm** (0 đến 600 ms, mặc định 0): ngón tay phải dừng đủ lâu mới đọc; phím luôn đọc ngay khi bật nhập bằng nhấc tay. Độ trễ chạm đúp do hệ thống quyết định, ứng dụng không chỉnh được.
- **Cử chỉ theo ứng dụng** (Điều khiển → Cử chỉ theo ứng dụng): chọn ứng dụng có biểu tượng khởi chạy rồi sửa bằng chính màn hình cử chỉ chung; chỉ phần khác bản đồ chung được lưu (tối đa 50 ứng dụng). Ứng dụng đang mở lấy từ cửa sổ ứng dụng thật, nên bàn phím hay thanh thông báo không làm mất cử chỉ riêng. Trình đơn vẫn dùng bản đồ chung.
- Không làm, có chủ đích: cử chỉ vân tay (phím cứng và phím âm lượng đã làm từ 2.12.0, xem mục đó) (ít máy hỗ trợ, thêm quyền), vùng chạm đi xuyên (cấu hình sai có thể khóa vùng chạm). Mỗi mục cần thử trên máy thật trước khi bật.
- Nhận diện nội dung web theo khả năng (có hành động duyệt phần tử HTML) thay vì chỉ theo tên lớp WebView, để giả lập chạm cũng áp dụng cho trình duyệt không dùng WebView. - **Tìm cài đặt** (ô tìm ở đầu màn hình chính): không phân biệt hoa thường và dấu ("thong bao" ra "Đọc thông báo"); tên cài đặt xếp trước mô tả. Chỉ mục nằm ở `SettingsIndex.kt` (tạo từ các màn hình); thêm cài đặt mới thì nhớ thêm chuỗi vào đó.
- **Màn Đọc chia nhóm** (Nội dung được đọc / Gợi ý và mức chi tiết / Chạm và gõ phím). Công tắc đọc thông báo chuyển hẳn sang màn **Đọc thông báo** để mỗi cài đặt chỉ có một nơi.
- **Đọc thông báo** (mục mới): không đọc khi ngón tay đang chạm màn hình, đang gọi, bật không làm phiền, đang phát nhạc (đều mặc định tắt) cùng danh sách "không bao giờ đọc" và "luôn đọc" (không phân biệt hoa thường/dấu; danh sách chặn ưu tiên hơn; "luôn đọc" bỏ qua cả công tắc chính). Không cần thêm quyền. Từ bản 2.24.0: màn hình tắt thì không đọc thông báo nào (luật cứng, đứng trước mọi luật khác, kể cả "luôn đọc").
- **Sao lưu và khôi phục** (Nâng cao): lưu/khôi phục cài đặt, cử chỉ, cử chỉ theo ứng dụng và nhãn tùy chỉnh bằng bộ chọn tệp của hệ thống (không cần quyền lưu trữ). Chỉ nhận khóa và kiểu hợp lệ theo `BackupSchema` (khóa sai kiểu sẽ làm sập dịch vụ ở lần đọc sau nên bị bỏ qua); không gồm tiện ích mở rộng, nhật ký lỗi, công cụ giọng đọc.
- **Chạm thẳng theo ứng dụng** (Cử chỉ theo ứng dụng → chọn ứng dụng): kích hoạt bằng cú chạm thật vào giữa phần tử thay vì `ACTION_CLICK`, cho ứng dụng tự vẽ giao diện. Trạng thái màn Trạng thái cảnh báo khi một trình đọc màn hình khác đang bật cùng lúc.
- Chưa làm có chủ đích: vùng cho cử chỉ/chạm đi xuyên (`setTouchExplorationPassthroughRegion`, `setGestureDetectionPassthroughRegion`). Cấu hình sai có thể khiến người dùng không chạm được vùng đó, nên cần thử trên máy thật (bàn phím, thanh điều hướng, cạnh màn hình) trước khi bật.

- Chưa build/chạy test trong môi trường soạn thảo (không có Gradle/Kotlin); chạy `./gradlew :app:testDebugUnitTest` và thử trên máy thật, nhất là nhấn liên kết Google trong Chrome/WebView (khóa extras của Chromium không thuộc API công khai nên chỉ dùng để nhận diện thêm).

## Bản 2.10.0: sửa lỗi tồn đọng
Các lỗi tồn đọng sau khi rà soát:
- **`HighlightOverlay`**: `suspendCancellableCoroutine<Unit>` có kiểu tường minh; huỷ chờ khung hình dùng `Choreographer` đã giữ sẵn thay vì gọi `getInstance()` ở luồng không có Looper (có thể ném `IllegalStateException`).
- **Tự đọc chữ trong ảnh**: ảnh chỉ bị đánh dấu "đã đọc" SAU khi người dùng đã dừng đủ lâu và đã thử chụp. Trước đây đánh dấu ngay lúc chọn nên vuốt nhanh qua ảnh làm mất lần đọc. Bộ nhớ này được xóa khi đổi cửa sổ (`AiAssistant.onWindowChanged`) và an toàn đa luồng.
- **Chụp màn hình**: quá hạn 5 giây thì báo lỗi thay vì treo; ảnh đến muộn hoặc khi tác vụ đã bị hủy được `recycle()` (trước đây bị rò, mỗi ảnh vài MB).
- **Trình đơn bị đóng vì đổi cửa sổ** (bàn phím, hộp thoại nhỏ): nay báo "Đã đóng trình đơn" thay vì đóng im lặng.
- **Đọc theo đơn vị** (`moveUnit`): làm mới nút trước khi đọc; nút đã đổi thì báo "Phần tử đã thay đổi" (không còn đọc dữ liệu cũ).
- **Script áp dụng mọi ứng dụng**: lớp lưu trữ từ chối cài khi chưa xác nhận (`AllAppsConfirmationRequired`), không chỉ giao diện.
- **Chuỗi số lượng**: `sp_state_percent`, `script_err_depth`, `script_err_rules_count`, `lb_limits` chuyển sang `<plurals>` (tiếng Nga và Ả Rập đúng ngữ pháp). Test `QuantityStringsTest` buộc mọi chuỗi có số lượng mới phải là plurals.
- **Mục "Quyền"** (Cài đặt → Nâng cao): luồng xin quyền theo tính năng (`PermissionFlow`: giải thích trước, từ chối thì dừng, "không hỏi lại" thì có nút mở Cài đặt) và `rememberPermissionRequest`. **Hiện chưa có tính năng nào cần quyền** (đọc địa điểm gần bạn, tìm danh bạ, gọi điện, mô tả ảnh trong bộ nhớ: chưa làm) nên danh sách `PermissionFeatures.all` rỗng và manifest chỉ khai báo rung. `ManifestPermissionsTest` buộc quyền khai báo đúng bằng quyền mà tính năng cần.

Chưa sửa (cần quyết định): trình đơn chung có 7 mục + "Khác" = 8 mục ở cấp đầu (yêu cầu ghi "tối đa 7").

## Bản 2.7.3

Dọn cảnh báo lint: icon ứng dụng (loa phát sóng âm, adaptive + monochrome), `dataExtractionRules` (không sao lưu), `AppRoot` dùng `LocalWindowInfo` thay `screenWidthDp`, `app/lint.xml` bỏ qua gợi ý chính tả/plurals của chuỗi sinh tự động.

## Bản 2.7.2

Sửa 408 lỗi lint `MissingTranslation`: `values-en-rGB` cố ý chỉ có 13 chuỗi nên lint đòi đủ bản dịch. Thêm `tools:ignore="MissingTranslation"` vào `values/strings.xml` (do `tools/i18n/gen.py` sinh); độ phủ ngôn ngữ vẫn được `TextsTest` kiểm.

## Bản 2.7.1

Sửa lỗi lint `LocalContextGetResourceValueCall` ở `PluginManagerScreen` (lấy chuỗi bằng `stringResource` thay vì `context.getString` trong Composable).

## Bản 2.7.0: nút bị ứng dụng giấu khỏi trợ năng

Một số ứng dụng (ví dụ ô tích "Tôi đồng ý với điều khoản") đánh dấu nút là "không quan trọng với trợ năng" nên trình đọc
không thấy và không bấm được.

- **Tiêu điểm chi tiết** (Cài đặt → Đọc, hoặc trình đơn chung → Khác, hoặc gán cử chỉ): bật cờ
  `FLAG_INCLUDE_NOT_IMPORTANT_VIEWS` lúc đang chạy và duyệt cả nút bấm được không nhãn nằm trong khung cha. Mặc định tắt.
- **Thông tin kỹ thuật** (trình đơn phần tử, hoặc gán cử chỉ): đọc lớp view, bấm/tích được, quan trọng với trợ năng, mã. Dùng để
  chẩn đoán màn hình khó.
- **Nhấn điều khiển bên cạnh**: nhấn đúp vào dòng chữ không bấm được sẽ nhấn ô tích/nút cùng hàng, gần nhất (tối đa 300 px).
- Chưa kiểm chứng trên máy thật (đặc biệt màn hình EPAY). Nếu ô tích vẫn không tới được thì dùng "Thông tin kỹ thuật" và báo lại.

## Bản 2.6.4

- Hàng đọc đầy: lời ưu tiên thấp (thông báo, "đã chạm") bị bỏ thay vì xóa câu đang đọc.
- Trình đơn đang mở: bỏ qua sự kiện focus của ứng dụng. Đổi cửa sổ: hủy tác vụ AI đang chạy.
- Giọng đọc và chữ giao diện cùng một nguồn ngôn ngữ. "Bỏ qua quảng cáo": từ chung chỉ khớp khi nhãn đúng bằng từ đó.
- Khóa luồng cho `EarconPlayer`; Regex của `EmojiText.tidy` thành hằng; sửa KDoc cài đặt.

## Bản 2.6.3

Gộp bản "v17" bạn gửi (đọc emoji có khoảng lặng, bảng emoji đầy đủ, `tools/emoji`) với các sửa rà soát mô tả hình ảnh/OCR bên dưới. 260 test offline đạt.

## Rà soát mô tả hình ảnh và OCR (2.6.1)

- Hủy tác vụ nhận dạng không còn giải phóng bitmap khi ML Kit còn đang đọc (tránh crash khi vuốt nhanh).
- Ô mật khẩu đang hiển thị bị tô đen trên ảnh chụp trước khi OCR/mô tả (mặc định); bật "đọc mật khẩu" trong Cài đặt thì không che.
- Vùng ảnh lấy theo vị trí SAU khi chụp; đổi phần tử thì hủy mô tả của phần tử cũ.
- Nhãn và OCR chạy song song, một nguồn lỗi không làm mất nguồn kia. Nhãn chưa dịch không đọc thô bằng giọng sai ngôn ngữ.
- Ẩn khung viền có timeout 300 ms (không treo khi màn hình tắt). Ảnh chụp là bitmap mutable để che vùng mật khẩu.
- OCR: hai cột xa nhau không dính thành một câu, giữ ký hiệu đơn như %, ?, không cắt giữa cặp surrogate.
- Thông báo: bộ nhớ ứng dụng theo LRU, giới hạn 240 ký tự. Đọc lại câu cuối không transform hai lần. TTS ưu tiên "ngôn ngữ theo ứng dụng".
- Chưa kiểm chứng trên máy thật: ML Kit, tô đen mật khẩu, timeout ẩn khung, locale theo ứng dụng của TTS.
- Cố ý giữ: thông báo chứa mã OTP vẫn được đọc to (người khiếm thị cần nghe); chưa có công tắc tắt.

## Chuyển trang, vuốt trái/phải và tự cuộn (2.6.0)
- **Trang kế / Trang trước** (hai hoặc ba ngón vuốt trái/phải): tìm vùng cuộn **ngang** (ViewPager, tab vuốt ngang, danh sách ngang) và chuyển trang. Chưa thử trên máy thật với từng loại giao diện.
- Vuốt phải/trái chuyển phần tử: nếu phần tử bạn chạm vào không phải điểm dừng (ví dụ con của khối đã gộp nhãn), app bắt đầu từ điểm dừng chứa nó thay vì nhảy về đầu/cuối danh sách.
- Tới phần tử cuối/đầu của màn hình: app tự cuộn một lần rồi chọn phần tử mới; hết thật mới báo "phần tử cuối".
- Trình đơn tự đóng sau 30 giây không dùng; trong trình đơn, nếu bạn đã bỏ gán hết "phần tử kế/trước, nhấn, quay lại" thì cử chỉ mặc định của chúng được dùng tạm để không bị kẹt.

## Đọc biểu tượng cảm xúc (emoji)
Cài đặt → Đọc → **Đọc biểu tượng cảm xúc** (mặc định bật). Emoji được đổi thành tên trước khi giọng đọc ("😂" → "cười ra nước mắt", "👍" → "ngón tay cái giơ lên").

**Từ điển.** `core/EmojiNames.kt` và `core/EmojiData.kt` được **sinh tự động** bằng `python3 tools/emoji/build_emoji.py` từ `tools/emoji/` (dữ liệu Unicode `emoji-data.txt` bản Emoji 15.1, bảng tên đã duyệt `names_curated.tsv`, bảng tên bổ sung `names_vi_extra.txt` và các quy tắc trong chính tập lệnh: đồng hồ, cung hoàng đạo, nghề nghiệp, gia đình, cờ). Trình sinh **từ chối chạy** nếu có emoji thiếu tên Việt hoặc Anh, hoặc hai ký tự trùng tên (trùng tên làm "★★★★☆" bị đọc "ngôi sao, 5 lần"). Hiện phủ toàn bộ 1.410 ký tự có thuộc tính Emoji của Emoji 15.1 (trước đây 281, tức chỉ 23%) cộng 7 emoji của Emoji 16.0 bằng tiếng Việt và tiếng Anh. Ngôn ngữ khác đọc tên tiếng Anh. Emoji hoàn toàn mới chưa có trong bảng vẫn được đọc là "biểu tượng cảm xúc" thay vì im lặng.

**Nhận diện.** Dùng thuộc tính Unicode (Emoji, Emoji_Presentation) thay cho các dải mã rộng: các ký hiệu giao diện như ● ○ ✓ ➤ ☐ trước đây bị đọc nhầm là "biểu tượng cảm xúc"; nay có tên riêng (ví dụ ● "chấm tròn đen", ✓ "dấu tích") còn ký hiệu không có tên (→ ⇒ ™ © ▶ không kèm U+FE0F) được giữ nguyên. Hệ quả cần biết: dòng như "● Online" giờ đọc "chấm tròn đen, Online", và thanh đánh giá "★★★★☆" đọc "ngôi sao đặc, 4 lần, ngôi sao rỗng".

**Emoji ghép.** Hiểu kiểu hiển thị (U+FE0F), màu da, ZWJ, giới tính (♂ ♀ → hậu tố "nam"/"nữ"), khung phím ("phím số 1", "phím thăng"), cờ quốc gia (tên nước do hệ điều hành cung cấp theo ngôn ngữ: "cờ Việt Nam", "cờ Pháp"), cờ vùng (Anh, Scotland, Wales) và các tổ hợp quen thuộc (gia đình, nghề nghiệp, cờ cầu vồng, trái tim rực lửa...). Tổ hợp chưa có tên thì đọc từng thành phần cách nhau bằng dấu phẩy, không còn đọc dính "người đàn ông người phụ nữ".

**Chính sách ngắt nghỉ** (`EmojiRunPolicy`, `SpeechPlan`): nhiều giọng đọc gần như không nghỉ ở dấu phẩy nên tên các emoji dính vào nhau. Vì vậy:
- Một chuỗi emoji liền nhau (cho phép khoảng trắng đơn giữa các emoji) từ **hai mục trở lên** được đọc **từng mục như một đoạn riêng**, cách nhau khoảng lặng 160 ms (380 ms sau mỗi nhóm 4 mục) và 260 ms với chữ xung quanh. Khoảng lặng là "đoạn im lặng" của TTS nên chắc chắn có, và co lại theo tốc độ đọc (60–600 ms).
- Emoji giống hệt nhau **từ 4 lần trở lên** gộp "tên, N lần"; 2–3 lần đọc từng cái ("😂😂😂" → "cười ra nước mắt" ×3, có nhịp). Trước đây ngưỡng là 3.
- Một chuỗi đọc tối đa 12 mục, phần còn lại gộp "và N biểu tượng khác".
- Một emoji đơn lẻ vẫn nằm trong câu ("Hay quá, cười ra nước mắt") để không cắt vụn lời.

**Hàng đợi giọng nói.** Chính sách hàng đợi (`SpeechQueuePolicy`) đếm theo **câu**, không theo từng đoạn phát (`SpeechPendingTracker`): một câu emoji tách thành nhiều đoạn không còn làm hàng đợi trông "đầy" nên không bị lời kế tiếp cắt ngang. "Đọc lại" (`repeatLast`) giữ câu **gốc** nên lập lại đúng các khoảng lặng.

**Giới hạn, nói thẳng.**
- Tên emoji tiếng Việt do người soạn viết, **chưa được người bản ngữ rà soát**; một số tên có thể chưa tự nhiên.
- Ngôn ngữ giao diện khác tiếng Việt vẫn đọc tên emoji bằng tiếng Anh (chưa có bảng tên Pháp, Tây Ban Nha, Nga, Ả Rập, Trung).
- Tên nước trong cờ lấy từ dữ liệu ngôn ngữ của hệ điều hành; máy thiếu dữ liệu đó sẽ đọc "lá cờ".
- Khoảng lặng dùng `playSilentUtterance`; hành vi thật phụ thuộc engine TTS và **chưa được thử trên máy**.
- Chưa có kiểm thử trên thiết bị thật; chưa chạy được `assembleDebug`, `testDebugUnitTest`, `lintDebug`.

## Điều kiện hệ thống ảnh hưởng cử chỉ
- Cử chỉ nhiều ngón và cử chỉ hai bước chỉ hoạt động khi bật chế độ khám phá bằng cảm ứng và hệ thống gửi cử chỉ tới
  dịch vụ; một số hãng máy/phiên bản Android hoặc trình đọc màn hình khác đang bật có thể chiếm cử chỉ. Muốn biết cử chỉ nào
  thật sự tới được ứng dụng trên máy của bạn, bật **Nhật ký chẩn đoán** (Công cụ → Nhật ký và hỗ trợ) rồi làm thử cử chỉ đó:
  cử chỉ tới nơi thì nhật ký có dòng `GESTURE`, không tới thì không có dòng nào. (Mục **Kiểm tra cử chỉ** đã bỏ ở bản 2.23.0.)
- Cử chỉ vuốt từ cạnh màn hình (Back/Home của hệ thống) không bắt được.

## Cài đặt
1. Tải APK từ tab **Actions** (mục Artifacts) hoặc build bằng Android Studio.
   APK debug từ Actions được ký bằng khóa tạm của mỗi lần chạy, nên khi cài bản mới hãy **gỡ bản cũ trước**
   (nếu không sẽ báo "xung đột gói").
2. **Android 13 trở lên, APK cài ngoài Google Play:** hệ thống chặn bật dịch vụ hỗ trợ tiếp cận (công tắc bị mờ).
   Vào *Cài đặt → Ứng dụng → Đọc Màn Hình Việt Pro → ⋮ → Cho phép cài đặt bị hạn chế*, rồi làm bước 3.
3. Mở ứng dụng, chạm công tắc để vào Cài đặt Hỗ trợ tiếp cận và bật dịch vụ.
4. **Tắt trình đọc màn hình khác** trước khi dùng vì cả hai dùng chế độ khám phá bằng cảm ứng.
5. Cài giọng tiếng Việt (Google Text-to-Speech) nếu thiết bị chưa có.

## Script plugin
Script là JSON khai báo, không chứa mã thực thi. Xem mẫu trong `samples/close_popup_vn.json`.

```json
{
  "id": "ten_script",
  "name": "Tên hiển thị",
  "description": "Mô tả ngắn",
  "packages": [],
  "rules": [
    { "text": "Đóng", "match": "equals", "action": "click" }
  ]
}
```
- `match`: `contains` (mặc định) hoặc `equals`.
- Tiêu chí: `text`, `contentDescription`, `viewId`, `className` (mọi tiêu chí đã khai báo phải khớp).
- `action` mở rộng: `click`, `long_click`, `focus`, `scroll_forward`, `scroll_backward`.
- `message` (tùy chọn, tối đa 120 ký tự): câu đọc sau khi rule thực hiện thành công.
- `packages`: để trống nghĩa là chạy với mọi ứng dụng.
- `id`: chỉ gồm `a-z`, `0-9`, `_` (tối đa 40 ký tự) và **không được trùng** id tiện ích dựng sẵn (`builtin_skip_ad`).
- Giới hạn an toàn: tệp ≤ 64 KB, JSON lồng ≤ 8 cấp, tối đa 20 rule. So khớp chữ không phân biệt hoa/thường và
  không phân biệt dạng Unicode dựng sẵn/tổ hợp của tiếng Việt.

## Đọc theo đơn vị, sao chép, dán, cắt (v2.4.0)
- Đơn vị đọc: đoạn → câu → từ → ký tự. Mặc định: ba ngón vuốt xuống = đơn vị kế, ba ngón vuốt lên = đơn vị trước, hai ngón chạm ba lần = đổi đơn vị. (Từ 2.20.0 ba ngón vuốt xuống/lên đổi điều khiển đọc và hai ngón chạm ba lần đọc từ phần tử đang chọn; "đơn vị kế/trước" và "đổi đơn vị đọc" còn trong trình đơn phần tử, và muốn ba ngón vuốt như cũ thì chọn kiểu "Đọc theo đơn vị và chuyển trang" trong mục Cử chỉ.) (Từ 2.19.0 "sao chép đơn vị đang đọc" không còn gán sẵn cho "lên rồi xuống": dùng trình đơn phần tử hoặc gán trong mục Cử chỉ; "lên rồi xuống" và "xuống rồi lên" nay đổi điều khiển đọc.)
- Sao chép: nếu đang có vùng chọn trong ô nhập (kể cả chọn ngược) thì chỉ sao chép đoạn đã chọn.
- Thêm hành động: đưa con trỏ về đầu/cuối, chọn đến đầu/cuối. Ô mật khẩu chỉ cho phép dán; cắt, chọn, di chuyển con trỏ, sao chép đều bị chặn. Cắt và dán do hệ thống thực hiện, ứng dụng không đọc hay ghi clipboard.
- Dán, cắt, chọn tất cả và các mục trên có trong trình đơn con "Chỉnh sửa văn bản" của ô nhập; có thể gán cho cử chỉ bất kỳ trong mục Cử chỉ.
- Cuộn trang thử mọi vùng cuộn (vùng chứa phần tử đang chọn trước, rồi vùng lớn nhất) thay vì chỉ một vùng.

## Đa ngôn ngữ (v2.3.0)
- Giao diện và câu đọc bằng giọng nói có 7 ngôn ngữ: Tiếng Việt, English, Français, Español, Русский, العربية (RTL), 中文 — 6 ngôn ngữ chính thức của Liên hợp quốc và tiếng Việt. Có thêm biến thể: 中文 giản thể (zh-Hans) và phồn thể (zh-Hant, Đài Loan/Hồng Kông), English Mỹ (mặc định) và Anh (en-GB, chỉ khác chính tả). Bản phồn thể được chuyển từ giản thể bằng bảng ký tự tự lập, cần người bản ngữ rà soát. Mặc định (khi máy dùng ngôn ngữ khác) là English.
- Đổi ngôn ngữ: Cài đặt → Giọng nói (TTS) → "Chọn ngôn ngữ ứng dụng" (mở thẳng màn hình ngôn ngữ riêng của ứng dụng trong hệ thống). Giọng đọc đổi theo; cần cài giọng tương ứng trong công cụ TTS.
- Chuỗi nằm ở `app/src/main/res/values*/strings.xml`. Các tệp này, `core/S.kt`, `core/FallbackTexts.kt` và `i18n/ResourceTexts.kt` được SINH TỰ ĐỘNG từ bảng dịch trong `tools/i18n/` (xem `tools/README.md`, chạy `python3 tools/i18n/gen.py .`); khi thêm chuỗi phải cập nhật đủ 7 ngôn ngữ (unit test `TextsTest` kiểm tra đủ khóa và đúng tham số).
- Bản dịch do máy dịch, CHƯA được người bản ngữ rà soát. Từ điển mô tả hình ảnh và đoán nhãn từ tên view hiện chỉ có tiếng Việt (giao diện `LanguageDictionary`, thêm ngôn ngữ = thêm một lớp); ngôn ngữ khác đọc từ tiếng Anh gốc. Chuỗi có số đếm (số nhiều) dùng `plurals` đủ dạng theo từng ngôn ngữ (ru: one/few/many/other, ar: 6 dạng).
- Bố cục dùng kích thước tối thiểu (`heightIn(min)`) và chữ tự xuống dòng nên không cắt chữ; bản debug bật pseudo-locale (en-XA, ar-XB) để soát lỗi vỡ chữ/đảo chiều.

## Giới hạn của phần AI (nói thẳng)
- OCR chạy hoàn toàn trên máy bằng mô hình ML Kit **đóng gói sẵn**, chọn theo ngôn ngữ ứng dụng: **Latin** (Việt, Anh,
  Pháp, Tây Ban Nha...) và **Trung** (chữ Hán). **Nga (Cyrillic) và Ả Rập: ML Kit chưa có mô hình gói sẵn nên ứng dụng
  báo "chưa hỗ trợ" thay vì đọc ra kết quả sai.** Chữ Việt đọc được ở mức cơ bản, dấu thanh có thể sai với chữ nhỏ/mờ.
  Kết quả có độ tin cậy thấp được thêm "có thể sai". Mô hình Trung làm APK nặng thêm khoảng 4 MB mỗi kiến trúc CPU (theo
  tài liệu ML Kit; chưa đo trên bản build thật).
- **Ảnh xác minh/CAPTCHA:** OCR thông thường **không đáng tin** với chữ méo, nhiễu, gạch chéo, và ứng dụng **không có chức
  năng giải hay vượt xác minh**. Nếu gặp ảnh xác minh, hãy dùng lựa chọn âm thanh của dịch vụ đó, kênh hỗ trợ dành cho
  người khiếm thị của họ, hoặc nhờ người nhìn giúp.
- **Tự đọc chữ trong ảnh không nhãn** (Cài đặt → Đọc, **mặc định tắt**): chỉ khi bạn chọn một ảnh không có chữ/mô tả/nhãn,
  mỗi lần một tác vụ, hủy khi chọn phần tử khác, không đọc lại cùng phần tử trong cùng cửa sổ, bỏ qua ô mật khẩu và
  cửa sổ bảo mật, không ghi gì ra đĩa. Cách này chụp màn hình mỗi lần chọn nên tốn pin hơn.
- "Mô tả hình ảnh" gán nhãn (khoảng 400 loại, dịch sang tiếng Việt bằng từ điển), không viết thành câu văn như AI sinh văn bản.
  Mô hình sinh mô tả của Google (GenAI) hiện chỉ có tiếng Anh, cần Gemini Nano và tải qua mạng nên chưa dùng.
- Chụp màn hình bị Android chặn ở màn hình bảo mật (mật khẩu, ngân hàng); khi đó ứng dụng sẽ báo thay vì đọc.
- Khi chụp màn hình, khung viền xanh được ẩn tạm (chờ 2 khung hình) rồi hiện lại, kể cả khi lỗi hoặc bị hủy.
- Phần chụp màn hình/ML Kit mới chỉ được biên dịch trên GitHub Actions, chưa thử trên máy thật.

## Quyết định thiết kế
- **Không đăng ký `typeWindowContentChanged` / `typeViewScrolled`:** hai loại sự kiện này phát dồn dập (mỗi lần cuộn, mỗi
  khung hoạt ảnh) gây bão sự kiện, tốn pin và làm trễ giọng đọc. Ứng dụng chỉ lấy lại cây giao diện khi cần (chọn, cuộn
  bằng cử chỉ, đổi cửa sổ) và làm mới nút (`refresh()`) trước khi dùng; nút đã cũ thì đọc "Phần tử đã thay đổi".
- **Giới hạn duyệt cây:** tối đa 1500 phần tử nhìn thấy (trang dài vẫn đọc được) và trần cứng 6000 nút để tránh treo.
- **Script không khai báo `packages`** chạy ở mọi ứng dụng: khi nạp, ứng dụng hỏi xác nhận trước khi cài.
- **Không dịch vụ nền (foreground service):** dịch vụ trợ năng đã được hệ thống giữ chạy.

## Quyền (manifest) và Google Play
| Quyền / khai báo | Lý do |
|---|---|
| `BIND_ACCESSIBILITY_SERVICE` (dịch vụ) | Đọc và điều khiển giao diện để làm trình đọc màn hình |
| `canTakeScreenshot` (cấu hình dịch vụ) | OCR/mô tả ảnh; ảnh chỉ nằm trong RAM, giải phóng ngay |
| `VIBRATE` | Rung phản hồi khi chuyển phần tử |
| `RECEIVE_BOOT_COMPLETED` | Nhận tin "máy khởi động xong, còn khóa" để nối lại giọng đọc ngay (bộ nhận `BootSignalReceiver`, chỉ ghi tin vào RAM). Quyền loại thường: không hỏi người dùng, không cho đọc dữ liệu nào |
| `<queries>`: TTS_SERVICE, MAIN/LAUNCHER | Liệt kê công cụ TTS; tra tên ứng dụng khi đọc thông báo (không dùng `QUERY_ALL_PACKAGES`) |
| Không có INTERNET / ACCESS_NETWORK_STATE | Mọi xử lý trên máy, không gửi dữ liệu đi đâu |

Khi đưa lên Google Play: chỉ khai báo các quyền trên, khai báo mục đích dịch vụ hỗ trợ tiếp cận (Accessibility API
declaration) và chính sách quyền riêng tư nêu rõ **không thu thập, không gửi dữ liệu ra ngoài thiết bị**.

**Mục "Quyền" trong ứng dụng.** Hiển thị theo từng tính năng cần quyền (tên, trạng thái "Đã cấp"/"Chưa cấp", nút mở đúng màn hình quyền của ứng dụng) và cập nhật khi quay lại từ Cài đặt hệ thống. Mở mục này không bao giờ tự xin quyền. Khi chưa có tính năng nào cần quyền, mục chỉ hiện lời giải thích. Luồng xin quyền: có quyền thì làm ngay; chưa có thì đọc lời giải thích rồi mới hiện hộp thoại hệ thống; bị từ chối thì đọc thông báo và kết thúc (không hỏi lại trong cùng một lần bấm); "không hỏi lại" thì kèm nút "Mở Cài đặt". Với gọi điện sẽ dùng `ACTION_DIAL` (không xin `CALL_PHONE`); với ảnh trong bộ nhớ sẽ dùng `PickVisualMedia` (không xin quyền đọc ảnh).

## Rà soát bố cục (5.5) — đã đọc mã, CHƯA xem trên máy
Kiểm theo mã nguồn (không có thiết bị/emulator ở môi trường làm việc):
| Màn hình | Cuộn dọc | Ghi chú |
|---|---|---|
| Danh sách mục + Trạng thái, Giọng nói, Rung/âm báo, Đọc, Nhãn, Trình đơn, Trợ giúp | Có (`ScreenColumn`) | chữ tự xuống dòng, hàng công tắc cao tối thiểu 80dp |
| Cử chỉ, Tiện ích | Có (`LazyColumn`) | hộp chọn chức năng cuộn được |
| Gắn nhãn, Tìm chữ (Activity riêng) | **Đã thêm** `verticalScroll` + `imePadding` | trước đó cột cố định, bàn phím/ chữ lớn/xoay ngang có thể che nút |
| Hộp thoại xác nhận (xóa tiện ích, script mọi ứng dụng) | **Đã thêm** cuộn | chữ dài ở ngôn ngữ khác không bị cắt |
| Màn hình rộng/xoay ngang | Danh sách trái + nội dung phải, mỗi bên cuộn riêng | ngưỡng 600dp |
| RTL (ar, ar-XB) | Dùng `start/end` của Compose | cần xem thật |
Việc còn lại: chạy bản debug với en-XA/ar-XB, cỡ chữ lớn nhất, màn hình nhỏ/ngang/lớn.

## Build
- Android Studio (bản hỗ trợ AGP 9.5): mở thư mục dự án, chờ sync, chọn *Build → Build APK(s)*. Cần gói **Android SDK Platform 37.1** (Tools → SDK Manager → SDK Platforms, mở rộng mục Android 17; Android Studio thường tự đề nghị tải khi sync).
- Dòng lệnh: `./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`
  (Gradle wrapper đã ghim Gradle 9.9.2 kèm checksum SHA-256).
- GitHub Actions: workflow `.github/workflows/build.yml` tự chạy test, lint và build APK mỗi lần push.
- **Bản release đã ký:** khóa KHÔNG nằm trong repo. `app/build.gradle.kts` chỉ ký khi đủ 4 biến môi trường
  `RELEASE_KEYSTORE_PATH`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD` (thiếu thì ra APK
  chưa ký). Trên GitHub: tạo keystore (`keytool -genkeypair -v -keystore release.jks -alias key -keyalg RSA -keysize 4096 -validity 10000`),
  mã hóa `base64 -w0 release.jks`, lưu vào Secrets `RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`,
  `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`, rồi chạy tay workflow **Build release** (`release.yml`) để lấy APK/AAB đã ký.
  Giữ kỹ keystore: mất khóa là không cập nhật được ứng dụng.

## Công nghệ (cập nhật 11/2026)
| Thành phần | Phiên bản |
|---|---|
| Android Gradle Plugin | 9.5.2 (Kotlin tích hợp sẵn, không còn plugin `kotlin-android`) |
| Gradle | 9.9.2 |
| Kotlin / Compose compiler plugin | 2.4.21 |
| Compose BOM | 2026.11.01 (Compose 1.13.0, Material3 1.5.0; đòi Kotlin 2.2+ và compileSdk 37.1) |
| lifecycle-runtime-compose | 2.11.1 |
| compileSdk / targetSdk / minSdk | 37.1 / 36 / 35 (Android 15+); compileSdk 37.1 cần gói "Android SDK Platform 37.1" |
| JDK | 17 trở lên (CI dùng 21) |

Phiên bản phụ thuộc nằm tập trung tại `gradle/libs.versions.toml`.

**Đối chiếu 13/11/2026 với trang phát hành chính thức:** Kotlin 2.4.21, Compose BOM 2026.09.00 (ui 1.12.1, Material3 1.4.0), core-ktx 1.19.1, activity-compose 1.13.0, lifecycle 2.11.0, coroutines 1.11.0, ML Kit (text-recognition 16.0.1, image-labeling 17.0.9), JUnit 4.13.2 (bản cuối của nhánh 4) và các action CI (checkout v7, setup-java v6, setup-android v4, setup-gradle v6, upload-artifact v7) đều là bản ổn định mới nhất. Cố ý **chưa** nâng: Compose 1.13.0-rc01 / Material3 1.5.0-rc01 (bản thử nghiệm; chờ BOM ổn định kế tiếp), activity 1.14 và lifecycle 2.12 (alpha), targetSdk 37 (Google Play mới yêu cầu API 36 từ 31/8/2026; nâng 37 cần thử hành vi mới trên máy thật), JUnit 6 (cần plugin ngoài cho AGP, không có lợi ích rõ).

**Đối chiếu 26/11/2026:** báo cáo lint thật của CI (bản 2.25.0) tự đối chiếu với Google Maven và Gradle, chỉ báo bốn bản mới: Gradle 9.9.2, AGP 9.5.2 và lifecycle-runtime-compose 2.11.1 (đã nâng, đều là bản vá), Compose BOM 2026.11.01 (**chưa** nâng, lý do ở "Bản 2.26.0"). Các thư viện khác trong danh mục vẫn là bản mới nhất. Compose 1.13.0 / Material3 1.5.0 đã ổn định từ BOM 2026.11.01 nhưng đòi compileSdk 37.1; targetSdk vẫn giữ 36.

**Đối chiếu 27/11/2026:** bản 2.28.0 đã nâng Compose BOM lên 2026.11.01 (Compose 1.13.0, Material3 1.5.0) kèm compileSdk 37.1; mọi mục còn lại của danh mục không đổi so với đối chiếu 26/11. targetSdk vẫn giữ 36 (chưa thử hành vi mới của Android 17 trên máy thật). Phần chưa kiểm chứng được ngoài CI: biên dịch Compose 1.13, cảnh báo lint mới, và việc máy dựng cài được gói "Android SDK Platform 37.1".

## Yêu cầu
- Android 15 (API 35) trở lên, JDK 17 trở lên.
