package com.example.vnscreenreader.core

import java.text.BreakIterator
import java.util.Locale

/** Đơn vị đọc/sao chép văn bản. Thứ tự là thứ tự đổi vòng tròn. */
enum class TextGranularity(val labelKey: S) {
    PARAGRAPH(S.GRAN_PARAGRAPH),
    SENTENCE(S.GRAN_SENTENCE),
    WORD(S.GRAN_WORD),
    CHARACTER(S.GRAN_CHARACTER);

    val label: String get() = t(labelKey)

    fun next(): TextGranularity = entries[(ordinal + 1) % entries.size]
}

/**
 * Tách văn bản thành các đoạn (range) theo đơn vị. Thuần Kotlin, O(n) thời gian và không gian.
 * Câu: kết thúc ở . ! ? … 。！？ khi sau đó là khoảng trắng/hết chuỗi/xuống dòng; không cắt sau chữ viết tắt
 * ("TP.", "Dr.", "Mr.") hay khi chữ kế tiếp viết thường (ví dụ "v.v. và").
 */
object TextUnits {

    /** Dấu kết câu: Latin, tiếng Ả Rập (؟ ۔) và toàn chiều rộng của tiếng Trung. */
    private const val SENTENCE_END = ".!?…。！？؟۔"

    /** Dấu kết câu toàn chiều rộng: tiếng Trung không có khoảng trắng sau dấu nên luôn là ranh giới câu. */
    private const val FULLWIDTH_END = "。！？"
    private const val CLOSERS = "\"')]}»”’」』）】》〉"

    fun ranges(text: String, granularity: TextGranularity): List<IntRange> = when (granularity) {
        TextGranularity.CHARACTER -> characters(text)
        TextGranularity.WORD -> words(text)
        TextGranularity.PARAGRAPH -> paragraphs(text)
        TextGranularity.SENTENCE -> sentences(text)
    }

    fun split(text: String, granularity: TextGranularity): List<String> =
        ranges(text, granularity).map { text.substring(it.first, it.last + 1) }

    /** Từng "ký tự người dùng thấy": gộp dấu thanh rời, emoji màu da/ZWJ, cờ, cặp surrogate (xem [Graphemes]). */
    private fun characters(text: String): List<IntRange> = Graphemes.clusters(text)

    /** Các hệ chữ không dùng khoảng trắng giữa các từ: một "từ" tách bằng khoảng trắng sẽ là cả cụm dài. */
    private val UNSPACED_SCRIPTS = setOf(
        Character.UnicodeScript.HAN, Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA,
        Character.UnicodeScript.THAI, Character.UnicodeScript.LAO, Character.UnicodeScript.KHMER,
        Character.UnicodeScript.MYANMAR,
    )

    /**
     * Từ = cụm không có khoảng trắng; riêng cụm chứa chữ Hán/Nhật/Thái... được tách tiếp bằng [BreakIterator] (trên
     * Android chạy bằng ICU có từ điển tách từ). Dấu câu đi kèm từ liền trước nên không thành "từ" riêng.
     */
    private fun words(text: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        var i = 0
        while (i < text.length) {
            // Khoảng trắng theo Unicode (gồm dấu cách không ngắt U+00A0, U+202F, U+3000...), không chỉ khoảng trắng ASCII như
            // regex `\S`: trang web hay chèn &nbsp; giữa các từ, nếu không "Hà&nbsp;Nội" thành một từ và "&nbsp;" đứng một mình
            // thành một "từ" rỗng khi duyệt.
            while (i < text.length && text[i].isWhitespace()) i++
            if (i >= text.length) break
            val start = i
            while (i < text.length && !text[i].isWhitespace()) i++
            val run = start until i
            if (hasUnspacedScript(text, run)) out += splitUnspaced(text, run) else out += run
        }
        return out
    }

    private fun hasUnspacedScript(text: String, run: IntRange): Boolean {
        var i = run.first
        while (i <= run.last) {
            val codePoint = text.codePointAt(i)
            if (Character.UnicodeScript.of(codePoint) in UNSPACED_SCRIPTS) return true
            i += Character.charCount(codePoint)
        }
        return false
    }

    private fun splitUnspaced(text: String, run: IntRange): List<IntRange> {
        val base = run.first
        val iterator = BreakIterator.getWordInstance(Locale.ROOT)
        iterator.setText(text.substring(run.first, run.last + 1))
        val parts = ArrayList<IntRange>()
        var carry = -1 // dấu mở đầu (ví dụ dấu ngoặc kép) chờ dính vào từ kế tiếp
        var start = iterator.first()
        var end = iterator.next()
        while (end != BreakIterator.DONE) {
            val from = base + start
            val to = base + end - 1
            when {
                hasLetterOrDigit(text, from, to) -> {
                    parts += (if (carry >= 0) carry else from)..to
                    carry = -1
                }
                parts.isNotEmpty() -> parts[parts.lastIndex] = parts.last().first..to // dấu cuối dính vào từ trước
                carry < 0 -> carry = from
            }
            start = end
            end = iterator.next()
        }
        if (parts.isEmpty()) parts += run // cụm chỉ gồm dấu câu: giữ nguyên một "từ"
        return parts
    }

    private fun hasLetterOrDigit(text: String, from: Int, toInclusive: Int): Boolean {
        var i = from
        while (i <= toInclusive) {
            val codePoint = text.codePointAt(i)
            if (Character.isLetterOrDigit(codePoint)) return true
            i += Character.charCount(codePoint)
        }
        return false
    }

    private fun paragraphs(text: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = 0
        while (start <= text.length) {
            var end = text.indexOf('\n', start)
            if (end < 0) end = text.length
            addTrimmed(text, start, end, out)
            start = end + 1
        }
        return out
    }

    private fun sentences(text: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        for (para in paragraphs(text)) {
            var start = para.first
            var i = para.first
            while (i <= para.last) {
                if (text[i] in SENTENCE_END && isBoundary(text, i, para.last)) {
                    var end = i
                    // Gộp dấu chấm lặp ("...", "?!") và dấu đóng ngoặc/nháy đi liền.
                    while (end + 1 <= para.last && (text[end + 1] in SENTENCE_END || text[end + 1] in CLOSERS)) end++
                    addTrimmed(text, start, end + 1, out)
                    start = end + 1
                    i = end + 1
                } else {
                    i++
                }
            }
            addTrimmed(text, start, para.last + 1, out)
        }
        return out
    }

    private fun isBoundary(text: String, at: Int, paraLast: Int): Boolean {
        var j = at + 1
        // Bỏ qua dấu lặp/dấu đóng để tìm ký tự thật sự kế tiếp.
        while (j <= paraLast && (text[j] in SENTENCE_END || text[j] in CLOSERS)) j++
        if (j > paraLast) return true
        if (text[at] in FULLWIDTH_END) return true
        if (!text[j].isWhitespace()) return false
        var k = j
        while (k <= paraLast && text[k].isWhitespace()) k++
        if (k > paraLast) return true
        if (text[at] == '.' && (isAbbreviation(text, at) || text[k].isLowerCase())) return false
        return true
    }

    private val TITLES = setOf("Mr", "Mrs", "Ms", "Dr", "Prof", "St", "Sr", "Jr", "Mme", "Mlle")

    /** Từ ngay trước dấu chấm là chữ viết tắt: toàn chữ hoa ngắn ("TP", "TS", "PGS") hoặc danh xưng ("Dr", "Mr"). */
    private fun isAbbreviation(text: String, dot: Int): Boolean {
        var s = dot
        while (s > 0 && text[s - 1].isLetter()) s--
        val word = text.substring(s, dot)
        if (word.isEmpty()) return false
        return word in TITLES || (word.length in 2..4 && word.all { it.isUpperCase() })
    }

    private fun addTrimmed(text: String, from: Int, toExclusive: Int, out: MutableList<IntRange>) {
        var s = from
        var e = toExclusive
        while (s < e && text[s].isWhitespace()) s++
        while (e > s && text[e - 1].isWhitespace()) e--
        if (s < e) out += s until e
    }
}

/** Kết quả di chuyển con trỏ đơn vị. */
sealed interface UnitMove {
    data class At(val text: String) : UnitMove
    data object End : UnitMove
    data object Start : UnitMove

    /** Phần tử đã thay đổi/biến mất: nơi gọi đã được báo "phần tử đã thay đổi", không đọc thêm gì. */
    data object Changed : UnitMove
}

/**
 * Con trỏ đơn vị trên văn bản của phần tử đang chọn. Đổi đơn vị giữ nguyên vị trí (chọn đơn vị chứa ký tự
 * hiện tại) nên người dùng có thể đang ở câu rồi chuyển sang từ mà không mất chỗ. Không an toàn đa luồng.
 */
class TextCursor(var granularity: TextGranularity = TextGranularity.SENTENCE) {
    private var text = ""
    private var ranges: List<IntRange> = emptyList()
    private var index = -1

    /** Gắn văn bản mới; chỉ đặt lại vị trí khi văn bản thật sự đổi. */
    fun bind(newText: String) {
        if (newText == text) return
        text = newText
        ranges = TextUnits.ranges(text, granularity)
        index = -1
    }

    fun cycle(): TextGranularity = select(granularity.next())

    /**
     * Đổi sang đơn vị [target] và giữ nguyên chỗ đang đứng (chọn đơn vị chứa ký tự hiện tại). Chọn lại đúng đơn vị đang dùng
     * thì không làm gì cả, nên gọi nhiều lần vẫn an toàn.
     */
    fun select(target: TextGranularity): TextGranularity {
        if (target == granularity) return granularity
        val anchor = ranges.getOrNull(index)?.first
        granularity = target
        ranges = TextUnits.ranges(text, granularity)
        index = if (anchor == null) -1 else ranges.indexOfLast { it.first <= anchor }
        return granularity
    }

    /** Quên văn bản và vị trí đang gắn: lần [bind] kế tiếp luôn bắt đầu lại, kể cả khi chữ giống hệt phần tử trước. */
    fun reset() {
        text = ""
        ranges = emptyList()
        index = -1
    }

    /**
     * Đặt con trỏ SAU đơn vị cuối cùng: lần [move] lùi kế tiếp đọc đơn vị cuối, lần tiến kế tiếp báo hết chữ. Dùng khi vừa lùi
     * sang phần tử trước, để vuốt tiếp đi ngược qua từng đơn vị của phần tử đó thay vì nhảy qua cả phần tử.
     */
    fun parkAtEnd() {
        index = ranges.size
    }

    fun move(forward: Boolean): UnitMove {
        if (ranges.isEmpty()) return if (forward) UnitMove.End else UnitMove.Start
        val target = if (forward) index + 1 else if (index < 0) -1 else index - 1
        if (target >= ranges.size) return UnitMove.End
        if (target < 0) return UnitMove.Start
        index = target
        return UnitMove.At(slice(ranges[index]))
    }

    /** Đơn vị đang chọn; null nếu chưa di chuyển (hoặc đang đặt sau đơn vị cuối, xem [parkAtEnd]). */
    fun current(): String? = ranges.getOrNull(index)?.let { slice(it) }

    /** Văn bản đang gắn không có đơn vị nào để đọc (rỗng hoặc toàn khoảng trắng). */
    val isEmpty: Boolean get() = ranges.isEmpty()

    private fun slice(r: IntRange) = text.substring(r.first, r.last + 1)
}
