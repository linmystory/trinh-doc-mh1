package com.example.vnscreenreader.plugin

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import com.example.vnscreenreader.core.S
import com.example.vnscreenreader.core.t

/**
 * Lưu script trong thư mục riêng của ứng dụng (filesDir/plugin_scripts).
 * Nhận trực tiếp [File] để kiểm thử được bằng JVM thuần (không cần Context).
 */
class PluginScriptStore(private val dir: File) {

    constructor(context: Context) : this(File(context.applicationContext.filesDir, DIR_NAME))

    /**
     * @param reservedIds id không được dùng (ví dụ id của tiện ích dựng sẵn). Trước đây script trùng id
     * được báo "cài thành công" nhưng không bao giờ hiển thị hay chạy.
     */
    /**
     * @param allAppsConfirmed script không khai báo "packages" chạy ở MỌI ứng dụng: chỉ được cài khi người dùng đã xác
     * nhận (mặc định true để giữ hành vi cũ của lớp lưu trữ; [PluginRegistry] mặc định false).
     */
    fun install(json: String, reservedIds: Set<String> = emptySet(), allAppsConfirmed: Boolean = true): Result<ScriptDefinition> {
        if (json.toByteArray(Charsets.UTF_8).size > MAX_BYTES) {
            return Result.failure(IllegalArgumentException(t(S.STORE_ERR_TOO_LARGE)))
        }
        val definition = ScriptParser.parse(json).getOrElse { return Result.failure(it) }
        if (definition.id in reservedIds) {
            return Result.failure(IllegalArgumentException(t(S.STORE_ERR_BUILTIN_ID, definition.id)))
        }
        if (definition.packages.isEmpty() && !allAppsConfirmed) {
            return Result.failure(AllAppsConfirmationRequired(definition.name))
        }
        return try {
            writeAtomically(File(dir, "${definition.id}.json"), json)
            Result.success(definition)
        } catch (e: IOException) {
            Result.failure(IOException(t(S.STORE_ERR_SAVE)))
        }
    }

    fun loadAll(): List<ScriptDefinition> =
        dir.listFiles { file -> file.isFile && file.extension == "json" && file.length() <= MAX_BYTES }
            ?.sortedBy { it.name }
            ?.mapNotNull { file ->
                try {
                    ScriptParser.parse(file.readText(Charsets.UTF_8)).getOrNull()
                } catch (e: IOException) {
                    null
                }
            }
            .orEmpty()

    fun delete(id: String): Boolean {
        if (!ScriptParser.isValidId(id)) return false
        return File(dir, "$id.json").delete()
    }

    /**
     * Ghi ra tệp tạm rồi đổi tên nguyên tử: mất điện/crash giữa chừng không để lại script hỏng một nửa
     * và không làm mất bản cũ.
     */
    private fun writeAtomically(target: File, content: String) {
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) throw IOException(t(S.STORE_ERR_DIR))
        val temp = File.createTempFile("script_", ".tmp", dir)
        try {
            temp.writeText(content, Charsets.UTF_8)
            try {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE)
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            temp.delete() // chỉ còn tồn tại khi đã lỗi; sau khi move thành công thì đây là no-op
        }
    }

    companion object {
        const val MAX_BYTES = 64 * 1024
        private const val DIR_NAME = "plugin_scripts"

        /** Đọc tối đa [maxBytes] byte; trả về null nếu tệp lớn hơn giới hạn. */
        fun readLimited(input: InputStream, maxBytes: Int): String? {
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > maxBytes) return null
                output.write(buffer, 0, read)
            }
            // String(bytes, charset) có từ API 1; ByteArrayOutputStream.toString(Charset) chỉ có từ API 33.
            return String(output.toByteArray(), Charsets.UTF_8)
        }
    }
}

/** Script chạy ở mọi ứng dụng nhưng người dùng chưa xác nhận. */
class AllAppsConfirmationRequired(val scriptName: String) : Exception(t(S.PL_ALLAPPS_TITLE))
